<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


// base url

$define = new define($con);

echo $getBaseUrl= $define->getBaseUrl();


// crud

$crud = new crud('state',$con);

 $state= $crud->read(5);
print_r($state);


$login = new login($con);

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $error = $login->authenticate($email, $password);
    if ($error) {
        echo $error;
    }
}

$dropdownGenerator = new DropdownGenerator();

echo $dropdownOptions = $dropdownGenerator->generateCustomerNameDropdown($con, 'state', 'name');



// Create an instance of the class with method chaining
$dynamicVars = new DynamicVariables();
echo $dynamicVars->cate;
echo $dynamicVars->name;

?>


<?php
// Your HTML element keys and their respective content extraction methods
$customHeadings = [
    'employee_name' => 'textContent',
    'department' => 'textContent',
    'credit_date' => 'date',
    'rm_approval' => 'selectValue',
    'gm_approval' => 'selectValue',
    'finance_approval' => 'selectValue'
    // Add other keys and their extraction methods as needed
];

// Start generating JavaScript code within PHP
echo '<script>';

// Collect JavaScript object rowData using PHP and JavaScript mixed code
echo 'const rowData = {';

// Loop through customHeadings to construct JavaScript object properties
foreach ($customHeadings as $key => $value) {
    switch ($value) {
        case 'date':
            echo $key . ': cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("input[type=\'date\']").value,';
            break;
        case 'textContent':
            echo $key . ': cells[' . array_search($key, array_keys($customHeadings)) . '].' . $value . ',';
            break;
        case 'selectValue':
            echo $key . ': cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("select").value,';
            break;
        // Add other cases as needed for different extraction methods
        default:
            // Handle other extraction methods or default behavior
            break;
    }
}

// Add state, month, and year separately
echo 'state: \'' . $state . '\',';
echo 'month: \'' . $month . '\',';
echo 'year: \'' . $year . '\'';

// Close the JavaScript object
echo '};';

// Close the JavaScript block
echo '</script>';
?>







<?php



// Table name from which you want to get the field names
$tableName = "employee"; // Change to your table name

// SQL query to get field names of the table
$sql = "DESCRIBE $tableName";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    // Store field names in an array
    $fieldNames = array();
    while ($row = $result->fetch_assoc()) {
        $fieldNames[] = $row['Field'];
    }

    // Output field names
    echo "Field names in '$tableName' table: <br>";
    foreach ($fieldNames as $fieldName) {
        echo $fieldName . "<br>";
    }
} else {
    echo "No results found";
}

?>



<?php


// SQL query to get column names and their data types
$sql = "SHOW COLUMNS FROM $tableName";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    // Store column names and their data types in an associative array
    $columnDataTypes = array();
    while ($row = $result->fetch_assoc()) {
        $columnDataTypes[$row['Field']] = $row['Type'];
    }

    // Output column names and their data types
    echo "Column names and data types in '$tableName' table: <br>";
    foreach ($columnDataTypes as $columnName => $dataType) {
        echo "$columnName: $dataType <br>";
    }
} else {
    echo "No results found";
}

?>

