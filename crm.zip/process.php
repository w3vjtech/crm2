<?php
include("db.php");
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
  if (isset($_POST["Send_Otp"])) {
    // Sanitize user input to prevent SQL injection
    $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING);
    
    // Generate OTP
    $otp = rand(1000, 9999);
    
    // Email OTP to the user
    $to = $username;
    $subject = "Your OTP";
    $message = "Your OTP is: $otp";
    $headers = "From: info@wbinfs.com"; // Replace with a valid sender email

    // Check if the mail was sent successfully before proceeding with database update
    if (mail($to, $subject, $message, $headers)) {
        // Update login table with the generated OTP
        $sql = "UPDATE login SET otp = '$otp' WHERE user_id = '$username'";
        
        // Execute the SQL query (assuming $con is your database connection)
        if ($con->query($sql) === TRUE) {
            // Sending the generated OTP as a JSON response
            echo json_encode(["otp" => "Otp Send"]);
            exit();
        } else {
            echo json_encode(["error" => "Error updating OTP in the database"]);
        }
    } else {
        echo json_encode(["error" => "Error sending OTP via email"]);
    }
}elseif (isset($_POST["Verify"])) {
     $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING);
    $userEnteredOTP = filter_var($_POST["otp"], FILTER_SANITIZE_STRING);
    
    $sql = "SELECT * FROM login WHERE user_id = '$username' AND otp = '$userEnteredOTP'";
    $result = $con->query($sql);

        if ($result) {
            // For demonstration purposes, sending a success message as JSON response
            echo json_encode(["success" => true]);
            exit();
        } else {
            // For demonstration purposes, sending an error message as JSON response
            echo json_encode(["success" => false]);
            exit();
        }
        
}elseif(isset($_POST["forgot_password"])) {
    // Sanitize user input to prevent SQL injection
    $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING);
    $newPassword = $_POST["password"]; // Password should not be sanitized as it may contain special characters
    
    // Update the user's password in the database
    $sql = "UPDATE login SET password = '$newPassword',otp = '' WHERE user_id = '$username'";
    
    // Execute the SQL query (assuming $con is your database connection)
    if ($con->query($sql) === TRUE) {
        // Password updated successfully
        echo json_encode(["password_changed" => true]);
        exit();
    } else {
        // Error updating password in the database
        echo json_encode(["error" => "Error updating password in the database"]);
        exit();
    }
}

}

?>


