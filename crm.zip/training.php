<?php
// file autoload
require_once 'functions/autoload.php';

// database
$db = new db();
$con=$db->getConnection();

$table='tsm_work_book';
include'function.php';


$table='training';

$customHeadings = [
        "id" => 'textContent',
        "ce_name" => 'textContent', 
        "location" => 'textContent',
        "contact_number" => 'textContent',
        "vertical_name"  => 'selectValue',
         "bgv_status" => 'selectValue',
        "wbi_tsm_name" => 'textContent',
        "tsm_rm_name" => 'textContent',
        "trainer_name" => 'textContent',
        "trainer_contact_number" => 'textContent',
        "start_date"  => 'date',
        "complete_date"  => 'date',
        "no_of_days_attend" => 'textContent',
        "aadhar_card_number"  => 'selectValue',
        "driving_license_number"  => 'selectValue',
        "passport_size_photo" => 'selectValue',
        "reference_number" => 'textContent',
        "training_status" => 'selectValue',
        "remarks_from_ot" => 'textContent',
        "remarks" => 'textContent',
];
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body >

<section>
    

<div class='sidebar'>
<?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
<?php include'top-bar.php'; ?>
    </div>
    <div class='page'>

  <div class="position-sticky l-0 z-4 bg-white">
              <h6 class="card-title m-0">training</h6>
           <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
     
    
    </div>
    
    <?php
if($state!=""){    
?>       
<div id="clipboard">
    <input type="text" id="table-search" placeholder="Search..." >
   
   <table id="editable-table">
   
     <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM training WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>


<td class="position-sticky l-0 z-4 bg-white <?php
$diff = date_diff(date_create($row['start_date']), date_create());

// Check if the difference is greater than 7 days and training status is not set
echo ($diff->days > 7 && empty($row['complete_date'])) ? "readmark" : '';
?>" contenteditable>  <?php echo $row["ce_name"]; ?> </td>

<td contenteditable>  <?php echo $row["location"]; ?> </td>
<td contenteditable>  <?php echo $row["contact_number"]; ?> </td>

<td>
<?php 
$DropdownGenerator = new DropdownGenerator();
echo $DropdownGenerator=$DropdownGenerator->generateCustomerNameDropdown($con, 'employee', 'vertical_name',$row["vertical_name"]);
?>
 
</td>
<td>
  <select>
    <option value="<?php echo $row["bgv_status"]; ?>"> <?php echo $row["bgv_status"]; ?> </option>
<option value="select">select</option>
<option value="COMPLETE">COMPLETE</option>
<option value="NOTCOMPLETE">NOTCOMPLETE</option>
  </select>
</td>
<td contenteditable>  <?php echo $row["wbi_tsm_name"]; ?> </td>

<td contenteditable>  <?php echo $row["tsm_rm_name"]; ?> </td>
<td contenteditable>  <?php echo $row["trainer_name"]; ?> </td>

<td contenteditable>  <?php echo $row["trainer_contact_number"]; ?> </td>

<td><input type="date" value="<?php echo $row["start_date"]; ?>"> </td>

<td><input type="date" value="<?php echo $row["complete_date"]; ?>"> </td>


<td contenteditable>  <?php echo $row["no_of_days_attend"]; ?> </td>





<td>
  <select>
    <option value="<?php echo $row["aadhar_card_number"]; ?>"> <?php echo $row["aadhar_card_number"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
    <option value="<?php echo $row["driving_license_number"]; ?>"> <?php echo $row["driving_license_number"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td>
  <select>
    <option value="<?php echo $row["passport_size_photo"]; ?>"> <?php echo $row["passport_size_photo"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td contenteditable>  <?php echo $row["reference_number"]; ?> </td>
<td>
  <select>
    <option value="<?php echo $row["training_status"]; ?>"> <?php echo $row["training_status"]; ?> </option>
<option value=""></option>
<option value="SELECT">SELECT</option>
<option value="REJECT">REJECT</option>
  </select>
</td>

<td contenteditable>  <?php echo $row["remarks_from_ot"]; ?> </td>

<td contenteditable>  <?php echo $row["remarks"]; ?> </td>



        </tr>
        
<?php
    }
}
?>

</tbody>
    </table>
 
 </div>
 
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
 <button id="captureButton">Copy to Clipboard</button>
 
</div> 
 
<?php
}
?>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
           
<td class='d-none'></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable></td>

<td contenteditable>   </td>
<td contenteditable> </td>

<td>
<?php 
$DropdownGenerator = new DropdownGenerator();
echo $DropdownGenerator=$DropdownGenerator->generateCustomerNameDropdown($con, 'employee', 'vertical_name');
?>
</td>
<td>
  <select>
   <option value="select">select</option>
<option value="COMPLETE">COMPLETE</option>
<option value="NOTCOMPLETE">NOTCOMPLETE</option>
  </select>
</td>
<td contenteditable>   </td>

<td contenteditable>   </td>
<td contenteditable>  </td>

<td contenteditable> </td>

<td><input type="date" value=""> </td>

<td><input type="date" value=""> </td>


<td contenteditable> </td>





<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td contenteditable></td>
<td>
  <select>
<option value=""></option>
<option value="SELECT">SELECT</option>
<option value="REJECT">REJECT</option>
  </select>
</td>

<td contenteditable> </td>

<td contenteditable> </td>

<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




    <?php
$customHeadings["state"] = $state;
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');

?>

                 
           
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

<style>
    .readmark {
    border: 1px solid red;
}
</style>
</body>

</html>