
<?php
$download='h';
clearstatcache();
  extract($_GET);
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename="'.$download.'.csv"');

 $date1='01'.date("/m/Y");
 $date2='31'.date("/m/Y");

   include("api/db.php");

   
      
      
function view($con,$sql)
{

 $result=mysqli_query($con,$sql);
while($row = $result->fetch_assoc()){
 $data[]=$row;
 $datas=json_encode($data);
 
 
}
 return json_decode($datas);
 
}
$sql="SELECT * FROM google_form_status";


$activity = view($con,$sql);

 $contents=',G00GLE FORM STATUS JUNE-JULY'."\n";
 $contents.=',STATE NAME- KERALA'."\n";
  $contents.=',TSM NAME- JISHNU'."\n";

 $contents.='state,tsm_name,engineer_name,location,calls_updated_in_whatsapp,g_form_update,no_of_calls_need_to_upload_in_g_form'."\n";
 
 foreach($activity as $mydata)
{
$contents.=str_replace(',', '',$mydata->state)." ,"; 
$contents.=str_replace(',', '',$mydata->tsm_name)." ,"; 
$contents.=str_replace(',', '',$mydata->engineer_name)." ,"; 
$contents.=str_replace(',', '',$mydata->location)." ,"; 
$contents.=str_replace(',', '',$mydata->calls_updated_in_whatsapp)." ,"; 
$contents.=str_replace(',', '',$mydata->g_form_update)." ,"; 
$contents.=str_replace(',', '',$mydata->no_of_calls_need_to_upload_in_g_form)." \n"; 
}




$contents = strip_tags($contents);

print $contents;	
?>
