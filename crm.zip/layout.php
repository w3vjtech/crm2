

 <link rel="stylesheet" href="https://wbinfs.in/style.php">
<style>
nav {
    text-transform: capitalize;
    position: sticky;
    top: 0px;
    z-index:1050;
}
.overflow-overlay {
    overflow: overlay;
}
    .menu ul li button {
    display:block;
    }  


.menu {
    position: relative;
    width:100%;
    max-width:700px;
}

.menu ul {
  width:100%;
  list-style: none;
  padding: 0;
  margin: 0;
  gap: 30px;
  display: flex;
  flex-direction: column;
}





/* This hides the dropdowns */


.menu li ul { display: none; }

.menu ul li a {
  display: block;
  text-decoration: none;
  white-space: nowrap;
  color: white;
  line-height: 2.5;
  font-family: 'Euclid Circular B SemiBold', sans-serif;
    font-weight: normal;
}






.menu li ul li { border-top: 0; }

/* Displays second level dropdowns to the right of the first level dropdown */






.menu ul:after { clear: both; }



   


.menu {
    padding-top: 45px;
}





.menu ul li a {
    width: 80%;
    
}

.menu ul li  {
    width: 100%;
    position: relative;
}
button.showButton svg {
    width: 20px;
    height: 20px;
}
.menu li button {
    position: absolute;
    right: 15px;
    top: 0px;
    margin:0px;
    padding:0px;
}

button {
    background: #3dbdb5;
    padding: 12px 23px;
    color: white;
}
.menu_icon svg {
    height: 30px;
    width:30px;
    fill: white;
}
</style>



 <nav class='h-100vh overflow-overlay  mw-500 p-10  l-0 bg-primary'>
  
      <div class='menu p-10 pt-md-30 pb-0 p-md-0  d-flex  flex-direction-column align-items-flex-start justify-content-space-between'>
    
      
    <img  class='mb-50 mx-auto' src="https://wbinfs.in/assets/logo-bg-white.png" height='75px' ></img>
        
        
<?php
include 'db.php'; // Assuming 'db.php' contains your database connection information

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
$type = 'TSM';


// Function to recursively build the tree menu as an HTML unordered list
function buildTree($parent_id = NULL, $con) {
    global $type; 
    $query = "SELECT * FROM menu WHERE FIND_IN_SET('$type', access) > 0 AND parent_id " . ($parent_id ? "= $parent_id" : "IS NULL"). " ORDER BY order_id";
    $result = $con->query($query);

    if ($result->num_rows > 0) {
        echo "<ul>"; // Start the unordered list
        while ($row = $result->fetch_assoc()) {
            // Output the menu item as a list item
            
            
            echo "<li> <div class='d-flex justify-content-flex-start gap-10 align-content-center align-items-center menu_icon'> " . $row['icon'] . "<a href='" . $row['url'] . "'>" . $row['page'] . "</a> </div>";
            
            if($row['url']==""){
echo '<button class="showButton"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6.91 12.65"  ><g id="a7f88036-326e-4150-88c4-9d6b8a1610b0" data-name="Layer 2"><g id="e414f6f0-4d54-48dd-b0d5-dd4fdc6de053" data-name="Layer 1"><line x1="0.5" y1="0.5" x2="6.41" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.41" y1="6.41" x2="0.5" y2="12.15" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg></button> ';
}
            // Recursive call for children
            buildTree($row['id'], $con);

            echo "</li>"; // Close the list item
        }
        echo "</ul>"; // Close the unordered list
    }
}

// Call the function to build the tree menu starting from the top-level items
buildTree(NULL, $con);

// Close database connection
$con->close();
?>
</div>
</nav>
  <script>
        
        var buttons = document.querySelectorAll('.showButton');

        buttons.forEach(function(button) {
            button.addEventListener('click', function() {
                var ul = this.nextElementSibling;
                if (ul.style.display === 'none') {
                    ul.style.display = 'block';
                    this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12.65 6.91" ><g id="b5abdd3f-8659-4748-bdbe-779c8f04327b" data-name="Layer 2"><g id="e32df425-7f56-4e14-8b91-f6b1b51ef6c6" data-name="Layer 1"><line x1="12.15" y1="0.5" x2="6.24" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.24" y1="6.41" x2="0.5" y2="0.5" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg>';
                } else {
                    ul.style.display = 'none';
                    this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6.91 12.65" ><g id="a7f88036-326e-4150-88c4-9d6b8a1610b0" data-name="Layer 2"><g id="e414f6f0-4d54-48dd-b0d5-dd4fdc6de053" data-name="Layer 1"><line x1="0.5" y1="0.5" x2="6.41" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.41" y1="6.41" x2="0.5" y2="12.15" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg>';
                }
            });
        });
    </script>
