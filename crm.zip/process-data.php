<?php
include'api/db.php';
    
    $data = json_decode(file_get_contents('php://input'), true);

  print_r($data);
   
foreach ($data as $entry) {
    
    extract($entry);

  if($id!=""){  
    
 $sql = "UPDATE tsm_work_book SET state='$state',wbi_engineer='$wbi_engineer',location='$location',cms_team_leader='$cms_team_leader',cms_engineer='$cms_engineer',am10_call_planned_by_wbi_ce='$am10_call_planned_by_wbi_ce',am10_status='$am10_status',am10_remarks='$am10_remarks',pm1_status='$pm1_status',pm1_remarks='$pm1_remarks',no_of_call_attended='$no_of_call_attended',call_closer_count='$call_closer_count',pm8_remarks='$pm8_remarks',report_time='$report_time',date='$date',wbi_tsm='$wbi_tsm',rm_name='$rm_name',jm_name='$jm_name' WHERE id='$id'";
  
      
  }else{ 
      
$sql = "INSERT INTO tsm_work_book (state, wbi_engineer, location, cms_team_leader, cms_engineer, am10_call_planned_by_wbi_ce, am10_status, am10_remarks, pm1_status, pm1_remarks, no_of_call_attended,call_closer_count, pm8_remarks, report_time, date, wbi_tsm, rm_name, jm_name) VALUES ('$state', '$wbi_engineer', '$location', '$cms_team_leader', '$cms_engineer', '$am10_call_planned_by_wbi_ce', '$am10_status', '$am10_remarks', '$pm1_status', '$pm1_remarks', '$no_of_call_attended','$call_closer_count', '$pm8_remarks', '$report_time', '$date', '$wbi_tsm', '$rm_name', '$jm_name')";

  }  
    
if(mysqli_query($con,$sql)){
     $response = ['status' => 'success', 'message' => 'tsm_work_book submitted'];
   echo json_encode($response);
}

}

?>