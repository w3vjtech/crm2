<?php

 include'../db.php';
 
   $sql = "SELECT * FROM employee";

	   $result=mysqli_query($con,$sql);
while($row = $result->fetch_assoc()){
    
 $dob=$row['dob'].'<br>';
 $to= $row['email'];
 $name = $row['first_name'];



$parts = explode('/', $dob);
$cdate=date("dm");
$bdate=$parts[0].$parts[1];

if($cdate==$bdate){
     echo $cdate.'<br>';
     include'sendemail.php';
}

}

?>

