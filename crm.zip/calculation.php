<?php
$designationColumn = "designation";
$designation = "SERVICE ENGINEERS";
$southStates = "('KERALA', 'TAMIL NADU', 'ANDHRA PRADESH', 'TELANGANA', 'KARNATAKA', 'MAHARASTRA')";
$northStates = "('MADHYA PRADESH', 'GUJARAT', 'RAJASTHAN', 'DELHI', 'PUNJAB', 'BIHARJHARKAND', 'UTTAR PRADESH', 'WEST BENGAL', 'ODISHA', 'ASSAM')";

// Function to execute query and handle errors
function executeQuery($con, $sql) {
    $result = $con->query($sql);
    if ($result === false) {
        die("Error executing query: " . $con->error);
    }
    return $result->fetch_assoc();
}

// Get total employees count
$totalEmployees = executeQuery($con, "SELECT COUNT(*) AS total FROM employee")['total'];

// Get count of employees excluding SERVICE ENGINEERS
$managementCount = executeQuery($con, "SELECT COUNT(*) AS total FROM employee WHERE $designationColumn != '$designation'")['total'];

// Get count of SERVICE ENGINEERS
$excludedCount = executeQuery($con, "SELECT COUNT(*) AS excludedCount FROM employee WHERE $designationColumn = '$designation'")['excludedCount'];

// Calculate percentages
$percentageOtherDesignations = (($totalEmployees - $excludedCount) / $totalEmployees) * 100;
$percentageExcluded = ($excludedCount / $totalEmployees) * 100;

// Get count of SERVICE ENGINEERS in South and North states
$southCount = executeQuery($con, "SELECT COUNT(*) AS southCount FROM employee WHERE state IN $southStates AND designation = '$designation'")['southCount'];
$northCount = executeQuery($con, "SELECT COUNT(*) AS northCount FROM employee WHERE state IN $northStates AND designation = '$designation'")['northCount'];

// Calculate percentages for South and North
$percentageSouth = ($southCount / $excludedCount) * 100;
$percentageNorth = ($northCount / $excludedCount) * 100;

// // Display the results
// echo "Total count of Staffs: " . $totalEmployees . "<br>";
// echo "Total count of Management Staffs : " . $managementCount . "<br>";
// echo "Percentage : " . round($percentageOtherDesignations, 2) . "%<br>";
// echo "Total count of service engineers: " . $excludedCount . "<br>";
// echo "Percentage : " . round($percentageExcluded, 2) . "%<br>";
// echo "Total count of SERVICE ENGINEERS in South states: " . $southCount . "<br>";
// echo "Percentage : " . round($percentageSouth, 2) . "%<br>";
// echo "Total count of SERVICE ENGINEERS in North states: " . $northCount . "<br>";
// echo "Percentage : " . round($percentageNorth, 2) . "%<br>";

?>




