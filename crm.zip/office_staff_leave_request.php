<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();




$table='invoice';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='office_staff_leave_request';

$customHeadings = [
    "id" => 'textContent',
    "date" =>'date',
    "state" =>'textContent' ,
    "wbi_management_staff" => 'textContent', 
    "start_date" => 'date',
    "end_date" => 'date',
    "designation" =>'textContent',
    "reporting_person_permission" => 'selectValue',
    "hr_permission" => 'selectValue',
    "remarks" => 'textContent',
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>

<section>
    

<div class='sidebar'>
    
<?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
         <div>

    
    
    <div class="position-sticky l-0 z-4 bg-white">
         <h6  class="pt-5">office staff leave request</h6>
        <?php
$list = ['month'=>$month, 'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
    </div>
     
    <?php
if($month!="" AND $year!=""){    
?>    
 
<div id="clipboard">
    
<input type="text" class="position-sticky l-0 z-4 bg-white" id="table-search" placeholder="Search..." >

   <table id="editable-table">
  <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM office_staff_leave_request WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
          
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td><input type="date" value="<?php echo $row["date"]; ?>"></td>
<td contenteditable><?php echo $row["state"]; ?></td>
<td contenteditable><?php echo $row["wbi_management_staff"]; ?></td>
<td><input type="date" value="<?php echo $row["start_date"]; ?>"></td>
<td><input type="date" value="<?php echo $row["end_date"]; ?>"></td>

<td contenteditable><?php echo $row["designation"]; ?></td>

 <td>
 <select>
    <option value="<?php echo $row["reporting_person_permission"]; ?>"> <?php echo $row["reporting_person_permission"]; ?></option>
    <?php if($type=="HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select> 
 </td>
 
 <td>
 <select>
    <option value="<?php echo $row["hr_permission"]; ?>"> <?php echo $row["hr_permission"]; ?></option>
     <?php if($type=="HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select> 
 </td>
 
<td contenteditable><?php echo $row["remarks"]; ?></td>

     </tr>

        <?php
    }
}
?>

</tbody>
    </table>

  
<?php
}
?>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           
  <td class='d-none'></td>
<td><input type="date" value=""></td>
<td contenteditable></td>
<td contenteditable></td>
<td><input type="date" value=""></td>
<td><input type="date" value=""></td>

<td contenteditable></td>
 
 <td>
 <select>
    <?php if($type=="HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select> 
 </td>
 
 <td>
 <select>
    <?php if($type=="HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?> 
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select> 
 </td>
 
<td contenteditable>  </td>
      

<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>


</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
<button id="submit-button" <?php if($type != "HR" && $type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
<button onclick="addTableRow()">Add Row</button>
<button id="captureButton">Copy to Clipboard</button>

</div>


<?php
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;
      
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');


$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



 </div>
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>