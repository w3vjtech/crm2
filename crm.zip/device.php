<script>
    var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    var screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    var request = new XMLHttpRequest();
   request.open("GET", "pc_verify.php?screen_width=" + screenWidth + "&screen_height=" + screenHeight, true);
 request.onreadystatechange = function() {
        if(this.readyState === 4 && this.status === 200) {
var jsonResponse = this.responseText;
try {
    var parsedResponse = JSON.parse(jsonResponse);

    if (parsedResponse && parsedResponse.access === "granted") {
         document.querySelector('.access').style.display = 'none';
    } else {
        document.querySelector('.access').style.display = 'flex';
        alert("Access Denied!");
        
    }
} catch (error) {
    console.error("Error parsing JSON:", error);
    alert("Error parsing JSON");
}

        }
    };
    request.send();

</script>

<div class='access'>
    <div class='bg-white d-flex flex-direction-column'>
    <button class='fs-40 bg-white text-primary'> Access Only On PC</button>
    <button class='fs-20 bg-white text-primary'>Please maximise your screen size and Refresh the page </button>
    </div>
</div>

<style>
    .access {
    background: #3dbdb5;
    z-index: 1050;
    display: flex;
    flex-direction: column;
    align-content: center;
    flex-wrap: nowrap;
    justify-content: center;
    align-items: center;
    color: white;
    font-size: 25px;
    height: 100%;
    width: 100%;
    position: fixed;
    top: 0px;
    left: 0px;
}
</style>