<?php
include'crud.php';
include'db.php';
// Initialize CRUD object
$dynamicCRUD = new DynamicCRUD('office_attendance', $con);

$data = json_decode(file_get_contents('php://input'), true);

  print_r($data);
   
foreach ($data as $entry) {
  if($entry['id']!=""){  
   $response = $dynamicCRUD->update($entry['id'], $entry);  
  }else{ 
    $response = $dynamicCRUD->create($entry);
  }  
}
// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>



