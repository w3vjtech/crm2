<?php
// file autoload
require_once 'functions/autoload.php';

// database
$db = new db();
$con = $db->getConnection();

if (isset($_POST["submit"])) {
    if (isset($_FILES['file'])) {
        $tableName = $_GET['table']; // Assuming table name is obtained from $_GET['table']

        // Instantiate CSV_upload class
        $csvProcessor = new CSV_upload($con);

        // Process the CSV file
        $uploadResult = $csvProcessor->processCSV($tableName, $_FILES['file']);

        if ($uploadResult === true) {
            echo "CSV data successfully processed and inserted into the database.";
        } else {
            echo "Failed to process CSV data. Please check your file and try again.";
        }
    } else {
        echo "No file uploaded.";
    }
}
?>

<form method="post" enctype="multipart/form-data">
    <label>Select CSV File:</label>
    <input type="file" name="file">
    <br>
    <input type="submit" name="submit" value="Import">
</form>


  