
<?php
$download='h';
clearstatcache();
  extract($_GET);
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename="'.$download.'.csv"');

 $date1='01'.date("/m/Y");
 $date2='31'.date("/m/Y");

   include("api/db.php");

   
      
      
function view($con,$sql)
{

 $result=mysqli_query($con,$sql);
while($row = $result->fetch_assoc()){
 $data[]=$row;
 $datas=json_encode($data);
 
 
}
 return json_decode($datas);
 
}
$sql="SELECT * FROM fcr";


$activity = view($con,$sql);

 $contents=',FCR SUBMISSION DETAILS'."\n";



 $contents.='engineer_name,number_of_fcr_submitted_to_cms,submitted_to_whom_cms_ce_tl_name_and_phone_number,which_month_fcr,submitted_date,submitted_via_courier_or_by_hand,courier_docket_number'."\n";
 
 foreach($activity as $mydata)
{
$contents.=str_replace(',', '',$mydata->engineer_name)." ,"; 
$contents.=str_replace(',', '',$mydata->number_of_fcr_submitted_to_cms)." ,"; 
$contents.=str_replace(',', '',$mydata->submitted_to_whom_cms_ce_tl_name_and_phone_number)." ,"; 
$contents.=str_replace(',', '',$mydata->which_month_fcr)." ,"; 
$contents.=str_replace(',', '',$mydata->submitted_date)." ,"; 
$contents.=str_replace(',', '',$mydata->submitted_via_courier_or_by_hand)." ,"; 
$contents.=str_replace(',', '',$mydata->courier_docket_number)." \n"; 
}




$contents = strip_tags($contents);

print $contents;	
?>
