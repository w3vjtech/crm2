<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
$table='gst';

$customHeadings = [
    "id" => 'textContent',
    "invoice_number" => 'textContent', 
    "invoice_date" => 'date',
     "month" => $month,
    "year" => $year,
     "client_name" => 'selectValue',
    "invoice_amount" => 'textContent',
    "gst_amount" => 'textContent',
    "total_amount"=>'textContent',
     "gst_status" => 'selectValue',
    "gst_due_date" => 'date',
    "gst_paid_date" => 'date',
   "remarks" => 'textContent',
   
];
    ?>
    
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">
  



<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
         <div class="position-sticky l-0 z-4 bg-white">
<h6 class="card-title m-0">GST</h6>
<?php
$list = ['month'=>$month, 'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
 </div>   
        
          
  
 
   
<div id="clipboard">
    
   <table id="editable-table">
    <input type="text" id="table-search" placeholder="Search..." >
       <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM gst  WHERE 1";

// if(isset($state)){
//   $sql .= " AND state='$state'";
// }
if(isset($month)&&!empty($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)&&!empty($year)){
  $sql .= " AND year='$year'";
}


$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>





<td class="position-sticky l-0 z-4 bg-white" contenteditable><?php echo $row["invoice_number"]; ?></td>
<td>   
 <input type="date"  value="<?php echo $row["invoice_date"]; ?>">
</td>
<td contenteditable><?php echo $row["month"]; ?></td>
<td contenteditable><?php echo $row["year"]; ?></td>

    <td>
 <select>
    <option value="<?php echo $row["client_name"]; ?>"> <?php echo $row["client_name"]; ?></option>
<option value="select">select</option>
<?php  echo $selectDropdown = generateSelectDropdown($con, 'finance_client', 'name'); ?>
  </select> 
 </td>
 


<td contenteditable><?php echo $row["invoice_amount"]; ?></td>
<td ><?php echo $row["gst_amount"]; ?></td>
<td ><?php echo $row["total_amount"]; ?></td>
<td>
  <select onchange="updateBorderColor(this)">
    <option value="<?php echo $row["gst_status"]; ?>"> <?php echo $row["gst_status"]; ?></option>
<option value="select">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>

  </select>
</td>
<td>   
 <input type="date"  value="<?php echo $row["gst_paid_date"]; ?>">
</td>

<td>   
 <input type="date"  value="<?php echo $row["gst_due_date"]; ?>">
</td>
<td contenteditable><?php echo $row["remarks"]; ?></td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>
</div>

<div class='position-sticky l-0 z-4 bg-white d-flex gap-20'>
<button id="submit-button" <?php if($type != "FM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
<button id="export-button">Export to Excel</button>
<button onclick="addTableRow()">Add Row</button>
<button id="captureButton">Copy to Clipboard</button>
</div>

 <script>
      function calculateGST() {
        [...document.querySelectorAll('#editable-table tbody tr')].forEach(row => {
          const valueCell = row.querySelector('td:nth-child(7)');
          const gstColumn = row.querySelector('td:nth-child(8)');
          const TotalColumn = row.querySelector('td:nth-child(9)');

          const valueString = valueCell.textContent || '0';
          const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;

          const gstRate = 18;
          const gstAmount = (numericValue * gstRate) / 100;

          gstColumn.textContent = `${gstAmount.toFixed(2)}`; 
          
          const TotalAmount =  numericValue + gstAmount;
          
          TotalColumn.textContent = `${TotalAmount.toFixed(2)}`; 
          
        });
      }

      calculateGST();

      document.querySelectorAll('#editable-table tbody tr td:nth-child(7)').forEach(cell => {
        cell.addEventListener('input', calculateGST);
      });

  </script>
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           <td class='d-none'></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable> </td>
<td>   
 <input type="date"  value="">
</td>
<td contenteditable>  </td>
<td contenteditable>  </td>
<td>
  <select onchange="updateBorderColor(this)">
<option value="select">select</option>
<?php
$sql = "SELECT * FROM finance_client";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
        echo '<option value="' . $name . '">' . $name . '</option>';

    }
} 
?>

  </select>
</td>

<td contenteditable>  </td>
<td >   </td>
<td >   </td>
<td>
  <select onchange="updateBorderColor(this)">

<option value="select">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>

  </select>
</td>
<td>   
 <input type="date"  value="">
</td>

<td>   
 <input type="date"  value="">
</td>
<td contenteditable>  </td>




      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>



<?php
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');

?>




           
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>

</body>

</html>