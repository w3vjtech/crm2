<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
   
 $report_time=$_GET['report_time'];
$state=$_GET['state'];
  $start_date= date("d-m-Y", strtotime($_GET['start_date']));
  $end_date= date("d-m-Y", strtotime($_GET['end_date']));

 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body>
    <section>

    <div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
           
              
        
<div class='position-sticky l-0 z-4 bg-white'>


    
      <h6 class="card-title m-0">tsm-monthly-output</h6>
            
    
             
             <form action="" method="get" class='searc-form'>
      <div class='d-flex gap-30'>
          
                <div >
  <label class="form-label">State:</label>
  <select name="state" class="form-control form-control-lg">
    <option value="<?php echo isset($state) ? $state : ''; ?>"> <?php echo isset($state) ? $state : 'Select'; ?></option>
   <?php
        echo $state_access;
       $array = explode(",", $state_access);

        ?>
        
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
if (in_array($name, $array)) {
        echo '<option value="' . $name . '">' . $name . '</option>';
}
    }
} 
?>
</select>
</div>

<div >
    <label class="form-label">start_date:</label>
    <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="form-control form-control-lg" placeholder="start_date" required>
</div>
<div >
    <label class="form-label">end_date:</label>
    <input type="date" name="end_date" value="<?php echo $end_date; ?>" class="form-control form-control-lg" placeholder="end_date" required>
</div>


<div >
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    
    
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}

tbody, td, tfoot, th, thead, tr {
    padding: 10px;
    width: max-content;
    text-wrap: nowrap;
    border: 1px solid #606060;
}
    </style>
     </div> 
    <?php
//if($state!="" AND $start_date!="" AND $end_date!=""){    
?>       

<?php
function fetchData($state, $type, $con) {
    $state = $con->real_escape_string($state);
    $type = $con->real_escape_string($type);

    $sql = "SELECT name FROM login WHERE state LIKE '%$state%' AND type = '$type'";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "Name: " . $row["name"] . "<br>";
        }
    } else {
        echo "No results found.";
    }
}


// Assuming you have established a connection to your database.
// Make sure to set $start_date, $end_date, $state, and have a valid $con connection.


?>




<?php
$sql = "SELECT date,  wbi_engineer_name, location, no_of_call_attended  
        FROM tsm_work_book
        WHERE date BETWEEN '$start_date' AND '$end_date' AND  state ='$state'";

$result = mysqli_query($con, $sql);

?>





<?php

if ($result) {
    
    $dates = [];
   
    $engineers = [];
    $locations = [];
    $calls = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $date = $row['date'];
         $engineer = trim($row['wbi_engineer_name']); // Trim whitespace from the engineer name

        $location = $row['location'];
        $no_of_calls = $row['no_of_call_attended'];
          $dates[] = $date;

          $engineers[] = $engineer;

        $locations[$engineer] = $location;

        // Assign calls data to the appropriate date and engineer
        $calls[$date][$engineer] = $no_of_calls;
    }
    
$dates = array_unique($dates);
$engineers = array_map('trim', array_unique($engineers)); // Trim each element in the array
    if (!empty($dates)) {
        echo '<table border="1">
            <tr>
                <th colspan="' . (count($engineers) + 1) . '">Engineer Output</th>
            </tr>
            <tr>
                <th colspan="' . (count($engineers) + 1) . '">State Name</th>
            </tr>
            <tr>
                <th colspan="' . (count($engineers) + 1) . '">TSM Name</th>
            </tr>
        ';

        // Print Engineer and Location headers
        echo '<tr><td>Engineer</td>';
        foreach ($engineers as $engineer) {
            echo '<td>' . $engineer . '</td>';
        }
        echo '</tr>';

        echo '<tr><td>Location</td>';
        foreach ($engineers as $engineer) {
            echo '<td>' . $locations[$engineer] . '</td>';
        }
        echo '</tr>';

        // Print Date and Calls data
        foreach ($dates as $date) {
            echo '<tr><td>' . $date . '</td>';
            foreach ($engineers as $engineer) {
                echo '<td>' . $calls[$date][$engineer] . '</td>';
            }
            echo '</tr>';
        }

        echo '</table>';
    } else {
        echo 'No data found';
    }
} else {
    echo 'Error in query execution: ' . $conn->error;
}
?>



<?php
//}
?>


  <button id="exportButton">Export to CSV</button>

  <script>
  
    document.getElementById('exportButton').addEventListener('click', function() {
      exportTableToCSV('tsm-monthly-output.csv');
    });

    function exportTableToCSV(filename) {
      var csv = [];
      var rows = document.querySelectorAll('table tr');

      for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll('td, th');

        for (var j = 0; j < cols.length; j++) {
          row.push(cols[j].innerText);
        }

        csv.push(row.join(','));
      }

      var blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });

      var link = document.createElement('a');
      if (link.download !== undefined) { 
        var url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  </script>
  
  


                 

       </div> 
   
     
       
          <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
</div>   
    </section>
    
</body>

</html>