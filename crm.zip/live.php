<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Table Edit and Data Submission</title>
</head>
<body>
    <h1>Editable Table</h1>
    <table id="editable-table">
        <thead>
            <tr>
                <th>State</th>
                <th>WBI Engineer</th>
                <th>Location</th>
                <th>CMS Team Leader</th>
                <th>CMS Engineer</th>
                <th>Call Planned by WBI CE</th>
                <th>Status</th>
                <th>Remarks</th>
                <th>Report Time</th>
                <th>Date</th>
                <th>WBI TSM</th>
                <th>RM Name</th>
                <th>JM Name</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td contenteditable>State 1</td>
                <td contenteditable>Engineer A</td>
                <td contenteditable>Location X</td>
                <td contenteditable>Team Leader A</td>
                <td contenteditable>Engineer C</td>
                <td contenteditable>Yes</td>
                <td contenteditable>Open</td>
                <td contenteditable>Details...</td>
                <td contenteditable>10:00 AM</td>
                <td contenteditable>2023-08-23</td>
                <td contenteditable>TSM 1</td>
                <td contenteditable>RM 1</td>
                <td contenteditable>JM 1</td>
            </tr>
            <tr>
                <td contenteditable>State 2</td>
                <td contenteditable>Engineer B</td>
                <td contenteditable>Location Y</td>
                <td contenteditable>Team Leader B</td>
                <td contenteditable>Engineer D</td>
                <td contenteditable>No</td>
                <td contenteditable>Closed</td>
                <td contenteditable>Notes...</td>
                <td contenteditable>2:30 PM</td>
                <td contenteditable>2023-08-24</td>
                <td contenteditable>TSM 2</td>
                <td contenteditable>RM 2</td>
                <td contenteditable>JM 2</td>
            </tr>
        </tbody>
    </table>

    <button id="submit-button">Submit Data</button>


    <script>
        document.getElementById('submit-button').addEventListener('click', function () {
            const tableRows = document.querySelectorAll('#editable-table tbody tr');
            const data = [];

            tableRows.forEach(row => {
                const cells = row.querySelectorAll('td');
                const rowData = {
                    state: cells[0].textContent,
                    wbi_engineer: cells[1].textContent,
                    location: cells[2].textContent,
                    cms_team_leader: cells[3].textContent,
                    cms_engineer: cells[4].textContent,
                    call_planned_by_wbi_ce: cells[5].textContent,
                    status: cells[6].textContent,
                    remarks: cells[7].textContent,
                    report_time: cells[8].textContent,
                    date: cells[9].textContent,
                    wbi_tsm: cells[10].textContent,
                    rm_name: cells[11].textContent,
                    jm_name: cells[12].textContent
                };
                data.push(rowData);
            });

            const jsonString = JSON.stringify(data);

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'process-data.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        console.log('Data sent successfully:', xhr.responseText);
                    } else {
                        console.error('Error sending data:', xhr.statusText);
                    }
                }
            };
            xhr.send(jsonString);
        });
    </script>
</body>
</html>
