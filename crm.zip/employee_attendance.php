<?php
$table='employee_attendance';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 
</head>

<body class="layout-1" data-luno="theme-black">

 <?php
  include'sidebar.php';
  ?>
  <div class="wrapper">
<?php
include'header.php';
?>




     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0"> Employee Attendance</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
            

    <!-- Display the add/edit employee_attendance form -->
    
      
    
 
 
    <form method="POST" action="" class="card-body">
        
        <input type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
    <div class="row g-3">    

         <div class="col-md-6">
              <label class="form-label">Name:</label>
        <input type="text" name="name" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['name'] : ''; ?>" class="form-control form-control-lg" placeholder="Name" required>
       
       </div>
 <div class="col-md-6">
              <label class="form-label">DESIGNATION:</label>
        <input type="text" name="designation" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['designation'] : ''; ?>" class="form-control form-control-lg" placeholder="Designation" required>
       
       </div>
          <div class="col-md-6">
              <label class="form-label">Date:</label>
        <input type="date" name="date" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['date'] : ''; ?>" class="form-control form-control-lg" placeholder="Date" required>
       
       </div>
        <div class="col-md-6">
              <label class="form-label">GPS IMAGE:</label>
               <div class='selectmenu'>
              
              <input type="radio" name="gps_image" value="yes" <?php if (isset($_GET['edit'])) { echo $pageresults[0]['gps_image'] === 'yes' ? 'checked' : ''; } ?>>

<label>yes</label>
<input type="radio" name="gps_image" value="no" <?php if (isset($_GET['edit'])) { echo $pageresults[0]['gps_image'] === 'no' ? 'checked' : ''; } ?>>

<label>no</label>
</div>
       </div>

           <div class="card-footer">
                <button type="submit" name="submit" class="btn btn-primary"><?php echo isset($_GET['edit']) ? 'Update' : 'Add'; ?> employee attendance</button>
                </div>
    </form>
    
    
             
                <table class="table myDataTable table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </th>
 <th> name  </th>
 <th> designation  </th>
 <th> date  </th>
 <th> gps_image  </th>



            <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                      
                           <?php foreach ($pageresults as $pageresult) : ?>
        <tr>
             <td>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </td>
                      

<td><?php echo $pageresult['name']; ?></td>

<td><?php echo $pageresult['designation']; ?></td>


<td><?php echo $pageresult['date']; ?></td>
<td><?php echo $pageresult['gps_image']; ?></td>


            
              <td>
                          <a href="?edit=<?php echo $pageresult['id']; ?>" > <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-edit"></i></button></a>
                        <a href="?delete=<?php echo $pageresult['id']; ?>" onclick="return confirm('Are you sure you want to delete this employee_attendance?')"> <button type="button" class="btn btn-sm btn-outline-danger"><i class="fa fa-trash-o"></i></button></a>
                      </td>
                      
        </tr>
        <?php endforeach; 
              ?>
                    
  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    
    
    
    
       
 <?php
include'footer.php';
?>  </div>

</body>

</html>