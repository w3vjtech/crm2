<?php
header('Content-Type: application/json');

 $screenWidth = isset($_GET['screen_width']) ? $_GET['screen_width'] : null;
 $screenHeight = isset($_GET['screen_height']) ? $_GET['screen_height'] : null;

        if (intval($screenWidth) > 1140) {
           
            $response = [
        'device'  => "pc",       
        'access' => "granted",
    ];

        } else {
              $response = [
         'device'  => "Not pc",       
        'access' => "denied",
    ];

        }
        
    echo json_encode($response);
?>        