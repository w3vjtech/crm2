<?php
$table='invoice';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>
<div class='d-flex'>

<?php
include'header.php';
?>


<div class='w-100 p-10'>
  
<?php include'top-bar.php'; ?>

     <h6  class="py-15 Euclid-Circular-B-SemiBold">wbi organization chart table</h6>
    
    
    <style>
    
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}
    </style>
    
    
    <?php
//if($state!="" AND $date!=""){    
?>       
<div id="clipboard">

   <table id="editable-table">
        <thead>
        
            <tr>
                <th>id</th>
<th>name</th>
<th>designation</th>
<th>parent id</th>
<th>order id</th>

            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM wbi_organization_chart  WHERE name != 'Organizational Chart'";

//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
          


<td><?php echo $row["id"]; ?></td>

<td contenteditable><?php echo $row["name"]; ?></td>

<td contenteditable><?php echo $row["designation"]; ?></td>

<td contenteditable><?php echo $row["parent_id"]; ?></td>

<td contenteditable><?php echo $row["order_id"]; ?></td>
  </tr>

        <?php
    }
}
?>

</tbody>
    </table>

  <button id="submit-button">Submit Data</button>
  <button id="export-button">Export to Excel</button>

<?php
//}
?>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
          
<td></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>

<button onclick="addTableRow()">Add Row</button>


<button id="captureButton">Copy to Clipboard</button>
</div>



<script>document.getElementById('captureButton').addEventListener('click', function() {html2canvas(document.getElementById('clipboard')).then(function(canvas) {canvas.toBlob(function(blob) {var item = new ClipboardItem({ "image/png": blob });navigator.clipboard.write([item]);});});});</script>

<script>
function updateBorderColor(selectElement) {
  const selectedValue = selectElement.value.toLowerCase();
  let borderColor = "";

  switch (selectedValue) {
    case "approved":
    case "paid":
      borderColor = "green";
      break;
    case "pending":
    case "unpaid":
      borderColor = "red";
      break;
    default:
      borderColor = "";
      break;
  }

  selectElement.style.borderColor = borderColor;
}
</script>


<script>
  document.getElementById('submit-button').addEventListener('click', function () {
        const tableRows = document.querySelectorAll('#editable-table tbody tr');
        const data = [];

        tableRows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const rowData = {
                
                
                id: cells[0].textContent,
                name: cells[1].textContent,
                designation: cells[2].textContent,
                parent_id: cells[3].textContent,
                order_id: cells[4].textContent,
                  
            };
            data.push(rowData);
        });

        const jsonString = JSON.stringify(data);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'wbi_organization_chart_table_crud.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert('Data sent successfully');
                    console.log('Data sent successfully:', xhr.responseText);
                } else {
                    alert("Data sent Failed");
                    console.error('Error sending data:', xhr.statusText);
                }
            }
        };
        xhr.send(jsonString);
    });
</script>

<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
               
    "id",
    "name",
    "designation",
    "parent_id",
    "order_id",

    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
                id: cells[0].textContent,
                name: cells[1].textContent,
                designation: cells[2].textContent,
                parent_id: cells[3].textContent,
                order_id: cells[4].textContent,
                
         
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


 <?php
include'footer.php';
?>  </div>
</div>
</body>

</html>