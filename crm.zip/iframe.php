<?php
$url=$_GET['url'];
?>
<iframe src="<?php echo $url; ?>">
</iframe>

<style>
    iframe {
    width: 100%;
    height: 100%;
    padding: 0px;
    margin: 0px;
    border: 0px;
    outline: 0px;
}
</style>