<?php
// autoload.php

spl_autoload_register(function ($className) {
    // Convert namespace separators (\) to directory separators (/)
    $className = str_replace('\\', '/', $className);

    // Assume classes are stored in the 'classes' directory
    $file = __DIR__ . '/classes/' . $className . '.php';

    // Check if the file exists, then include it
    if (file_exists($file)) {
        require_once $file;
    }
});
?>