<?php
class SubmitButton {
    public static function renderScript($customHeadings, $table,$editable_table,$submit_button) {
        $jsScript = '<script>';
        $jsScript .= 'document.getElementById("'.$submit_button.'").addEventListener("click", function() {  this.disabled = true;';
        $jsScript .= 'const tableRows = document.querySelectorAll(\'#' . $editable_table . ' tbody tr\');';
        $jsScript .= 'const data = [];';

        $jsScript .= 'tableRows.forEach(row => {';
        $jsScript .= 'const cells = row.querySelectorAll(\'td\');';
        $jsScript .= 'const rowData = {';

        foreach ($customHeadings as $key => $value) {
            switch ($value) {
                case 'date':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("input[type=\'date\']").value,';
                    break;
                    case 'time':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("input[type=\'time\']").value,';
                    break;
                case 'textContent':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].' . $value . ',';
                    break;
                case 'selectValue':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("select").value,';
                    break;
                // Add other cases as needed for different extraction methods
                  
                default:
                    $jsScript .= '"' . $key . '": "'.$value. '",';
                    // Handle other extraction methods or default behavior
                    break;
            }
        }

        $jsScript .= '};';
        $jsScript .= 'data.push(rowData);';
        $jsScript .= '});';

        $jsScript .= 'const jsonString = JSON.stringify(data);';
        $jsScript .= 'const xhr = new XMLHttpRequest();';
        $jsScript .= 'xhr.open(\'POST\', \'crud.php?table=' . $table . '\', true);';
        $jsScript .= 'xhr.setRequestHeader(\'Content-Type\', \'application/json\');';
        $jsScript .= 'xhr.onreadystatechange = function () {';
        $jsScript .= 'if (xhr.readyState === XMLHttpRequest.DONE) {';
        $jsScript .= 'if (xhr.status === 200) {';
        $jsScript .= 'alert(\'Data sent successfully\'); window.location.href = window.location.href;';
        $jsScript .= 'console.log(\'Data sent successfully:\', xhr.responseText);';
        $jsScript .= '} else {';
        $jsScript .= 'alert("Data sent Failed");';
        $jsScript .= 'console.error(\'Error sending data:\', xhr.statusText);';
        $jsScript .= '}';
        $jsScript .= '}';
        $jsScript .= '};';
        $jsScript .= 'xhr.send(jsonString);';
        $jsScript .= '});';
        $jsScript .= '</script>';

        return $jsScript;
    }
}
?>
