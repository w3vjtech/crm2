<?php
/*
class CrmMail {
    private $to;
    private $subject;
    private $message;
    private $attachments = [];

    public function __construct($to, $subject, $message) {
        $this->to = $to;
        $this->subject = $subject;
        $this->message = $message;
    }

    public function addAttachment($file_path, $file_name = '') {
        $this->attachments[] = ['path' => $file_path, 'name' => $file_name];
    }

    public function sendEmail() {
        $semi_rand = md5(time());
        $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "From: sender@example.com\r\n"; // Replace with sender's email
        $headers .= "Content-Type: multipart/mixed; boundary=\"{$mime_boundary}\"\r\n";

        $message = "--{$mime_boundary}\r\n";
        $message .= "Content-Type: text/html; charset=\"UTF-8\"\r\n";
        $message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
        $message .= $this->message . "\r\n\r\n";

        foreach ($this->attachments as $attachment) {
            if (is_file($attachment['path'])) {
                $file_content = file_get_contents($attachment['path']);
                $file_content = chunk_split(base64_encode($file_content));
                $file_name = $attachment['name'] ?: basename($attachment['path']);
                $file_type = mime_content_type($attachment['path']);

                $message .= "--{$mime_boundary}\r\n";
                $message .= "Content-Type: {$file_type}; name=\"{$file_name}\"\r\n";
                $message .= "Content-Disposition: attachment; filename=\"{$file_name}\"\r\n";
                $message .= "Content-Transfer-Encoding: base64\r\n";
                $message .= "X-Attachment-Id: " . rand(1000, 9999) . "\r\n\r\n";
                $message .= $file_content . "\r\n\r\n";
            }
        }

        $message .= "--{$mime_boundary}--";

        return mail($this->to, $this->subject, $message, $headers);
    }
}

// Usage
$to = "nvj824855@gmail.com";
$subject = "Test Email with Attachments";
$message = "This is a test email with various attachments sent using pure PHP.";

$mail = new CrmMail($to, $subject, $message);

// Add attachments (replace with actual file paths and names)
//$mail->addAttachment("path/to/image.jpg", "image.jpg");
//$mail->addAttachment("path/to/file.pdf", "document.pdf");
//$mail->addAttachment("path/to/excel.xlsx", "data.xlsx");

if ($mail->sendEmail()) {
    echo "Email sent successfully with attachments!";
} else {
    echo "Email sending failed.";
}
?>





<?php
$to = "somebody@example.com, somebodyelse@example.com";
$subject = "HTML email";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p>This email contains HTML Tags!</p>
<table>
<tr>
<th>Firstname</th>
<th>Lastname</th>
</tr>
<tr>
<td>John</td>
<td>Doe</td>
</tr>
</table>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: myboss@example.com' . "\r\n";

mail($to,$subject,$message,$headers);
?>

<?php
*/
// the message
$msg = "First line of text\nSecond line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail("nvj824855@gmail.com","My subject",$msg);
?>