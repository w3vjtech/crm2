<?php
class db {
    private $con;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->con = mysqli_connect('localhost', 'u701799789_hr', 'Wbinfs123456@', 'u701799789_hr');
    }
    public function getConnection() {
        return $this->con;
    }
}
?>
