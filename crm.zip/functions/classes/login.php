<?php

class login {
    private $con;

    public function __construct($con) {
        $this->con = $con;
    }

    public function authenticate($email, $password) {
        $sql = "SELECT * FROM login WHERE user_id = '$email' AND password = '$password'";
        $result = mysqli_query($this->con, $sql);
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            session_start();
            $_SESSION["email"] = $email;
            $_SESSION["state"] = $row['state'];
            $_SESSION["type"] = $row['type'];
            setcookie("email", $email, time() + (86400 * 30), "/"); // Cookie lasts for 30 days
            setcookie("password", $password, time() + (86400 * 30), "/"); // Cookie lasts for 30 days
           
            header("Location: home.php");
            exit();
        } else {
            return "Incorrect username or password";
        }
    }
    
    
    public function autologin($email, $password) {
        
          $sql = "SELECT * FROM login WHERE user_id = '$email' AND password = '$password'";
        $result = mysqli_query($this->con, $sql);
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            session_start();
            $_SESSION["email"] = $email;
            $_SESSION["state"] = $row['state'];
            $_SESSION["type"] = $row['type'];

            header("Location: home.php");
            exit();
        } else {
            return "Incorrect username or password";
        }
        
    }
    
}
?>