<?php
class DropdownGenerator {
    public function generateCustomerNameDropdown($con, $tableName, $columnName,$value='') {
        $options = '';

        $sql = "SELECT DISTINCT $columnName FROM $tableName";
        $result = $con->query($sql);

        if ($result->num_rows > 0) {
            $options = mysqli_fetch_all($result, MYSQLI_ASSOC);

            $select = '<select name="'.$columnName.'" class="form-control form-control-lg">';
              $select .= "<option value='$value'>$value</option>";
            foreach ($options as $option) {
                $customerName = $option[$columnName]; 
                $select .= "<option value='$customerName'>$customerName</option>";
            }
            $select .= '</select>';

            return $select;
        }
         return '';
    }
}
?>
