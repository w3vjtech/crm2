<?php
class ExportButton {
    
    public static function renderButton() {
        return '<button id="'.$export_button.'">Export Data</button>';
    }

    public static function renderScript($customHeadings,$editable_table,$export_button) {
        $jsScript = '<script>';
        $jsScript .= 'document.getElementById("'.$export_button.'").addEventListener("click", function() {';
        $jsScript .= 'const tableRows = document.querySelectorAll(\'#' . $editable_table . ' tbody tr\');';
        $jsScript .= 'const data = [];';
        $jsScript .= 'const customHeadings = ' . json_encode(array_keys($customHeadings)) . ';data.push(customHeadings.join(","));';

        // Loop through customHeadings to construct JavaScript object properties
        $jsScript .= 'tableRows.forEach(row => {';
        $jsScript .= 'const cells = row.querySelectorAll(\'td\');';
        $jsScript .= 'const rowData = {';

        foreach ($customHeadings as $key => $value) {
            
                     switch ($value) {
                case 'date':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("input[type=\'date\']").value,';
                    break;
                    case 'time':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("input[type=\'time\']").value,';
                    break;
                case 'textContent':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].' . $value . ',';
                    break;
                case 'selectValue':
                    $jsScript .= '"' . $key . '": cells[' . array_search($key, array_keys($customHeadings)) . '].querySelector("select").value,';
                    break;
                // Add other cases as needed for different extraction methods
                  
                default:
                    $jsScript .= '"' . $key . '": "'.$value. '",';
                    // Handle other extraction methods or default behavior
                    break;
            }
            
        }

        $jsScript .= '};';
        $jsScript .= 'data.push(Object.values(rowData).map(value => `"${value}"`).join(","));';
        $jsScript .= '});';

        $jsScript .= 'const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");';
        $jsScript .= 'const encodedUri = encodeURI(csvContent);';
        $jsScript .= 'const link = document.createElement("a");';
        $jsScript .= 'link.setAttribute("href", encodedUri);';
        $jsScript .= 'link.setAttribute("download", "data.csv");';
        $jsScript .= 'document.body.appendChild(link);';
        $jsScript .= 'link.click();';
        $jsScript .= 'document.body.removeChild(link);';

        $jsScript .= '});';
        $jsScript .= '</script>';

        return $jsScript;
    }
}

?>