<?php

class TableFilter {
    public static function generateScript($search, $filterCheckbox, $table) {
        return "
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            const input = document.getElementById('$search');
            const checkboxes = document.querySelectorAll('.$filterCheckbox');

            input.addEventListener('input', filterTable);
            checkboxes.forEach(checkbox => checkbox.addEventListener('change', filterTable));

            function filterTable() {
                const filter = input.value.toUpperCase();
                const table = document.querySelector('#$table tbody');
                const rows = table.getElementsByTagName('tr');

                for (let i = 0; i < rows.length; i++) {
                    let shouldDisplay = false;

                    for (let j = 0; j < checkboxes.length; j++) {
                        if (checkboxes[j].checked) {
                            const columnIndex = j;
                            const td = rows[i].getElementsByTagName('td')[columnIndex];
                            if (td) {
                                const txtValue = td.textContent || td.innerText;
                                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                    shouldDisplay = true;
                                    break; 
                                }
                            }
                        }
                    }

                    if (shouldDisplay) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
     
     
   
    const selectAllCheckbox = checkboxes[0];

    function toggleCheckboxes(event) {
      checkboxes.forEach((checkbox) => {
        checkbox.checked = event.target.checked;
      });
    }

    selectAllCheckbox.addEventListener('change', toggleCheckboxes);
  });
</script>";
    }
}

?>
