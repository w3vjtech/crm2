<?php
// Define the BASE_URL constant
define('BASE_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/');

// Start defining a PHP class
class define {

    public function getBaseUrl() {
        return BASE_URL;
    }
}
?>
