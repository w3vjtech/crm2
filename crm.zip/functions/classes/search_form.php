
    
    
    <?php
class search_form {
    public static function generate_search_form($con, $state_access,$list) {
        $form = "
        <form action='' method='get' class='search-form'>
            <div class='d-flex flex-wrap-wrap align-content-center justify-content-flex-start align-items-center w-100 gap-10 py-10'>";

        foreach ($list as $key => $value) {
            switch ($key) {
                case 'date':
                    $form .= "
                    <div>
                        <label class='form-label'>Date:</label>
                        <input type='date' name='date' value='" . (isset($value) ? date("Y-m-d", strtotime($value)) : '') . "' class='form-control form-control-lg' placeholder='Date' required>
                    </div>";
                    break;
                    case 'start_date':
                    $form .= "
                    <div>
                        <label class='form-label'>Start Date:</label>
                        <input type='date' name='start_date' value='" . (isset($value) ? date("Y-m-d", strtotime($value)) : '') . "' class='form-control form-control-lg' placeholder='Date' required>
                    </div>";
                    break;
                    case 'end_date':
                    $form .= "
                    <div>
                        <label class='form-label'>End Date:</label>
                        <input type='date' name='end_date' value='" . (isset($value) ? date("Y-m-d", strtotime($value)) : '') . "' class='form-control form-control-lg' placeholder='Date' required>
                    </div>";
                    break;
                    
                case 'state':
                    $form .= "
                    <div>
                        <label class='form-label'>State:</label>
                        <select name='state' class='form-control form-control-lg'>
                        
                        
                         <option value='" . (isset($value) ? $value : '') . "'>" . (isset($value) ? $value : '') . "</option> 
                        <option value=''>SELECT ALL</option>";
                            
                    $array = explode(',', $state_access);
        
                    $sql = 'SELECT * FROM state';
                    $result = $con->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $name = $row['name'];
                            if (in_array($name, $array)) {
                                $form .= "<option value='" . $name . "'>" . $name . "</option>";
                            }
                        }
                    }

                    $form .= "</select>
                    </div>";
                    break;
                // Add cases for 'month' and 'year' similarly if needed
           case 'month':
    $months = array(
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    );

    $form .= '
        <div>
            <label class="form-label">Month:</label>
            <select name="month" class="form-control form-control-lg">
                <option value="' . (isset($value) ? $value : '') . '">' . (isset($value) ? $value : '') . '</option> <option value="">Select</option>';

    foreach ($months as $name) {
        $form .= '<option value="' . $name . '">' . $name . '</option>';
    }

    $form .= '
            </select>
        </div>';
    break;

    case 'year':
    // Get the current year
    $currentYear = date("Y");
    $years = range($currentYear, 2022);

    $form .= '
        <div>
            <label class="form-label">Year:</label>
            <select name="year" class="form-control form-control-lg">
                <option value="' . (isset($value) ? $value : '') . '">' . (isset($value) ? $value : '') . '</option> <option value="">Select</option>';

    foreach ($years as $name) {
        $form .= '<option value="' . $name . '">' . $name . '</option>';
    }

    $form .= '
            </select>
        </div>';
    break;

                    
   case 'working_status':
    $form .= '
        <div>
            <label class="form-label">Working Status:</label>
            <select name="working_status" class="form-control form-control-lg">
                <option value="' . (isset($value) ? $value : '') . '">' . (isset($value) ? $value : '') . '</option>
                <option value="">SELECT ALL</option>
                <option value="WORKING">WORKING</option>
                <option value="RESIGNED">RESIGNED</option>
                <option value="TERMINATED">TERMINATED</option>
               <option value="NOT RESPONDING">NOT RESPONDING</option>
            </select>
        </div>
    ';
    break;

                    
    case 'vertical_name':
    $form .= '
        <div>
            <label class="form-label">Vertical Name:</label>
            <select name="vertical_name" class="form-control form-control-lg">
                <option value="' . (isset($value) ? $value : '') . '">' . (isset($value) ? $value : 'Select') . '</option>
                <option value="">SELECT ALL</option>
                <option value="WBI">WBI</option>
                <option value="O²">O²</option>
                <option value="Dirtx">Dirtx</option>
                <option value="Cassette">Cassette</option>
            </select>
        </div>
    ';
    break;
 case 'designation':
    $form .= '
        <div>
            <label class="form-label">designation:</label>
            <select name="designation" class="form-control form-control-lg">
                <option value="">Select All</option>';

    $sql = "SELECT DISTINCT designation FROM employee";
    $result = $con->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name = $row["designation"];
            $selected = (isset($designation) && $designation === $name) ? 'selected' : '';
             $form .=  '<option value="' . $name . '" ' . $selected . '>' . $name . '</option>';
        }
    }

    $form .= '
            </select>
        </div>';
    break;
  case 'vendor':
    $form .= '
        <div>
            <label class="form-label">vendor:</label>
            <select name="vendor" class="form-control form-control-lg">
                <option value="">Select</option>';

    $sql = "SELECT DISTINCT name FROM vendor";
    $result = $con->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name = $row["name"];
            $selected = (isset($vendor) && $vendor === $name) ? 'selected' : '';
             $form .=  '<option value="' . $name . '" ' . $selected . '>' . $name . '</option>';
        }
    }

    $form .= '
            </select>
        </div>';
    break;

                    
                default:
                    // Handle other cases if needed
                    break;
            }
        }

        $form .= "
                <div class='search-box'>
                    <input type='submit' class='search' value='Search'>
                </div>
            </div>
        </form>";

        return $form;
    }
}
?>
