
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  

    <link rel="apple-touch-icon" type="image/png" href="https://cpwebassets.codepen.io/assets/favicon/apple-touch-icon-5ae1a0698dcc2402e9712f7d01ed509a57814f994c660df9f7a952f3060705ee.png" />

    <meta name="apple-mobile-web-app-title" content="CodePen">

    <link rel="shortcut icon" type="image/x-icon" href="https://cpwebassets.codepen.io/assets/favicon/favicon-aec34940fbc1a6e787974dcd360f2c6b63348d4b1f4e06c77743096d55480f33.ico" />

    <link rel="mask-icon" type="image/x-icon" href="https://cpwebassets.codepen.io/assets/favicon/logo-pin-b4b4269c16397ad2f0f7a01bcdf513a1994f4c94b8af2f191c09eb0d601762b1.svg" color="#111" />



  
    <script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-2c7831bb44f98c1391d6a4ffda0e1fd302503391ca806e7fcc7b9b87197aec26.js"></script>


  <title>CodePen - Excel To Web Form</title>

    <link rel="canonical" href="https://codepen.io/livefiredev/pen/oNqmzMo">
  
  
  
  
<style>
#myDemoTextArea {
  width: 200px;
  height: 20px;
}

#table_container {
  max-width: 100%;
  width: 450px;
  max-height: 500px;
  overflow-y: scroll;
  padding: 10px;
}

#tableAsJSON {
  width: 450px;
  height: 500px;
}

table.boostrap4_table_head_dark_striped_rounded_compact {
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  text-align: left;
  box-sizing: border-box;
  border-collapse: collapse;
  width: 100%;
  margin-bottom: 1rem;
  background-color: transparent;
}

table.boostrap4_table_head_dark_striped_rounded_compact thead th {
  font-size: 1rem;
  line-height: 1.5;
  border-collapse: collapse;
  box-sizing: border-box;
  text-align: inherit;
  padding: 0.3rem;
  vertical-align: bottom;
  border-bottom: 2px solid #dee2e6;
  color: #fff;
  background-color: #212529;
  border-color: #32383e;
}

table.boostrap4_table_head_dark_striped_rounded_compact td {
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  text-align: left;
  border-collapse: collapse;
  box-sizing: border-box;
  padding: 0.3rem;
  vertical-align: top;
  box-shadow: 0 0 1px #212529;
}

table.boostrap4_table_head_dark_striped_rounded_compact
  tbody
  tr:nth-of-type(odd) {
  background-color: rgba(0, 0, 0, 0.05);
}

table.boostrap4_table_head_dark_striped_rounded_compact th:first-of-type {
  border-top-left-radius: 10px;
}

table.boostrap4_table_head_dark_striped_rounded_compact th:last-of-type {
  border-top-right-radius: 10px;
}

table.boostrap4_table_head_dark_striped_rounded_compact
  tr:last-of-type
  td:first-of-type {
  border-bottom-left-radius: 10px;
}

table.boostrap4_table_head_dark_striped_rounded_compact
  tr:last-of-type
  td:last-of-type {
  border-bottom-right-radius: 10px;
}
</style>

  <script>
  window.console = window.console || function(t) {};
</script>

  
  
</head>

<body translate="no">
  <textarea id="myDemoTextArea"></textarea>
<div>
  <a href="#" id="clear_link">Clear</a>
</div>
<div id="table_container"></div>
<textarea id="tableAsJSON"></textarea>
  
      <script id="rendered-js" >
let constructTableFromPastedInput = pastedInput => {
  let rawRows = pastedInput.split("\n");
  let headRow = "";
  let bodyRows = [];
  rawRows.forEach((rawRow, idx) => {
    let rawRowArray = rawRow.split("\t");
    if (idx == 0) {
      headRow = `<tr><th>${rawRowArray.join("</th><th>")}</th></tr>`;
    } else {
      bodyRows.push(`<tr><td>${rawRowArray.join("</td><td>")}</td></tr>`);
    }
  });
  return `
                <table class="boostrap4_table_head_dark_striped_rounded_compact">
                    <thead>
                        ${headRow}
                    </thead>
                    <tbody>
                        ${bodyRows.join("")}
                    </tbody>
                </table>
            `;
};

let constructJSONFromPastedInput = pastedInput => {
  let rawRows = pastedInput.split("\n");
  let headersArray = rawRows[0].split("\t");
  let output = [];
  rawRows.forEach((rawRow, idx) => {
    if (idx > 0) {
      let rowObject = {};
      let values = rawRow.split("\t");
      headersArray.forEach((header, idx) => {
        rowObject[header] = values[idx];
      });
      output.push(rowObject);
    }
  });
  return output;
};

const theTextArea = document.getElementById("myDemoTextArea");

const inputHandler = function (e) {
  let inputText = e.target.value;
  let tableHTML = constructTableFromPastedInput(inputText);
  let tableAsJson = constructJSONFromPastedInput(inputText);
  let prettyJSON = JSON.stringify(tableAsJson, null, 2);
  console.log(prettyJSON);
  document.getElementById("table_container").innerHTML = tableHTML;
  document.getElementById("table_container").style.display = "block";
  document.getElementById("tableAsJSON").value = prettyJSON;
};

theTextArea.addEventListener("input", inputHandler);

document.getElementById("clear_link").addEventListener("click", () => {
  document.getElementById("myDemoTextArea").value = "";
  document.getElementById("table_container").innerHTML = "";
  document.getElementById("table_container").style.display = "none";
  document.getElementById("tableAsJSON").value = "";
});

    </script>

  
</body>

</html>
