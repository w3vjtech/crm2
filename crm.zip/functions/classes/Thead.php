<?php
class Thead {
    public static function generateThead($filterCheckbox, $customHeadings) {
        $thead = '<thead>
            <tr>
                    <input type="checkbox" class="filterCheckbox" checked> Select All
                ';

        $isFirst = true;
         $secondAdded = false;
        foreach ($customHeadings as $columnName => $contentType) {
            $classes = [];

            if ($isFirst) {
                $classes[] = 'd-none';
            }
            if (!$isFirst) {
                $check_box = '<input type="checkbox" class="filterCheckbox" checked>';
            }
             if (!$isFirst && !$secondAdded) {
                $classes[] = 'position-sticky';
                $classes[] = 'l-0';
                $classes[] = 'z-5';
                $secondAdded = true;
            }

            $thead .= '<th class="' . implode(' ', $classes) . '">
                    <div class="d-flex gap-7  justify-content-flex-start align-items-flex-start align-content-flex-start flex-direction-row">
                      
                      
                      <div>'.$check_box.'</div> <div> <p class="text-left fs-15"> ' . str_replace('_', ' ', $columnName) . '  </p></div> 
                    </div>
                </th>';

            $isFirst = false;
        }

        $thead .= '</tr></thead>';

        return $thead;
    }
}

?>