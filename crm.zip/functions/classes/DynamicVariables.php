<?php
class DynamicVariables {
    // Constructor to create variables dynamically from $_GET
    public function __construct() {
        foreach ($_GET as $key => $value) {
            // Create dynamic properties directly and set them in the class
            ${$key} = htmlspecialchars($value);
            $this->{$key} = ${$key};
        }
        
        // Return $this for method chaining
        return $this;
    }
}

?>