<?php
class BorderColorUpdater {
    public static function generateScript() {
        $script = '
        <script>
        function updateBorderColor(selectElement) {
          const selectedValue = selectElement.value.toLowerCase();
          let borderColor = "";

          switch (selectedValue) {
            case "APPROVED":
            case "PAID":
              borderColor = "green";
              break;
            case "PENDING":
            case "UNPAID":
              borderColor = "red";
              break;
            default:
              borderColor = "";
              break;
          }

          selectElement.style.borderColor = borderColor;
        }
        </script>';

        return $script;
    }
}
?>