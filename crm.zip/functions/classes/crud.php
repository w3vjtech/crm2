<?php

class crud {
    private $table;
    private $con;

    public function __construct($table, $con) {
        $this->table = $table;
        $this->con = $con;
    }

    public function create($data) {
        $fields = implode(',', array_keys($data));
        $values = "'" . implode("','", $data) . "'";
        $sql = "INSERT INTO {$this->table} ($fields) VALUES ($values)";
        
        if (mysqli_query($this->con, $sql)) {
            return ['status' => 'success', 'message' => 'Record created successfully'];
        } else {
            return ['status' => 'error', 'message' => 'Record creation failed'];
        }
    }

    public function read($id = null) {
        $where = $id ? "WHERE id = $id" : '';
        $sql = "SELECT * FROM {$this->table} $where";
        $result = mysqli_query($this->con, $sql);
        
        if ($result) {
            $data = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
            return $data;
        } else {
            return [];
        }
    }

    public function update($id, $data) {
        $updates = [];
        foreach ($data as $key => $value) {
            $updates[] = "$key = '$value'";
        }
        $updates = implode(',', $updates);
        $sql = "UPDATE {$this->table} SET $updates WHERE id = $id";
        
        if (mysqli_query($this->con, $sql)) {
            return ['status' => 'success', 'message' => 'Record updated successfully'];
        } else {
            return ['status' => 'error', 'message' => 'Record update failed'];
        }
    }

    public function delete($id) {
        $sql = "DELETE FROM {$this->table} WHERE id = $id";
        
        if (mysqli_query($this->con, $sql)) {
            return ['status' => 'success', 'message' => 'Record deleted successfully'];
        } else {
            return ['status' => 'error', 'message' => 'Record deletion failed'];
        }
    }
}
?>