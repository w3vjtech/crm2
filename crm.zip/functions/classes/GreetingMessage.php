<?php
class GreetingMessage {
    private $current_time;

    public function __construct() {
        date_default_timezone_set('Asia/Kolkata');
        $this->current_time = date('H');
    }

    public function getGreeting() {
        if ($this->current_time >= 5 && $this->current_time < 12) {
            return "Good morning, ";
        } elseif ($this->current_time >= 12 && $this->current_time < 16) {
            return "Good afternoon, ";
        } elseif ($this->current_time >= 16 && $this->current_time < 20) {
            return "Good evening, ";
        } else {
            return "Good night, ";
        }
    }
}
?>
