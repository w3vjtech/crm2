
        <script>
        document.addEventListener('DOMContentLoaded', function () {
            const input = document.getElementById('$search');
            const checkboxes = document.querySelectorAll('.$filterCheckbox');

            input.addEventListener('input', filterTable);
            checkboxes.forEach(checkbox => checkbox.addEventListener('change', filterTable));

            function filterTable() {
                const filter = input.value.toUpperCase();
                const table = document.querySelector('#$table tbody');
                const rows = table.getElementsByTagName('tr');

                for (let i = 1; i < rows.length; i++) {
                    let shouldDisplay = false;

                    for (let j = 0; j < checkboxes.length; j++) {
                        if (checkboxes[j].checked) {
                            const columnIndex = j;
                            const td = rows[i].getElementsByTagName('td')[columnIndex];
                            if (td) {
                                const txtValue = td.textContent || td.innerText;
                                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                                    shouldDisplay = true;
                                    break; 
                                }
                            }
                        }
                    }

                    if (shouldDisplay) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });
        </script>

<!DOCTYPE html>
<html>
<head>
    <title>Table Filter Example</title>
</head>
<body>
    <input type='text' id='searchInput' placeholder='Search...'>
    <input type='checkbox' class='filterCheckbox'> Option 1
    <input type='checkbox' class='filterCheckbox'> Option 2

    <table id='dataTable'>
        <thead>
            <tr>
                <th>Column 1</th>
                <th>Column 2</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Data 1</td>
                <td>Data A</td>
            </tr>
            <tr>
                <td>Data 2</td>
                <td>Data B</td>
            </tr>
            <!-- Additional table rows -->
        </tbody>
    </table>
</body>
</html>