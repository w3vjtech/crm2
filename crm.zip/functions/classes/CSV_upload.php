<?php
class CSV_upload {
    private $con;

    public function __construct($con) {
        $this->con = $con;
    }

    public function processCSV($tableName, $file) {
        $csvFilePath = $file['tmp_name'];

        if (file_exists($csvFilePath) && is_readable($csvFilePath)) {
            $handle = fopen($csvFilePath, "r");
            if ($handle !== false) {
                $fieldNames = fgetcsv($handle); // Get the field names from the first row

                $describeSql = "DESCRIBE $tableName";
                $result = $this->con->query($describeSql);

                if ($result && $result->num_rows > 0) {
                    $existingColumns = array();
                    while ($row = $result->fetch_assoc()) {
                        $existingColumns[] = $row['Field'];
                    }

                    $nonExistentColumns = array_diff($fieldNames, $existingColumns);
                    if (!empty($nonExistentColumns)) {
                        echo "The following column(s) do not exist in the table: " . implode(', ', $nonExistentColumns);
                        return false;
                    } else {
                        fseek($handle, 0);
                        fgetcsv($handle); // Skip the header row as it was already read

                        while ($rowData = fgetcsv($handle)) {
                            $sanitizedData = array_map('htmlspecialchars', $rowData);
                            $dataValues = array_map([$this->con, 'real_escape_string'], $sanitizedData);
                            $dataValuesString = "'" . implode("', '", $dataValues) . "'";
                            $sql = "INSERT INTO $tableName (" . implode(', ', $fieldNames) . ") VALUES ($dataValuesString)";

                            $insertResult = $this->con->query($sql);

                            if ($insertResult === false) {
                                echo "Error executing SQL query: " . $this->con->error;
                                return false;
                            }
                        }
                        fclose($handle);
                        return true;
                    }
                } else {
                    echo "No results found for table description.";
                    return false;
                }
            } else {
                echo "Failed to open the CSV file.";
                return false;
            }
        } else {
            echo "CSV file does not exist or is not readable.";
            return false;
        }
    }
}
?>