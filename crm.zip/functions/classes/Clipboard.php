<?php
class Clipboard {
    public function generateScript($clipboard,$captureButton) {
        $script = <<<EOD
<script>
document.getElementById('$captureButton').addEventListener('click', function() {
    var scale = 3;

    html2canvas(document.getElementById('$clipboard'), {
        scale: scale
    }).then(function(canvas) {
        canvas.toBlob(function(blob) {
            var item = new ClipboardItem({ "image/png": blob });
            navigator.clipboard.write([item]).then(function() {
                alert('Copied to Clipboard!');
            }).catch(function(err) {
                console.error('Unable to copy image to clipboard:', err);
            });
        });
    });
});
</script>
EOD;
        return $script;
    }
}
?>