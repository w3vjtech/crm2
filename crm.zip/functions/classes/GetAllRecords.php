<?php
class GetAllRecords
{
    private $con;

    // Constructor to initialize the database connection
    public function __construct($con)
    {
        $this->con = $con;
    }

    // Fetch all records from the wbi_escalation_matrix table
    public function getAllRecords()
    {
        $sql = "SELECT * FROM wbi_escalation_matrix";
        $result = $this->con->query($sql);

        $records = array();

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
        }

        return $records;
    }
}    
    ?>