<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];

 $start_date= $_GET['start_date'];
 
 $end_date= $_GET['end_date'];
 
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body>

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
 <div class="position-sticky l-0 z-4 bg-white">
  <h6 class="card-title m-0">ZM-WORK-BOOK</h6>
  <?php
$list = ['start_date'=>$start_date, 'end_date'=>$end_date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    <div id='clipboard'>
    <?php
//if($state!="" AND $start_date!="" AND $end_date!=""){    
?>       

<?php
// Function to retrieve and display data
function fetchData($state, $type, $con) {
    // Sanitize user inputs to prevent SQL injection (you should use prepared statements)
    $state = $con->real_escape_string($state);
    $type = $con->real_escape_string($type);

    // SQL query
    $sql = "SELECT name FROM login WHERE state LIKE '%$state%' AND type = '$type'";

    // Execute the query
    $result = $con->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Loop through the results and echo the names
        while ($row = $result->fetch_assoc()) {
            return $row["name"];
        }
    } else {
       
    }
}





$states = explode(",", $state_access);
$stateList = "'" . implode("','", $states) . "'";


$sql = "SELECT date, state,am10_remarks,no_of_call_attended FROM tsm_work_book
        WHERE state IN ($stateList) AND STR_TO_DATE(date, '%d-%m-%Y') BETWEEN '$start_date' AND '$end_date'";
$formattedOutput = [];
// Execute the SQL query
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $date = $row['date'];
    $state = $row['state'];
    
    $rm_name=fetchData($state, 'RM', $con); 
    
      $formattedOutput[$date][$state]['am10_remarks'] += 1;
     
    if ($row['am10_remarks'] !== 'LEAVE' && $row['am10_remarks'] !== '0') {
      $am10_remarks[$date][$state] += 1;
      $total_am10_remarks[$date] += 1;
      
      $total_am10_remarks[$state] += 1;
      
       $grand_total_am10_remarks += 1;
       
       $rm_total[$rm_name] += 1;
       
    }
    
     if ($row['no_of_call_attended'] !== 'LEAVE' && $row['no_of_call_attended'] !== '0' && $row['no_of_call_attended'] !== 'NO CALL' && $row['no_of_call_attended'] !== 'OTHERS') {
      $no_of_call_attended[$date][$state] += $row['no_of_call_attended'];
   
      $total_no_of_call_attended[$date] += $row['no_of_call_attended'];
      $total_no_of_call_attended[$state] += $row['no_of_call_attended'];
       $grand_total_no_of_call_attended += $row['no_of_call_attended'];
       
       $rm_total_no_of_call_attended[$rm_name] += $row['no_of_call_attended'];
    }
    
    
}



// Print the formatted output as an HTML table
echo '<table border="1">';
echo '<tr>';

$count = 1; // Initialize count outside the loop

/*foreach ($rm_total as $key => $value) {
    echo '<td> RM ' . $count .'</td>';
    $count++; // Increment count after displaying each value
}
*/
echo '</tr>';




echo '<tr>';
foreach ($rm_total as $key => $value) {
    echo '<td>';
    echo "Name: $key, <br> Total Presents: $value<br>";
    echo "Total Call Attend: ".$rm_total_no_of_call_attended[$key];
    echo'</td>';
}
echo '</tr>';

echo '</table>';

echo '<div class="d-flex gap-30 Euclid-Circular-B-SemiBold py-30">';
echo '<div>';
echo 'Grand Total Presents : '.$grand_total_am10_remarks;
echo '</div><div>';
echo  'Grand Total Call Attend : '.$grand_total_no_of_call_attended;
echo '</div></div>';
?>
   

</div>
      
     
  
  <div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
 <button id="captureButton">Copy to Clipboard</button>
  </div>
<?php
//}
?>

 
    <script>
        document.getElementById('captureButton').addEventListener('click', function() {
            html2canvas(document.getElementById('clipboard')).then(function(canvas) {
                  canvas.toBlob(function(blob) {
                    var item = new ClipboardItem({ "image/png": blob });
                    navigator.clipboard.write([item]);
                });
            });
        });
    </script>

  
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>  
    </div>
    
</div>
</section>


</body>

</html>