<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
 $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='leave_request';

$customHeadings = [
    "id" => 'textContent',
    "wbi_engineer" => 'textContent', 
    "start_date" => 'date',
    "end_date" => 'date',
    "tsm_permission" => 'selectValue',
    "hr_permission" => 'selectValue',
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body class="layout-1" data-luno="theme-black">

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
 
  <div class="position-sticky l-0 z-4 bg-white">
<h6 class="card-title m-0">Engineers leave request</h6>

   <?php
$list = ['state'=>$state,'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

</div>

    <?php
if($state!="" AND $date!=""){    
?>       


<div id="clipboard">
    <input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
   <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM leave_request WHERE state = '$state' AND date = '$date'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td contenteditable>  <?php echo $row["wbi_engineer"]; ?> </td>

<td>   
 <input type="date" name="start_date" value="<?php echo $row["start_date"]; ?>" class="form-control form-control-lg" placeholder="start_date">
</td>


<td>   
 <input type="date" name="end_date" value="<?php echo $row["end_date"]; ?>" class="form-control form-control-lg" placeholder="end_date">
</td>


<td>
      <select onchange="updateBorderColor(this)">
           <option value="<?php echo $row["tsm_permission"]; ?>">  <?php echo $row["tsm_permission"]; ?></option>
 <?php if($type=="TSM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>
  <td>
      <select onchange="updateBorderColor(this)">
           <option value="<?php echo $row["hr_permission"]; ?>"> <?php echo $row["hr_permission"]; ?> </option>
 <?php if($type=="HR" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>

        </tr>
        
        <?php
    }
}


?>

</tbody>
    </table>
   </div>
 
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if( $type != "TSM" && $type != "RM" && $type != "ZM" && $type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
  </div>
  
<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
         <td class='d-none'></td>

<td contenteditable>  </td>

<td>   
 <input type="date" name="start_date" value="" class="form-control form-control-lg" placeholder="start_date">
</td>


<td>   
 <input type="date" name="end_date" value="" class="form-control form-control-lg" placeholder="end_date">
</td>
<td>
      <select onchange="updateBorderColor(this)">
 <?php if($type=="TSM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>
  <td>
      <select onchange="updateBorderColor(this)">
 <?php if($type=="HR" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>
      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>


      
    
    <?php
$customHeadings["state"] = $state;
$customHeadings["date"] = $date;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>

                 
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

</body>

</html>