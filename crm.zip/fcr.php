<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();



$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
 $table='fcr';

$customHeadings = [
    
   "id" => 'textContent',
   "engineer_name" => 'textContent', 
   "client_name" => 'selectValue',
   "number_of_fcr_submitted" => 'textContent',
   "submitted_to_whom" => 'textContent',
   "which_month_fcr" => 'selectValue',
   "submitted_date" =>  'date',
   "submitted_via" => 'selectValue',
   "courier_name_docket_number" =>'textContent',

];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 
 ?>

</head>

<body class="layout-1" data-luno="theme-black">

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        <div class="position-sticky l-0 z-4 bg-white">
   <h6 class="card-title m-0">FCR</h6>
    <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
        


    <?php
if($state!=""){    
?>       

<div id="clipboard">
    <input type="text" class="position-sticky l-0 z-4 bg-white" id="table-search" placeholder="Search..." >
    
    
   <table id="editable-table">
 
  <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
     
        <tbody>
   

<?php
$sql = "SELECT * FROM fcr WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable>  <?php echo $row["engineer_name"]; ?> </td>
<td>
 <select>
    <option value="<?php echo $row["client_name"]; ?>"> <?php echo $row["client_name"]; ?></option>
<option value="select">select</option>
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'customer_name'); ?>
  </select> 
 </td>
<td contenteditable>  <?php echo $row["number_of_fcr_submitted"]; ?> </td>
<td contenteditable>  <?php echo $row["submitted_to_whom"]; ?> </td>
<td > 
<?php $which_month_fcr=$row["which_month_fcr"]; ?>
<select name="month" class="form-control form-control-lg">
    
    <option value="<?php echo isset($which_month_fcr) ? $which_month_fcr : ''; ?>"> <?php echo isset($which_month_fcr) ? $which_month_fcr : 'Select'; ?></option>
    <?php
    $months = array(
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    );

    foreach ($months as $name) {
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
    ?>
</select>
</td>
<td>   
 <input type="date" name="submitted_date" value="<?php echo $row["submitted_date"]; ?>" class="form-control form-control-lg" placeholder="submitted_date">
</td>

<td>
 <select>
    <option value="<?php echo $row["submitted_via"]; ?>"> <?php echo $row["submitted_via"]; ?></option>
<option value="select">select</option>
<option value="Courier">Courier</option>
<option value="By hand">By hand</option>
  </select> 
 </td>

<td contenteditable>  <?php echo $row["courier_name_docket_number"]; ?> </td>
        </tr>
        
        <?php
    }
}else{
     
$sql = "SELECT * FROM employee WHERE designation = 'SERVICE ENGINEERS' AND working_status='WORKING' AND vertical_name='WBI'";
if (isset($state)) {
    $sql .= " AND state = '$state'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        ?>
           <tr>
           
<td class='d-none'></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable>  <?php echo $row["name"]; ?> </td>
<td>
 <select>
<option value="select">select</option>
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'customer_name'); ?>
  </select> 
 </td>
<td contenteditable></td>
<td contenteditable></td>
<td > 
<?php $which_month_fcr=$row["which_month_fcr"]; ?>
<select name="month" class="form-control form-control-lg">
    
    <option value="<?php echo isset($which_month_fcr) ? $which_month_fcr : ''; ?>"> <?php echo isset($which_month_fcr) ? $which_month_fcr : 'Select'; ?></option>
    <?php
    $months = array(
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    );

    foreach ($months as $name) {
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
    ?>
</select>
</td>
<td>   
 <input type="date" name="submitted_date" value="" class="form-control form-control-lg" placeholder="submitted_date">
</td>

<td>
 <select>
<option value="select">select</option>
<option value="Courier">Courier</option>
<option value="By hand">By hand</option>
  </select> 
 </td>

<td contenteditable></td>
        </tr>

        <?php
    }
} 
    
}

?>

</tbody>
    </table>
</div>


<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "TSM" && $type != "RM" &&  $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>

</div>





<?php
}
?>


            
           
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           
<td class='d-none'></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable>   </td>
<td>
 <select>
  <option value="select">select</option>
<?php
$sql = "SELECT DISTINCT customer_name FROM customer_escalation_matrix";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $customer_name=$row["customer_name"];
echo'<option value="'.$customer_name.'">'.$customer_name.'</option>';
    }
} 
?>
  </select> 
 </td>

<td contenteditable>   </td>
<td contenteditable>   </td>
<td > 
<select name="month" class="form-control form-control-lg">
<option value="select">select</option>
    <?php
    $months = array(
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    );

    foreach ($months as $name) {
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
    ?>
</select>
</td>
<td><input type="date" value=""> </td>
<td> 
<select>
<option value="select">select</option>
<option value="Courier">Courier</option>
<option value="By hand">By hand</option>
</select>
</td>
<td contenteditable>   </td>




      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>
<?php

$customHeadings["state"] = $state;
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;


$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>




                
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>

</body>

</html>