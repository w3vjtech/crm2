<?php
$con = mysqli_connect('localhost', 'u701799789_hr', 'Wbinfs123456@', 'u701799789_hr');
?>
