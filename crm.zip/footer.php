  
  
    <!--footer>
      <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
        <p class="col-md-4 mb-0 text-muted">© 2023 <a href="" target="_blank" title="ThemeMakker Infotech LLP">WBI</a>, All Rights Reserved.</p>
        <a href="index.html#" class="col-md-4 d-flex align-items-center justify-content-center my-3 my-lg-0 me-lg-auto">
        
        </a>
      </div>
    </footer -->

  <script>
  const inputElements = document.querySelectorAll("input[type='text']");

  inputElements.forEach(function(inputElement) {
    inputElement.addEventListener('input', function(event) {
      const currentInput = event.target.value;
      const uppercaseInput = currentInput.toUpperCase();
      event.target.value = uppercaseInput;
    });
  });
  
  

  const dateInputs = document.querySelectorAll("input[type='date']");

  dateInputs.forEach(function(dateInput) {
    dateInput.setAttribute('min', '2022-01-01');
  });
</script>


  <style>

ul.dtr-details {
    list-style: none;
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: flex-start;
    gap: 20px;
}

.table.dataTable .dtr-details li {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 30px;
    border-bottom: 1px solid;
    width: 100%;
}

.table.dataTable .dtr-details li span {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    width: 50%;
    text-align: left;
}

html {
text-transform: capitalize;
}
  </style>