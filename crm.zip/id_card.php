<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='id_card';

$customHeadings = [
    "id" => 'textContent',
    "wbi_ce_name" => 'textContent', 
    "location" => 'textContent',
    "dob" => 'date',
    "blood_group" => 'textContent',
    "wbi_id" => 'textContent',
    "card_expiry_date" => 'date',
    "address" => 'textContent',
    "pincode" => 'textContent',
    "contact_number" => 'textContent',
    "email_id" => 'textContent',
    "softcopy_status" => 'selectValue',
    "hardcopy_status" => 'selectValue',
    "id_card_status" => 'selectValue',
    "issued_by" => 'textContent',
    "courier_pod" => 'textContent',
    "delivery_status" => 'selectValue',
];
        
    


    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>
<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>

</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>


<div class="position-sticky l-0 z-4 bg-white">
     <h6  class="pt-5">ID Card</h6>
 
   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    
    <?php
if($state!="" AND $month!="" AND $year!=""){    
?>      

<div id="clipboard">
<div>
    
    <?php
    $sql = "SELECT COUNT(*) as total_rows FROM id_card";

$result = $con->query($sql);
if ($result->num_rows > 0) {
     $row = $result->fetch_assoc(); 
     ?>
        <p>Total ID Cards: <?php echo $row["total_rows"]; ?> </p> 
<?php
}
?>
</div>


<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
         <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM id_card WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable><?php echo $row["wbi_ce_name"]; ?></td>
<td contenteditable><?php echo $row["location"]; ?></td>
<td><input type="date" value="<?php echo $row["dob"]; ?>"></td>
<td contenteditable><?php echo $row["blood_group"]; ?></td>
<td contenteditable><?php echo $row["wbi_id"]; ?></td>
<td><input type="date" value="<?php echo $row["card_expiry_date"]; ?>"></td>
<td contenteditable><?php echo $row["address"]; ?></td>
<td contenteditable><?php echo $row["pincode"]; ?></td>
<td contenteditable><?php echo $row["contact_number"]; ?></td>
<td contenteditable class='email'><?php echo $row["email_id"]; ?></td>

<td>
 <select>
    <option value="<?php echo $row["softcopy_status"]; ?>"> <?php echo $row["softcopy_status"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td>
  <select>
    <option value="<?php echo $row["hardcopy_status"]; ?>"> <?php echo $row["hardcopy_status"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
    <option value="<?php echo $row["id_card_status"]; ?>"> <?php echo $row["id_card_status"]; ?></option>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
  </select>
</td>

<td contenteditable>  <?php echo $row["issued_by"]; ?> </td>

<td contenteditable>  <?php echo $row["courier_pod"]; ?> </td>


<td>
  <select>
    <option value="<?php echo $row["delivery_status"]; ?>"> <?php echo $row["delivery_status"]; ?></option>
<option value="select">select</option>
<option value="RECEIVED">RECEIVED</option>
<option value="NOT RECEIVED">NOT RECEIVED</option>
  </select>
</td>


        </tr>

        <?php
    }
}
?>
    

</tbody>
    </table>
</div>

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>

</div>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           
<td class='d-none'></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable></td>
<td contenteditable></td>
<td><input type="date" value=""></td>
<td contenteditable></td>
<td contenteditable></td>
<td><input type="date" value=""></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable class='email'></td>

<td>
 <select>
  
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td>
  <select>
   
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
   
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
  </select>
</td>

<td contenteditable></td>
<td contenteditable></td>
<td>
  <select>
<option value="select">select</option>
<option value="RECEIVED">RECEIVED</option>
<option value="NOT RECEIVED">NOT RECEIVED</option>
  </select>
</td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>





<?php
}
?>

        
        <?php

    $customHeadings["state"] = $state;
    $customHeadings["month"] = $month;
    $customHeadings["year"] = $year;
 
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>
       

  
        
    </div>
    <div class='footer'>
         <?php include'footer.php'; ?>
    </div>
    
</div>
</section>

</body>

</html>