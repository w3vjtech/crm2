<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='business_management';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 $client_name=$_GET['client_name'];
 $state=$_GET['state'];
 ?>

</head>

<body>

<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
    
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">Business Management</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
      
<div>
    
    <style>
        table img {
    height: 50px;
}
    </style>
    
    <table>
    <tr>
        		
        <th>company_logo</th> <th>party</th> <th>code</th>
    </tr>
   <?php

$sql = "SELECT * FROM business_management";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        
        ?>
        <tr>
            <td>
                <img src='business_management/logo/<?php echo $row["company_logo"]; ?>' />
            </td>
            <td>
                <?php echo $row["party"]; ?>
            </td>
            <td>
                <?php echo $row["code"]; ?>
            </td>
    </tr>
    <?php
  }
} 
?>
</table> 
		
</div>


              </div>
            </div>         
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>

</body>

</html>