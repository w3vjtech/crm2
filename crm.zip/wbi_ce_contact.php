<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='wbi_ce_contact';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $edit=$_GET['edit'];
 
 $customHeadings = [
    "id" => 'textContent',
    "name" => 'textContent', 
    "employee_id" => 'textContent',
    "contact_number" => 'textContent',
    "email_id" => 'textContent',
    "district" => 'textContent',
    "pincode" => 'textContent',
];

    
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 
</head>

<body >


<section>
    

<div class='sidebar'>
<?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
       
                    
<div class="position-sticky l-0 z-4 bg-white">
  <h6 class="card-title m-0"> WBI CE CONTACT </h6>
   <?php
$list = ['state'=>$state]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    <?php
if($state!=""){    
?>       


<div id="clipboard">
    <input type="text" id="table-search" placeholder="Search..." >
   <table id="editable-table">
        <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM employee WHERE designation = 'SERVICE ENGINEERS' AND state='$state' AND working_status='WORKING'";


$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
     <td><?php echo $row["name"]; ?></td>
     <td><?php echo $row["employee_id"]; ?></td>
     <td><?php echo $row["contact_number"]; ?></td>
     <td class='email'><?php echo $row["email_id"]; ?></td>  
     <td><?php echo $row["district"]; ?></td>   
     <td><?php echo $row["pincode"]; ?></td>   
    </tr>
        <?php
    }
  }
?>

</tbody>
    </table> 
<button id="captureButton">Copy to Clipboard</button>


<?php
}
?>
</div>



      
            <?php
$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>