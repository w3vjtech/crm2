<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();



$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>

 <?php
 include'head.php';
 ?>
</head>

<body >



<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
         

<div class="position-sticky l-0 z-4 bg-white">
    
   <h6 class="card-title m-0">Office Attendance</h6> 
<?php
$list = ['month'=>$month, 'year'=>$year ]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

</div>

    <?php
if($month!="" AND $year!=""){    
?>       
   <table id="editable-table">
        <thead>
        
            <tr>

<th class='position-sticky l-0 z-4 bg-white'>name</th>
<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
<th>7</th>
<th>8</th>
<th>9</th>
<th>10</th>
<th>11</th>
<th>12</th>
<th>13</th>
<th>14</th>
<th>15</th>
<th>16</th>
<th>17</th>
<th>18</th>
<th>19</th>
<th>20</th>
<th>21</th>
<th>22</th>
<th>23</th>
<th>24</th>
<th>25</th>
<th>26</th>
<th>27</th>
<th>28</th>
<th>29</th>
<th>30</th>
<th>31</th>
<th>total Leave</th>
<th>total Presents</th>
            </tr>
        </thead>
        <tbody>
  
<?php

$currentDateString = date('Y-m-d');

$sql = "SELECT * FROM office_attendance WHERE  month = '$month' AND year = '$year'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class='position-sticky l-0 z-4 bg-white' contenteditable>  <?php echo $row["name"]; ?> </td>
<?php
$no_month=date('m', strtotime($month));
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $no_month, $year);

$noCount = 0;
$total = 0;

  for ($day = 1; $day <= 31; $day++) {
    $name = $row["id"] . "date" . $day;
    $value =$row["date" .$day];
   $numbers = explode(',', $value);
   
  $totalOfDay = array_sum(array_map('floatval', $numbers));
   
    $dateString = "$year-$no_month-$day";
    $dayOfWeek = date('N', strtotime($dateString)); // 1 (Monday) to 7 (Sunday)
    
    
foreach ($numbers as $number) {
    if (strtotime($dateString) <= strtotime($currentDateString) && $number !== '0.5' && $dayOfWeek != 7) {
        $noCount += 0.5;
    }
}



 ?>
    <td>
        
    <input type="checkbox" name="<?php echo $name; ?>" value="0.5" class="checkmark-checkbox" <?php if ($numbers[0] === '0.5') echo "checked"; ?> /> 
    <input type="checkbox" name="<?php echo $name; ?>" value="0.5" class="checkmark-checkbox" <?php if ($numbers[1] === '0.5')  echo "checked"; ?> />
    
    </td>
    
    <?php
    $total += $totalOfDay;
  }
  ?>
  
<td> <?php  echo $noCount; ?> </td>
<td> <?php  echo $total;  ?> </td>
</tr>
        
        <?php
    }
    
}else{
    


    
$sql = "SELECT * FROM employee WHERE designation != 'SERVICE ENGINEERS' AND vertical_name='WBI' AND working_status='WORKING'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
       
        ?>
          <tr>
           
<td class='d-none'></td>
<td class='position-sticky l-0 z-4 bg-white' contenteditable>  <?php echo $row["name"]; ?> </td>


  <?php
  for ($day = 1; $day <= 31; $day++) {
    $name = $row["id"] . "date" . $day;
    ?>
    <td>
    <input type="checkbox" name="<?php echo $name; ?>" value="0.5" class="checkmark-checkbox" />
    <input type="checkbox" name="<?php echo $name; ?>" value="0.5" class="checkmark-checkbox" />
    </td>
    <!--crossmark-checkbox-->
    <?php
  }
  ?>

        </tr>

        <?php
    }
} 
    
}
?>

</tbody>
 <tfoot>
      <tr>
          <th class="position-sticky l-0 z-4 bg-white">
              total
          </th>
    </tr>
    </tfoot>
    </table>

                 
           
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "TSM" && $type != "RM" && $type != "ZM" && $type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  
  </div>
<?php
}
?>



<script>

document.addEventListener('DOMContentLoaded', function() {
    
  const dataTable = document.getElementById('editable-table');
  const tfoot = dataTable.querySelector('tfoot');


function calculateColumnTotal(colIndex) {
  let total = 0;
  const tbody = document.querySelector('#editable-table tbody');
  const rows = tbody.querySelectorAll('tr');

  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    const cell = cells[colIndex];
    const checkboxes = cell.querySelectorAll('input[type="checkbox"]');
     
    if (checkboxes.length > 0) {
        
      checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
          total += 0.5;
        }
      });
      
      
    } else {
      const cellText = cell.textContent.trim();
      const numberValue = parseFloat(cellText);
      if (!isNaN(numberValue)) {
        total += numberValue;
      }
    }
  });

  return total;
}


  for (let i = 2; i < 35; i++) {
    const colTotal = calculateColumnTotal(i);
    const colTotalCell = document.createElement('td');
    colTotalCell.textContent = colTotal;
    tfoot.querySelector('tr').appendChild(colTotalCell);
  }
});


   
  document.getElementById('submit-button').addEventListener('click', function () {
      this.disabled = true;
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

    tableRows.forEach(row => {
      const cells = row.querySelectorAll('td');
      const rowData = {
        id: cells[0].textContent,
        name: cells[1].textContent,
        state: '<?php echo $state; ?>',
        month: '<?php echo $month; ?>',
        year: '<?php echo $year; ?>'
      };

      for (let day = 1; day <= 31; day++) {
        const name = 'date' + day;
    const values = Array.from(cells[day + 1].querySelectorAll('input')).map(input => input.checked ? ('0.5') : '0').join(',');

        rowData[name] = values;
      }

      data.push(rowData);
    });

    const jsonString = JSON.stringify(data);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'crud.php?table=office_attendance', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          alert('Data sent successfully');
           window.location.href = window.location.href;
          console.log('Data sent successfully:', xhr.responseText);
        } else {
          alert('Data sent Failed');
          console.error('Error sending data:', xhr.statusText);
        }
      }
    };
    xhr.send(jsonString);
  });
</script>


<script>

const total = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(10) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call10').textContent = `Total: ${total}`;

const total9 = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(9) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call9').textContent = `Total: ${total9}`;


</script>

<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
       "id",
"name",
"state",
"month",
"year",
"date1",
"date2",
"date3",
"date4",
"date5",
"date6",
"date7",
"date8",
"date9",
"date10",
"date11",
"date12",
"date13",
"date14",
"date15",
"date16",
"date17",
"date18",
"date19",
"date20",
"date21",
"date22",
"date23",
"date24",
"date25",
"date26",
"date27",
"date28",
"date29",
"date30",
"date31",
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
         const rowData = {
        id: cells[0].textContent,
        name: cells[1].textContent,
        state: '<?php echo $state; ?>',
        month: '<?php echo $month; ?>',
        year: '<?php echo $year; ?>'
      };

      for (let day = 1; day <= 31; day++) {
        const name = 'date' + day;
        const values = Array.from(cells[day + 1].querySelectorAll('input:checked')).map(input => input.value).join(', ');
        rowData[name] = values;
      }

      data.push(rowData);
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>



    </div>
    <div class='footer'>
        <?php
include'footer.php';
?>
    </div>
    
</div>
</section>


</body>

</html>