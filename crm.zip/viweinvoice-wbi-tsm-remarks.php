<?php
include'api/db.php';
    
$data = json_decode(file_get_contents('php://input'), true);

extract($data);

  $sql = "SELECT * FROM invoice_wbi_tsm_remarks WHERE invoice_no='$invoice_no'";

  
	
	   $result=mysqli_query($con,$sql);
while($row = $result->fetch_assoc()){
 $invoices[] =$row;
}

		
 echo "<h2>".$invoice_no."</h2>";
echo "<table>";
echo "<tr><th>Date</th><th>Remarks</th></tr>";

foreach ($invoices as $invoice) {
    echo "<tr>";
    echo "<td>" . $invoice['date'] . "</td>";
    echo "<td>" . $invoice['wbi_tsm_remarks'] . "</td>";
    echo "</tr>";
}

echo "</table>";
   
   


?>


