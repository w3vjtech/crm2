<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='invoice';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
   
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>
<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
  <div class='w-100'>



     <h6  class="pt-5">screening</h6>
    
    
    


    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}
    </style>
    
    
    
<div>
    
    
    


</div>

<div id="clipboard">
   <table id="editable-table">
       
        <thead>
      
        
        <tr>  
            <th>Applied date</th>
            <th class="position-sticky l-0 z-4 bg-white">name</th>
            <th>dob</th>
            <th>age</th>
            <th>marital status</th>
            <th>state</th>
            <th>district</th>
            <th>work location</th>
            <th>home location</th>
            <th>residential address </th>
            <th>pin code </th>
            <th>phone </th>
            <th>email</th>
            <th>academic qualification </th>
            <th>field work experience </th>
            <th>atm esurveillance experience </th>
            <th>year of exprience </th>
            <th>recent company job role and salary </th>
            <th>recent company details and two reference no </th>
            <th>computer knowledge hardware and software </th>
            <th>candidate have two wheeler and license </th>
            <th>candidate have laptop </th>
            <th>candidate can assure phonewatsapp availability </th>
            <th>payment mode preferred salary percall basis </th>
            <th>willingness to relocate If required </th>
            <th>languages_known</th>
            <th>reference_phone_number_from_family</th>
            <th>willingness_to_immediately_join</th>
            <th>currently working</th>
            <th>notice period duration </th>
            <th>additional remarks </th>
            <th>Linkedin</th>
            <th>police clearance certificate </th>
            <th>CV</th>
            </tr>
        </thead>
        <tbody>
   

<?php
function echoSelectedStatus($phone) { 
   global $con;

    // SQL query to select data based on contact number
    $sql = "SELECT * FROM screening WHERE contact_no='$phone'"; 
    
    // Executing the query
    $result = $con->query($sql); 
    
    // Checking if there are any rows returned
    if ($result->num_rows > 0) {
        // Fetching the first row from the result set
        $row = $result->fetch_assoc();
        
        // Checking if the 'third_level_status' column value is 'SELECTED'
        // If true, echoing classes for Bootstrap background and text color
        echo ($row['third_level_status'] == "SELECTED") ? 'bg-primary text-white' : 'bg-white';
    } 
}  



 $sql1 = "SELECT COUNT(DISTINCT Phone) as total_unique_count FROM screening_data";
$result1 = $con->query($sql1);
if ($result1->num_rows > 0) {
   $row1 = $result1->fetch_assoc();
echo  $row1["total_unique_count"];
    }
    
 $sql = "SELECT * FROM screening_data";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
    <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td  ><?php echo $row["apply_date"]; ?></td> 
<td  class="position-sticky l-0 z-4  <?php echoSelectedStatus($row["phone"]); ?>"><?php echo $row["name"]; ?></td> 
<td  ><?php echo $row["dob"]; ?></td> 
<td  ><?php echo $row["age"]; ?></td> 
<td  ><?php echo $row["marital_status"]; ?></td> 
<td  ><?php echo $row["state"]; ?></td> 
<td  ><?php echo $row["district"]; ?></td> 
<td  ><?php echo $row["work_location"]; ?></td> 
<td  ><?php echo $row["home_location"]; ?></td> 
<td  ><?php echo $row["residential_address"]; ?></td> 
<td  ><?php echo $row["pin_code"]; ?></td> 
<td  ><?php echo $row["phone"]; ?></td> 
<td class="email" ><?php echo $row["email"]; ?></td> 
<td  ><?php echo $row["academic_qualification"]; ?></td> 
<td  ><?php echo $row["field_work_experience"]; ?></td> 
<td  ><?php echo $row["atm_esurveillance_experience"]; ?></td> 
<td  ><?php echo $row["year_of_exprience"]; ?></td> 
<td  ><?php echo $row["recent_company_job_role_and_salary"]; ?></td> 
<td  ><?php echo $row["recent_company_details_and_two_reference_no"]; ?></td> 
<td  ><?php echo $row["computer_knowledge_hardware_and_software"]; ?></td> 
<td  ><?php echo $row["candidate_have_two_wheeler_and_license"]; ?></td> 
<td  ><?php echo $row["candidate_have_laptop"]; ?></td> 
<td  ><?php echo $row["candidate_can_assure_phone_watsapp_availability"]; ?></td> 
<td  ><?php echo $row["payment_mode_preferred_salary_percall_basis"]; ?></td> 
<td  ><?php echo $row["willingness_to_relocate_If_required"]; ?></td>
<td  ><?php echo $row["languages_known"]; ?></td>
<td  ><?php echo $row["reference_phone_number_from_family"]; ?></td>
<td  ><?php echo $row["willingness_to_immediately_join"]; ?></td>
<td  ><?php echo $row["currently_working"]; ?></td>
<td  ><?php echo $row["notice_period_duration"]; ?></td>
<td  ><?php echo $row["additional_remarks"]; ?></td>
<td  ><?php echo $row["linkedin"]; ?></td>
<td  ><?php echo $row["police_clearance_certificate"]; ?></td>
<td  ><a href="uploads/<?php echo $row["upload_recent_photo"]; ?>">click</a></td>


      </tr>

        <?php
    }
}
?>

</tbody>
    </table>

 
<button id="export-button">Export to Excel</button>

<button id="captureButton">Copy to Clipboard</button>
</div>



<script>document.getElementById('captureButton').addEventListener('click', function() {html2canvas(document.getElementById('clipboard')).then(function(canvas) {canvas.toBlob(function(blob) {var item = new ClipboardItem({ "image/png": blob });navigator.clipboard.write([item]);});});});</script>


<script>
function updateBorderColor(selectElement) {
  const selectedValue = selectElement.value.toLowerCase();
  let borderColor = "";

  switch (selectedValue) {
    case "approved":
    case "paid":
      borderColor = "green";
      break;
    case "pending":
    case "unpaid":
      borderColor = "red";
      break;
    default:
      borderColor = "";
      break;
  }

  selectElement.style.borderColor = borderColor;
}
</script>


<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
         "id",
         "apply_date",
        "name",
        "dob",
        "age",
        "marital_status",
        "state",
        "district",
        "work_location",
        "home_location",
        "residential_address",
        "pin_code",
        "phone",
        "email",
        "academic_qualification",
        "field_work_experience",
        "atm_esurveillance_experience",
        "year_of_exprience",
        "recent_company_job_role_and_salary",
        "recent_company_details_and_two_reference_no",
        "computer_knowledge_hardware_and_software",
        "candidate_have_two_wheeler_and_license",
        "candidate_have_laptop",
        "candidate_can_assure_phone_watsapp_availability",
        "payment_mode_preferred_salary_percall_basis",
        "willingness_to_relocate_If_required",
        "languages_known",
        "reference_phone_number_from_family",
        "willingness_to_immediately_join",
        "currently_working",
        "notice_period_duration",
        "additional_remarks",
        "linkedin",
        "action",
        "state",
        "date",      
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
            
            
            
            
            id: cells[0].textContent,
            apply_date: cells[1].textContent,
            name: cells[2].textContent,
            dob: cells[3].textContent,
            age: cells[4].textContent,
            marital_status: cells[5].textContent,
            state: cells[6].textContent,
            district: cells[7].textContent,
            work_location: cells[8].textContent,
            home_location: cells[9].textContent,
            residential_address: cells[10].textContent,
            pin_code: cells[11].textContent,
            phone: cells[12].textContent,
            email: cells[13].textContent,
            academic_qualification: cells[14].textContent,
            field_work_experience: cells[15].textContent,
            atm_esurveillance_experience: cells[16].textContent,
            year_of_exprience: cells[17].textContent,
            recent_company_job_role_and_salary: cells[18].textContent,
            recent_company_details_and_two_reference_no: cells[19].textContent,
            computer_knowledge_hardware_and_software: cells[20].textContent,
            candidate_have_two_wheeler_and_license: cells[21].textContent,
            candidate_have_laptop: cells[22].textContent,
            candidate_can_assure_phone_watsapp_availability: cells[23].textContent,
            payment_mode_preferred_salary_percall_basis: cells[24].textContent,
            willingness_to_relocate_If_required: cells[25].textContent,
            languages_known: cells[26].textContent,
            reference_phone_number_from_family: cells[27].textContent,
            willingness_to_immediately_join: cells[28].textContent,
            currently_working: cells[29].textContent,
            notice_period_duration: cells[30].textContent,
            additional_remarks: cells[31].textContent,
            linkedin:  cells[32].textContent,
            action: cells[33].textContent,
            
           state: '<?php echo $state; ?>',
           date:'<?php echo $date; ?> ',
      
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


  </div>
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>
</body>

</html>