<?php
$resize = $_GET['resize'];

// File type
header('Content-Type: image/webp');

// Get new dimensions
list($width, $height) = getimagesize($resize);

$info = getimagesize($resize);
$mime = $info['mime'];

switch ($mime) {
    case 'image/jpeg':
        $image_create_func = 'imagecreatefromjpeg';
        break;
    case 'image/png':
        $image_create_func = 'imagecreatefrompng';
        break;
    case 'image/gif':
        $image_create_func = 'imagecreatefromgif';
        break;
        
    case 'image/webp':
        $image_create_func = 'imagecreatefromwebp';
        break;
        
    default:
        break;
}

// Resampling the image
$image_p = imagecreatetruecolor($width, $height);
if ($mime == 'image/png') {
    imagesavealpha($image_p, true);
    $transparent = imagecolorallocatealpha($image_p, 0, 0, 0, 127);
    imagefill($image_p, 0, 0, $transparent);
} else {
    $white = imagecolorallocate($image_p, 255, 255, 255);
    imagefill($image_p, 0, 0, $white);
}
$image = $image_create_func($resize);
imagecopyresampled($image_p, $image, 0, 0, 0, 0,
        $width, $height, $width, $height);

// Display of output image
if ($mime == 'image/png') {
    imagepng($image_p);
} else {
    imagejpeg($image_p, null, 50);
}

?>