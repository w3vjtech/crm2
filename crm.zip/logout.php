 <?php
session_start();
session_destroy();
foreach ($_COOKIE as $cookieName => $cookieValue) {
    setcookie($cookieName, '', time() - 3600, '/');
}

header("Location: index.php"); 
?>