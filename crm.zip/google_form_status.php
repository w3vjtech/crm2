<?php
// file autoload
require_once 'functions/autoload.php';

// database
$db = new db();
$con=$db->getConnection();

$table='tsm_work_book';
include'function.php';

$table='google_form_status';

$customHeadings = [
    "id" => 'textContent',
    "engineer_name" => 'textContent', 
    "location" => 'textContent',
    "calls_updated_in_whatsapp" => 'textContent',
    "g_form_update" => 'textContent',
    "no_of_calls_need_to_upload_in_g_form" => 'textContent',
];
        
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 
 $date=$_GET['date'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body >

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
              
<div class="position-sticky l-0 z-4 bg-white">
   <h6 class="card-title m-0">google_form_status</h6>
 <?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    <?php
if($state!=""){    
?>       

<div id="clipboard">
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
    <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM google_form_status WHERE state = '$state' AND date='$date'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td contenteditable>  <?php echo $row["engineer_name"]; ?> </td>
<td contenteditable>  <?php echo $row["location"]; ?> </td>
<td contenteditable>  <?php echo $row["calls_updated_in_whatsapp"]; ?> </td>
<td contenteditable>  <?php echo $row["g_form_update"]; ?> </td>
<td contenteditable>  <?php echo $row["no_of_calls_need_to_upload_in_g_form"]; ?> </td>
        </tr>
        
        <?php
    }
}


else{
     
$sql = "SELECT * FROM employee WHERE designation = 'SERVICE ENGINEERS' AND working_status='WORKING' AND vertical_name='WBI'";
if (isset($state)) {
    $sql .= " AND state = '$state'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        ?>
          <tr>

          
<td class='d-none'></td>


<td contenteditable><?php echo $row["name"];; ?></td>

<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>

      </tr>

        <?php
    }
} 
    
}
?>

</tbody>
    </table>
</div>

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "TSM" &&  $type != "RM" &&  $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
  </div>
  
<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
                   
<td class='d-none'></td>
<td contenteditable>  </td>
<td contenteditable>  </td>
<td contenteditable>  </td>
<td contenteditable>  </td>
<td contenteditable>  </td>
      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>






<?php

    $customHeadings["state"] = $state;
    $customHeadings["date"] = $date;


$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



                 
            
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>