<?php
$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 
 $date=$_GET['date'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">

 <?php
 include'sidebar.php';
  ?>
  <div class="wrapper">
<?php
include'header.php';
?>



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">hard_copy</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">

  
  


    
    
    
             
             <form action="" method="get" class='searc-form'>
      <div class='row'>
      <div class="col-md-3">
  <label class="form-label">State:</label>
  <select name="state" class="form-control form-control-lg">
    <option value="<?php echo isset($state) ? $state : ''; ?>"> <?php echo isset($state) ? $state : 'Select'; ?></option>
   <?php
        echo $state_access;
       $array = explode(",", $state_access);

        ?>
        
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
if (in_array($name, $array)) {
        echo '<option value="' . $name . '">' . $name . '</option>';
}
    }
} 
?>
</select>
</div>



<div class="col-md-3">
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}
    </style>
    <?php
if($state!=""){    
?>       
   <table id="editable-table">
        <thead>
        
            <tr>  
                
            <th>candidate_name</th>    
            <th>signed_agreement_copy</th>   
            <th>academic_certificate</th>   
            <th>aadhaar_card_copy</th>   
            <th>pan_card_copy</th>   
            <th>passport_photo</th>   
            <th>two_reference_contact_from_the_previous_company</th>   
            <th>bank_passbook_front_page_copy</th>   
            <th>driving_licence</th>   
            <th>location</th>   
            <th>tsm_name</th>   
            <th>date</th>   
            <th>remarks </th>   
              
            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM hard_copy WHERE state = '$state'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td contenteditable>  <?php echo $row["candidate_name"]; ?> </td> 
<td>
<input type="radio" name="signed_agreement_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["signed_agreement_copy"] === 'yes') echo "checked"; ?> />
<input type="radio" name="signed_agreement_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["signed_agreement_copy"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="academic_certificate<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["academic_certificate"] === 'yes') echo "checked"; ?> />
<input type="radio" name="academic_certificate<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["academic_certificate"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="aadhaar_card_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["aadhaar_card_copy"] === 'yes') echo "checked"; ?> />
<input type="radio" name="aadhaar_card_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["aadhaar_card_copy"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="pan_card_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["pan_card_copy"] === 'yes') echo "checked"; ?> />
<input type="radio" name="pan_card_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["pan_card_copy"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="passport_photo<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["passport_photo"] === 'yes') echo "checked"; ?> />
<input type="radio" name="passport_photo<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["passport_photo"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="two_reference_contact_from_the_previous_company<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["two_reference_contact_from_the_previous_company"] === 'yes') echo "checked"; ?> />
<input type="radio" name="two_reference_contact_from_the_previous_company<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["two_reference_contact_from_the_previous_company"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="bank_passbook_front_page_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["bank_passbook_front_page_copy"] === 'yes') echo "checked"; ?> />
<input type="radio" name="bank_passbook_front_page_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["bank_passbook_front_page_copy"] === 'no')  echo "checked"; ?> />    
</td>
<td>
<input type="radio" name="driving_licence<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" <?php if ($row["driving_licence"] === 'yes') echo "checked"; ?> />
<input type="radio" name="driving_licence<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" <?php if ($row["driving_licence"] === 'no')  echo "checked"; ?> />    
</td>

<td contenteditable>  <?php echo $row["location"]; ?> </td>
<td contenteditable>  <?php echo $row["tsm_name"]; ?> </td>
<td>   
 <input type="date" name="date" value="<?php echo $row["date"]; ?>" class="form-control form-control-lg" placeholder="date">
</td>
<td contenteditable>  <?php echo $row["remarks"]; ?> </td>
        </tr>
        
        <?php
    }
}else{
     
$sql = "SELECT * FROM screening WHERE 1";
if (isset($state)) {
    $sql .= " AND state = '$state'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        ?>
          <tr>

          
<td class='d-none'></td>

<td contenteditable>  <?php echo $name; ?> </td>
<td>
<input type="radio" name="signed_agreement_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="signed_agreement_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="academic_certificate<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="academic_certificate<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="aadhaar_card_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="aadhaar_card_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="pan_card_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="pan_card_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="passport_photo<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="passport_photo<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="two_reference_contact_from_the_previous_company<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="two_reference_contact_from_the_previous_company<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox" />    
</td>
<td>
<input type="radio" name="bank_passbook_front_page_copy<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox"  />
<input type="radio" name="bank_passbook_front_page_copy<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox"  />    
</td>
<td>
<input type="radio" name="driving_licence<?php echo $row["id"]; ?>" value="yes" class="checkmark-checkbox" />
<input type="radio" name="driving_licence<?php echo $row["id"]; ?>" value="no" class="crossmark-checkbox"  />    
</td>

<td contenteditable>0</td>
<td contenteditable>0</td>
<td>   
 <input type="date" name="date" value="" class="form-control form-control-lg" placeholder="date">
</td>
<td contenteditable>0</td>
      </tr>

        <?php
    }
} 
    
}
?>

</tbody>
    </table>



  <button id="submit-button">Submit Data</button>
  <button id="export-button">Export to Excel</button>
<?php
}
?>

<script>
  document.getElementById('submit-button').addEventListener('click', function () {
        const tableRows = document.querySelectorAll('#editable-table tbody tr');
        const data = [];

        tableRows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const rowData = {
id: cells[0].textContent,
candidate_name: cells[1].textContent,
signed_agreement_copy: Array.from(cells[2].querySelectorAll('input:checked')).map(input => input.value).join(','),
academic_certificate: Array.from(cells[3].querySelectorAll('input:checked')).map(input => input.value).join(','),
aadhaar_card_copy: Array.from(cells[4].querySelectorAll('input:checked')).map(input => input.value).join(','),
pan_card_copy: Array.from(cells[5].querySelectorAll('input:checked')).map(input => input.value).join(','),
passport_photo: Array.from(cells[6].querySelectorAll('input:checked')).map(input => input.value).join(','),
two_reference_contact_from_the_previous_company:Array.from(cells[7].querySelectorAll('input:checked')).map(input => input.value).join(','),
bank_passbook_front_page_copy: Array.from(cells[8].querySelectorAll('input:checked')).map(input => input.value).join(','),
driving_licence: Array.from(cells[9].querySelectorAll('input:checked')).map(input => input.value).join(','),
location: cells[10].textContent,
tsm_name: cells[11].textContent,
date: cells[12].querySelector('input[type="date"]').value,
remarks: cells[13].textContent,
state: '<?php echo $state; ?>'
            };
            data.push(rowData);
        });

        const jsonString = JSON.stringify(data);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'hard_copy_crud.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert('Data sent successfully');
                    console.log('Data sent successfully:', xhr.responseText);
                } else {
                    alert("Data sent Failed");
                    console.error('Error sending data:', xhr.statusText);
                }
            }
        };
        xhr.send(jsonString);
    });
</script>

<script>

const total = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(10) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call10').textContent = `Total: ${total}`;

const total9 = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(9) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call9').textContent = `Total: ${total9}`;


</script>
<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
       "id",
       
"candidate_name",
"signed_agreement_copy",
"academic_certificate",
"aadhaar_card_copy",
"pan_card_copy",
"passport_photo",
"two_reference_contact_from_the_previous_company",
"bank_passbook_front_page_copy",
"driving_licence",
"location",
"tsm_name",
"date",
"remarks",
"state"
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
          id: cells[0].textContent,
candidate_name: cells[1].textContent,
signed_agreement_copy: Array.from(cells[2].querySelectorAll('input:checked')).map(input => input.value).join(','),
academic_certificate: Array.from(cells[3].querySelectorAll('input:checked')).map(input => input.value).join(','),
aadhaar_card_copy: Array.from(cells[4].querySelectorAll('input:checked')).map(input => input.value).join(','),
pan_card_copy: Array.from(cells[5].querySelectorAll('input:checked')).map(input => input.value).join(','),
passport_photo: Array.from(cells[6].querySelectorAll('input:checked')).map(input => input.value).join(','),
two_reference_contact_from_the_previous_company:Array.from(cells[7].querySelectorAll('input:checked')).map(input => input.value).join(','),
bank_passbook_front_page_copy: Array.from(cells[8].querySelectorAll('input:checked')).map(input => input.value).join(','),
driving_licence: Array.from(cells[9].querySelectorAll('input:checked')).map(input => input.value).join(','),
location: cells[10].textContent,
tsm_name: cells[11].textContent,
date: cells[12].querySelector('input[type="date"]').value,
remarks: cells[13].textContent,
state: '<?php echo $state; ?>'
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


                 </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
 <?php
include'footer.php';
?>  </div>
</body>

</html>