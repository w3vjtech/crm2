<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


include'function.php';
?>


  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
    $report_time=$_GET['report_time'];
    $date=$_GET['date'];
    $edit=$_GET['edit'];
   
 
$table='final_screening_status';

$customHeadings = [
    "id" => 'textContent',
    "interviewer_name" => 'textContent', 
    "candidate_name" => 'textContent',
    "location" => 'textContent',
    "third_level_status" => 'selectValue',
     "agreement_status" => 'selectValue',
    "id_card_status" => 'selectValue',
    "insurance_status" => 'selectValue',
    "remarks" => 'textContent',
];
 
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>


<section>
    

<div class='sidebar'>
        <?php
    include'header.php';
    ?>

</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

    
    <div class="position-sticky l-0 z-4 bg-white">

     <h6  class="pt-5">final screening status</h6>
    
    
 <?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>



        </div>   
    
    <?php
if($state!="" AND $date!=""){    
?>       


<div id="clipboard">
    
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
  <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM final_screening_status WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($date)){
  $sql .= " AND date='$date'";
}


//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
        
         
<td class='d-none'><?php echo $row["id"]; ?></td>



<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>><?php echo $row["interviewer_name"]; ?></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> <?php  $diff = date_diff(date_create($row['date']), date_create());

        // Check if the difference is greater than 30 days and insurance status is not "COMPLETED"
        if ($diff->days > 60 && $row['insurance_status'] !== "COMPLETED") {
            echo "class='readmark'";
        }?>><?php echo $row["candidate_name"]; ?></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>><?php echo $row["location"]; ?></td> 
<td>
 <select>
    <option value="<?php echo $row["third_level_status"]; ?>"><?php echo $row["third_level_status"]; ?></option>
    <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
 <td>
 <select>
    <option value="<?php echo $row["agreement_status"]; ?>"><?php echo $row["agreement_status"]; ?></option>
     <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
  <td>
 <select>
    <option value="<?php echo $row["id_card_status"]; ?>"><?php echo $row["id_card_status"]; ?></option>
     <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
  <td>
 <select>
    <option value="<?php echo $row["insurance_status"]; ?>"><?php echo $row["insurance_status"]; ?></option>
     <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>><?php echo $row["remarks"]; ?></td> 

    </tr>

        <?php
    }
}
?>

</tbody>
    </table>
</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "HR" && $type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()" style="<?php if($type != "HR" && $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "display: none;"; ?>" >Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
           
<td class='d-none'></td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>></td> 
<td>
 <select>
 <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 <td>
 <select>
  <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
 <td>
 <select>
 <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
 <td>
 <select>
 <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>
<option value="select">select</option>
<option value="COMPLETED">COMPLETED</option>
<option value="NOT COMPLETED">NOT COMPLETED</option>
<?php } ?>
  </select> 
 </td>
 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>></td> 


<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




<?php
}
?>


<?php
$customHeadings["state"] = $state;
$customHeadings["date"] = $date;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');

$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>





    </div>
    <div class='footer'>
        
     <?php
    include'footer.php';
    ?>  
    </div>
    
</div>
</section>

<style>td.readmark {
    border: 1px solid red;
}</style>
</body>

</html>
