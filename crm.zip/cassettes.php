<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
 
$table='cassettes';

$customHeadings = [
    "id" => 'textContent',
    "client" => 'selectValue', 
    "branch_name" => 'textContent',
    "phone_number" => 'textContent',
    "email_id" => 'textContent',
    "no_of_cassettes" => 'textContent',
     "activity" => 'selectValue',
    "invoice_numbers" =>'textContent',
    "invoice_amount" => 'textContent',
    "invoice_status" => 'selectValue',
    "courier_charges" => 'textContent',
    "remarks" => 'textContent',
];
        

    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body>

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

  
  <div class="position-sticky l-0 z-4 bg-white">
  <h6 class="card-title m-0">cassettes</h6>
   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    
    <?php
if($state!="" AND $month!="" AND $year!=""){    
?>
    
    
<div id="clipboard">
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
       <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php

$sql = "SELECT * FROM cassettes WHERE 1";


if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}


$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
         
                   
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td class='position-sticky l-0 z-4 bg-white'>
  <select >
    <option value="<?php echo $row["client"]; ?>"> <?php echo $row["client"]; ?></option>
<option value="select">select</option>

    <?php echo $selectDropdown = generateSelectDropdown($con, 'finance_client', 'name'); ?>

  </select>
</td>
<td contenteditable>  <?php echo $row["branch_name"]; ?> </td>
<td contenteditable>  <?php echo $row["phone_number"]; ?> </td>
<td contenteditable>  <?php echo $row["email_id"]; ?> </td>
<td contenteditable>  <?php echo $row["no_of_cassettes"]; ?> </td>

<td>
  <select >
    <option value="<?php echo $row["activity"]; ?>"> <?php echo $row["activity"]; ?></option>
<option value="select">select</option>

    <?php echo $selectDropdown = generateSelectDropdown($con, 'finance_activity', 'name'); ?>


  </select>
</td>

<td contenteditable>  <?php echo $row["invoice_numbers"]; ?> </td>
<td contenteditable>  <?php echo $row["invoice_amount"]; ?> </td>

<td>
 <select>
    <option value="<?php echo $row["invoice_status"]; ?>"> <?php echo $row["invoice_status"]; ?></option>
<option value="select">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>
  </select> 
 </td>

<td contenteditable>  <?php echo $row["courier_charges"]; ?> </td>
<td contenteditable>  <?php echo $row["remarks"]; ?> </td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>


</div>

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "TSM" && $type != "RM" &&  $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>

<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
    <td class='d-none'><?php echo $row["id"]; ?></td>

<td class='position-sticky l-0 z-4 bg-white'>
  <select >
<option value="select">select</option>
<?php
$sql = "SELECT * FROM finance_client";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
        echo '<option value="' . $name . '">' . $name . '</option>';

    }
} 
?>

  </select>
</td>
<td contenteditable>   </td>
<td contenteditable>  </td>
<td contenteditable>   </td>
<td contenteditable>  </td>
<td>
  <select >

<option value="select">select</option>
<?php
$sql = "SELECT * FROM finance_activity";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
        echo '<option value="' . $name . '">' . $name . '</option>';

    }
} 
?>

  </select>
</td>
<td contenteditable>   </td>
<td contenteditable>   </td>

<td>
 <select>
   
<option value="select">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>
  </select> 
 </td>

<td contenteditable>  </td>
<td contenteditable>   </td>





      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>



 


<?php
$customHeadings["state"] = $state;
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>

</body>

</html>