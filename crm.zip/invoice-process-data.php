<?php
include'api/db.php';
    
    $data = json_decode(file_get_contents('php://input'), true);

  print_r($data);
   
foreach ($data as $entry) {
    
    extract($entry);

  if($id!=""){  
    
 $sql = "UPDATE invoice SET invoice_no='$invoice_no',invoice_date='$invoice_date',vendor='$vendor',invoice_status='$invoice_status',due_date='$due_date',tl_approval='$tl_approval',tsm_approval='$tsm_approval',rm_approval='$rm_approval',wbi_tsm_remarks='$wbi_tsm_remarks',client_remarks='$client_remarks',month='$month',year='$year',vendor_state='$vendor_state' WHERE id='$id'";
  
      
  }else{ 
      
$sql = "INSERT INTO invoice (invoice_no,invoice_date,vendor,invoice_status,due_date,tl_approval,tsm_approval,rm_approval,wbi_tsm_remarks,client_remarks,month,year,vendor_state) VALUES ('$invoice_no','$invoice_date','$vendor','$invoice_status','$due_date','$tl_approval','$tsm_approval','$rm_approval','$wbi_tsm_remarks','$client_remarks','$month','$year','$vendor_state')";

  }  
    
if(mysqli_query($con,$sql)){
     $response = ['status' => 'success', 'message' => 'invoice submitted'];
   echo json_encode($response);
}

}

?>



