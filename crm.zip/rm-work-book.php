<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();

$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];

$start_date=$year.'-'.$month.'-01';
$end_date=$year.'-'.$month.'-31';

 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body class="layout-1" data-luno="theme-black">

            
            
       
          
      

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
  <div class="position-sticky l-0 z-4 bg-white ">
     <h6 class="card-title m-0">RM work book</h6>
    
    <form action="" method="get" class='searc-form'>
      <div class='d-flex gap-30'>

<select name='month'>
    <?php
    $months = [
        '01' => "January",
        '02' => "February",
        '03' => "March",
        '04' => "April",
        '05' => "May",
        '06' => "June",
        '07' => "July",
        '08' => "August",
        '09' => "September",
        '10' => "October",
        '11' => "November",
        '12' => "December"
    ];

    foreach ($months as $number => $name) {
        echo "<option value=\"$number\">$name</option>";
    }
    ?>
</select>

<select name='year'>
    <?php
    $currentYear = date("Y");
    $startYear = 2022;

    for ($year = $currentYear; $year >= $startYear; $year--) {
        echo "<option value=\"$year\">$year</option>";
    }
    ?>
</select>


<div>
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}

tbody, td, tfoot, th, thead, tr {
    padding: 10px;
    width: max-content;
    text-wrap: nowrap;
    border: 1px solid #606060;
}
    </style>
    </div>
   <div id='clipboard'>
    <?php
//if($state!="" AND $start_date!="" AND $end_date!=""){    
?>       

<?php
// Function to retrieve and display data
function fetchData($state, $type, $con) {
    // Sanitize user inputs to prevent SQL injection (you should use prepared statements)
    $state = $con->real_escape_string($state);
    $type = $con->real_escape_string($type);

    // SQL query
    $sql = "SELECT name FROM login WHERE state LIKE '%$state%' AND type = '$type'";

    // Execute the query
    $result = $con->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Loop through the results and echo the names
        while ($row = $result->fetch_assoc()) {
            echo "Name: " . $row["name"] . "<br>";
        }
    } else {
        echo "No results found.";
    }
}





$states = explode(",", $state_access);
$stateList = "'" . implode("','", $states) . "'";

$sql = "SELECT date, state, am10_remarks, no_of_call_attended FROM tsm_work_book
        WHERE state IN ($stateList) AND STR_TO_DATE(date, '%d-%m-%Y') BETWEEN '$start_date' AND '$end_date'";

$formattedOutput = [];
// Execute the SQL query
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $date = $row['date'];
    $state = $row['state'];
    
      $formattedOutput[$date][$state]['am10_remarks'] += 1;
     
    if ($row['am10_remarks'] !== 'LEAVE' && $row['am10_remarks'] !== '0') {
      $am10_remarks[$date][$state] += 1;
      $total_am10_remarks[$date] += 1;
      $total_am10_remarks[$state] += 1;
       $grand_total_am10_remarks += 1;
       
    }
    
     if ($row['no_of_call_attended'] !== 'LEAVE' && $row['no_of_call_attended'] !== '0') {
      $no_of_call_attended[$date][$state] += $row['no_of_call_attended'];
   
      $total_no_of_call_attended[$date] += $row['no_of_call_attended'];
      $total_no_of_call_attended[$state] += $row['no_of_call_attended'];
       $grand_total_no_of_call_attended += $row['no_of_call_attended'];
    }
    
    
}



 



// Print the formatted output as an HTML table
echo '<table border="1">';




echo '<tr><th>RM </th>';
foreach ($states as $state) {
    
    
    echo '<th colspan="2">';
    
    fetchData($state, 'RM', $con); 
    echo'</th>';
  }

echo '</tr>';


echo '<tr><th>TSM</th>';
foreach ($states as $state) {
    
    
    echo '<th colspan="2">';
    fetchData($state, 'TSM', $con); 
    echo'</th>';
  }
echo '</tr>';


echo '<tr><th>Location</th>';
foreach ($states as $state) {
    
    
    echo '<th colspan="2">' . $state.'</th>';
  }

echo '<th>Total - PRESENTS</th>';
echo '<th >Total - Call Attended</th>';
echo '</tr>';

foreach ($formattedOutput as $date => $stateData) {
    echo '<tr>';
    echo '<td>' . $date . '</td>';
    foreach ($states as $state) {
       
       
        echo '<td >' . $am10_remarks[$date][$state]. '</td>';
         echo '<td >' . $no_of_call_attended[$date][$state] . '</td>';
    }
   
    echo '<td>' . $total_am10_remarks[$date] . '</td>';
     echo '<td>' . $total_no_of_call_attended[$date] . '</td>';
    echo '</tr>';
}

// Print column totals row for each column separately
echo '<tr><td>Total</td>';
foreach ($states as $state) {
  
    echo '<td>' . $total_am10_remarks[$state] . '</td>';
    echo '<td>' . $total_no_of_call_attended[$state] . '</td>';
}
echo '<td>' . $grand_total_am10_remarks . '</td>';
echo '<td>' . $grand_total_no_of_call_attended . '</td>';
echo '</tr>';

echo '</table>';

?>
    
<div class="pt-20"> </div>

</div>

  <div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="export-button">Export to Excel</button>
   <button id="captureButton">Copy to Clipboard</button>
  </div> 
   
<?php
//}
?>

 
    <script>
        document.getElementById('captureButton').addEventListener('click', function() {
            html2canvas(document.getElementById('clipboard')).then(function(canvas) {
                  canvas.toBlob(function(blob) {
                    var item = new ClipboardItem({ "image/png": blob });
                    navigator.clipboard.write([item]);
                });
            });
        });
    </script>
    
<script>

const total = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(10) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call10').textContent = `Total: ${total}`;

const total9 = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(9) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call9').textContent = `Total: ${total9}`;


</script>
<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
       "id",
"state",
"wbi_engineer",
"location",
"cms_team_leader",
"cms_engineer",
"am10_remarks",
"no_of_call_attended",
"no_of_call_attended",
"am10_remarks",
"pm1_remarks",
"report_time",
"date",
"wbi_tsm",
"rm_name",
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
           id: cells[0].textContent,
                state: '<?php echo $state; ?>',
                wbi_engineer: cells[1].textContent,
                location: cells[2].textContent,
                cms_team_leader: cells[3].textContent,
                cms_engineer: cells[4].textContent,
              'am10_remarks': cells[5].querySelector('select').value,
                'am10_remarks': cells[6].querySelector('select').value,
                'pm1_remarks': cells[7].querySelector('select').value,
              'no_of_call_attended': cells[8].querySelector('select').value,
              'no_of_call_attended': cells[9].querySelector('select').value,
                date: '<?php echo $date; ?>',
                wbi_tsm: '<?php echo $state; ?>',
                rm_name: '',
                jm_name: ''
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


                 
            
          
        
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>