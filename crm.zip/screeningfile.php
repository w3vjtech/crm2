<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the file was uploaded without errors
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        // Specify the directory where you want to save the uploaded file
        $uploadDir = "uploads/";

        // Create the uploads directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Build the path to save the file
        $uploadPath = $uploadDir . basename($_FILES["file"]["name"]);

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $uploadPath)) {
            echo "File uploaded successfully. Path: " . $uploadPath;
        } else {
            echo "Error uploading the file.";
        }
    } else {
        echo "Error: " . $_FILES["file"]["error"];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload Form</title>
</head>
<body>
    <!--<h2>File Upload Form</h2>-->
    <form action="screeningfile.php" method="post" enctype="multipart/form-data">
        <label for="file">Choose a file:</label>
        <input type="file" name="file" id="file" required>
        <br>
        <!--<input type="submit" value="Upload">-->
    </form>
</body>
</html>
