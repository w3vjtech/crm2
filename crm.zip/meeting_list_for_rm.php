<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();



$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 

$table='meeting';

$customHeadings = [
    "id" => 'textContent',
    "rm_name" => 'textContent', 
    "zm_name" => 'textContent',
    "meeting_date" => 'date',
    "meeting_times" => 'time',
    "meeting_agenda" => 'textContent',
    "zm_approvel" => 'selectValue',
    "meeting_attendance" => 'textContent',
    "meeting_miniutes" => 'textContent',
    "remarks" => 'textContent',
];
         
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body >

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
        <div class="position-sticky l-0 z-4 bg-white">
   <h6 class="card-title m-0">RM Meeting</h6>
<?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
          <div class="card">
             
              <div class="card-body">

  

    <?php
if($state!="" AND $date!=""){    
?>       
   <table id="editable-table">
       <input type="text" id="table-search" placeholder="Search..." >
 <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php

$sql = "SELECT * FROM meeting WHERE state = '$state' AND date = '$date' AND meeting_book='RM'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td contenteditable><?php echo $row["rm_name"]; ?></td>

<td contenteditable><?php echo $row["zm_name"]; ?></td>
<td>   
 <input type="date" name="date" value="<?php echo $row["meeting_date"]; ?>" class="form-control form-control-lg" placeholder="date">
</td>
<td>   
 <input type="time" name="meeting_times" value="<?php echo $row["meeting_times"]; ?>" class="form-control form-control-lg" placeholder="meeting_times">
</td>
<td contenteditable><?php echo $row["meeting_agenda"]; ?></td>

<td>
  <select onchange="updateBorderColor(this)">
    <option value="<?php echo $row["zm_approvel"]; ?>">  <?php echo $row["zm_approvel"]; ?></option>
    
   <?php if($type=="ZM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>





<td <?php echo $row["zm_approvel"]  == "YES" ? 'contenteditable' : ''; ?>  ><?php echo $row["meeting_attendance"]; ?></td>
<td <?php echo $row["zm_approvel"]  == "YES" ? 'contenteditable' : ''; ?> ><?php echo $row["meeting_miniutes"]; ?></td>
<td <?php echo $row["zm_approvel"]  == "YES" ? 'contenteditable' : ''; ?> ><?php echo $row["remarks"]; ?></td>

        </tr>
        
        <?php
    }
}

?>

</tbody>
    </table>


<div class="position-sticky l-0 z-4 bg-white d-flex gap-20 ">
  <button id="submit-button" <?php if($type != "RM" &&  $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>

</div>
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
    <td class='d-none'></td>
    <td contenteditable></td>
    <td contenteditable></td>
    <td>   
      <input type="date" name="date" value="" class="form-control form-control-lg" placeholder="date">
    </td>
     <td>   
      <input type="time" name="meeting_times" value="" class="form-control form-control-lg" placeholder="meeting_times">
    </td>
    <td contenteditable></td>
       <td>
      <select onchange="updateBorderColor(this)">
         <?php if($type=="ZM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
      </select>
    </td>
    
 
    <td  ></td>
    <td  ></td>
    <td  ></td>
    <td>
      <button onclick="removeTableRow(this)">Remove</button>
    </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>



<?php
}
?>



<?php
$customHeadings["meeting_book"] = 'RM';
$customHeadings["state"] = $state;
$customHeadings["date"] = $date;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');

$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');

?>


                 </div>
            </div>
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>