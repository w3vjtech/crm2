<?php
$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">
<div class='d-flex'>
    
<?php
include'header.php';
?>


  <div class="wrapper p-10 w-100">

<?php include'top-bar.php'; ?>


     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">training</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">

  
  


    
    
    
             
             <form action="" method="get" class='searc-form'>
      <div class='d-flex gap-30'>
      <div >
  <label class="form-label">State:</label>
  <select name="state" class="form-control form-control-lg">
    <option value="<?php echo isset($state) ? $state : ''; ?>"> <?php echo isset($state) ? $state : 'Select'; ?></option>
   <?php
        echo $state_access;
       $array = explode(",", $state_access);

        ?>
        
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
if (in_array($name, $array)) {
        echo '<option value="' . $name . '">' . $name . '</option>';
}
    }
} 
?>
</select>
</div>

 <div>
  <label class="form-label">month:</label>
<select name="month" class="form-control form-control-lg">
    <option value="<?php echo isset($month) ? $month : ''; ?>"> <?php echo isset($month) ? $month : 'Select'; ?></option>
    <?php
    $months = array(
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    );

    foreach ($months as $name) {
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
    ?>
</select>

</div>
  <div>
  <label class="form-label">Year:</label>
<select name="year" class="form-control form-control-lg">
              <option value="<?php echo isset($year) ? $year : ''; ?>"> <?php echo isset($year) ? $year : 'Select'; ?></option>
  
            <?php
            // Get the current year
            $currentYear = date("Y");
$years = range($currentYear, 2022);
foreach ($years as $name) {
    echo '<option value="' . $name . '">' . $name . '</option>';
}
            ?>
        </select>
</div>

<div>
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}
    </style>
    <?php
if($state!=""){    
?>       
<div id="clipboard">
   <table id="editable-table">
        <thead>
        
            <tr>  
            <th>ce name</th>
            <th>location</th>
            <th>vertical name</th>
            <th>wbi tsm name</th>
            <th>trainer name</th>
            <th>trainer contact number</th>
            <th>training start date</th>
            <th>training end date</th>
            <th>no of days attend</th>
            <th>aadhar card number</th>
            <th>driving license number</th>
            <th>passport size photo</th>
        
            <th>remarks</th>
            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM training WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>


<td contenteditable>  <?php echo $row["ce_name"]; ?> </td>

<td contenteditable>  <?php echo $row["location"]; ?> </td>

<td>
  <select>
    <option value="<?php echo $row["vertical_name"]; ?>"> <?php echo $row["vertical_name"]; ?> </option>
<option value="select">select</option>
<option value="ABC">ABC</option>
<option value="ABC">ABC</option>
  </select>
</td>
<td contenteditable>  <?php echo $row["wbi_tsm_name"]; ?> </td>

<td contenteditable>  <?php echo $row["trainer_name"]; ?> </td>

<td contenteditable>  <?php echo $row["trainer_contact_number"]; ?> </td>

<td><input type="date" value="<?php echo $row["training_start_date"]; ?>"> </td>

<td><input type="date" value="<?php echo $row["training_end_date"]; ?>"> </td>


<td contenteditable>  <?php echo $row["no_of_days_attend"]; ?> </td>





<td>
  <select>
    <option value="<?php echo $row["aadhar_card_number"]; ?>"> <?php echo $row["aadhar_card_number"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
    <option value="<?php echo $row["driving_license_number"]; ?>"> <?php echo $row["driving_license_number"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td>
  <select>
    <option value="<?php echo $row["passport_size_photo"]; ?>"> <?php echo $row["passport_size_photo"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td contenteditable>  <?php echo $row["remarks"]; ?> </td>


        </tr>
        
<?php
    }
}
?>

</tbody>
    </table>



  <button id="submit-button" <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
<?php
}
?>




<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
           
<td class='d-none'></td>
<td contenteditable></td>
<td contenteditable></td>

<td>
  <select>
<option value="select">select</option>
<option value="ABC">ABC</option>
<option value="ABC">ABC</option>
  </select>
</td>
<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td><input type="date" value=""> </td>

<td><input type="date" value=""> </td>


<td contenteditable></td>

<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>
<td contenteditable></td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>

<button onclick="addTableRow()">Add Row</button>

<button id="captureButton">Copy to Clipboard</button>

</div>



<script>document.getElementById('captureButton').addEventListener('click', function() {html2canvas(document.getElementById('clipboard')).then(function(canvas) {canvas.toBlob(function(blob) {var item = new ClipboardItem({ "image/png": blob });navigator.clipboard.write([item]);});});});</script>

<script>
function updateBorderColor(selectElement) {
  const selectedValue = selectElement.value.toLowerCase();
  let borderColor = "";

  switch (selectedValue) {
    case "approved":
    case "paid":
      borderColor = "green";
      break;
    case "pending":
    case "unpaid":
      borderColor = "red";
      break;
    default:
      borderColor = "";
      break;
  }

  selectElement.style.borderColor = borderColor;
}
</script>





<script>
  document.getElementById('submit-button').addEventListener('click', function () {
      this.disabled = true;
        const tableRows = document.querySelectorAll('#editable-table tbody tr');
        const data = [];

        tableRows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const rowData = {
        id: cells[0].textContent,                
        ce_name: cells[1].textContent,
        location: cells[2].textContent,
        vertical_name: cells[3].querySelector('select').value,
        wbi_tsm_name: cells[4].textContent,
        trainer_name: cells[5].textContent,
        trainer_contact_number: cells[6].textContent,
        training_start_date: cells[7].querySelector('input[type="date"]').value,
        training_end_date: cells[8].querySelector('input[type="date"]').value,
        no_of_days_attend: cells[9].textContent,
        aadhar_card_number: cells[10].querySelector('select').value,
        driving_license_number: cells[11].querySelector('select').value,
        passport_size_photo: cells[12].querySelector('select').value,
        remarks: cells[13].textContent,
        
        state: '<?php echo $state; ?>',
        month: '<?php echo $month; ?>',
        year:'<?php echo $year; ?>',

            };
            data.push(rowData);
        });

        const jsonString = JSON.stringify(data);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'training-crude.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert('Data sent successfully');
                    
                    window.location.href = window.location.href;
                    
                    console.log('Data sent successfully:', xhr.responseText);
                } else {
                    alert("Data sent Failed");
                    console.error('Error sending data:', xhr.statusText);
                }
            }
        };
        xhr.send(jsonString);
    });
</script>

<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
"id",
"ce_name",
"location",
"vertical_name",
"wbi_tsm_name",
"trainer_name",
"trainer_contact_number",
"training_start_date",
"training_end_date",
"no_of_days_attend",
"aadhar_card_number",
"driving_license_number",
"passport_size_photo",
"remarks",

"state",
"month",
"year",

    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
id: cells[0].textContent,                
ce_name: cells[1].textContent,
location: cells[2].textContent,
vertical_name: cells[3].querySelector('select').value,
wbi_tsm_name: cells[4].textContent,
trainer_name: cells[5].textContent,
trainer_contact_number: cells[6].textContent,
training_start_date: cells[7].querySelector('input[type="date"]').value,
training_end_date: cells[8].querySelector('input[type="date"]').value,
no_of_days_attend: cells[9].textContent,
aadhar_card_number: cells[10].querySelector('select').value,
driving_license_number: cells[11].querySelector('select').value,
passport_size_photo: cells[12].querySelector('select').value,
remarks: cells[13].textContent,

        state: '<?php echo $state; ?>',
        month: '<?php echo $month; ?>',
        year:'<?php echo $year; ?>',

        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


                 </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
 <?php
include'footer.php';
?>  </div>
</div>
</body>

</html>