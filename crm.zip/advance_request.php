<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
$table='advance_request';

$customHeadings = [
    "id" => 'textContent',
    "employee_name" => 'textContent', 
    "department" => 'textContent',
    "requested_amount" => 'textContent',
    "rm_approval" => 'selectValue',
     "gm_approval" => 'selectValue',
    "finance_approval" => 'selectValue',
    "approved_amount" => 'textContent',
    "credit_date" => 'date',
    "status" => 'textContent',
    "amount_returned_date" => 'date',
];
 
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">


<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
        <div class="position-sticky l-0 z-4 bg-white">
  <h6 class="card-title m-0">Advance request</h6>
   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
       

    
    <?php
if($state!=""){    
?>       

<div id="clipboard">
   <table id="editable-table">
       <input type="text" id="table-search" placeholder="Search..." >
          <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM advance_request WHERE 1";


if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}




$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
         
<td class='d-none'><?php echo $row["id"]; ?></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable><?php echo $row["employee_name"]; ?></td>
<td contenteditable><?php echo $row["department"]; ?></td>
<td contenteditable><?php echo $row["requested_amount"]; ?></td>
  
  <td>
 <select>
    <option value="<?php echo $row["rm_approval"]; ?>"> <?php echo $row["rm_approval"]; ?></option>
    <?php if($type == "RM" || $type == "ZM" || $type == "GM"|| $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
 <td>
 <select>
    <option value="<?php echo $row["gm_approval"]; ?>"> <?php echo $row["gm_approval"]; ?></option>
    <?php if( $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
  <td>
 <select>
    <option value="<?php echo $row["finance_approval"]; ?>"> <?php echo $row["finance_approval"]; ?></option>
    <?php if($type == "FM" || $type == "GM"|| $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
  <td contenteditable><?php echo $row["approved_amount"]; ?></td>
  
<td>   
 <input type="date" name="credit_date" value="<?php echo $row["credit_date"]; ?>" class="form-control form-control-lg" placeholder="credit_date">
</td>


<td contenteditable><?php echo $row["status"]; ?></td>

<td>   
 <input type="date" name="amount_returned_date" value="<?php echo $row["amount_returned_date"]; ?>" class="form-control form-control-lg" placeholder="amount_returned_date">
</td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>
</div>

  <div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "FM" && $type != "RM" && $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>

<?php
}
?>
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
 <td class='d-none'></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
  
  <td>
 <select>
    
    <?php if($type == "RM" || $type == "ZM" || $type == "GM"|| $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
 <td>
 <select>
   
    <?php if( $type == "GM" || $type == "MD" || $type == "D" ){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
  <td>
 <select>
  
    <?php if($type == "FM" || $type == "GM"|| $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="APPROVED">APPROVED</option>
<option value="CANCELLED">CANCELLED</option>
<?php } ?>
  </select> 
 </td>
  
  <td contenteditable>  </td>
  
<td>   
 <input type="date" name="credit_date" value="" class="form-control form-control-lg" placeholder="credit_date">
</td>


<td contenteditable>  </td>

<td>   
 <input type="date" name="amount_returned_date" value="" class="form-control form-control-lg" placeholder="amount_returned_date">
</td>




      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>





<?php

$customHeadings["state"] = $state;
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;
        

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>


</body>

</html>