<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $date= date("d-m-Y", strtotime($_GET['date']));
 $edit=$_GET['edit'];
 

$table='tsm_work_book';

$customHeadings = [
    
    "id" => 'textContent',
    "wbi_engineer_name" => 'textContent',
    "wbi_id" => 'textContent',
    "location" => 'textContent',
    "am10_call_planned_by_wbi_ce" => 'selectValue',
    "am10_remarks" => 'selectValue',
    "pm1_remarks" => 'selectValue',
    "no_of_call_attended" => 'selectValue',
    "call_closer_count" => 'selectValue',
];
 
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 
</head>

<body>

<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
<div class="position-sticky l-0 z-4 bg-white">        
           <h6 class="card-title m-0">Tsm work book</h6>
<?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>

<div id='clipboard'>
    
    
    <?php
if($state!="" AND $date!=""){    
?>       
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
 <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
       <tbody>
   

<?php
$sql = "SELECT * FROM tsm_work_book WHERE state = '$state' AND date = '$date'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc(); // Removed unnecessary curly braces
    echo '<p class="py-5">Who Upload :'.$row["who_upload"].'</p>';    
}

  
$sql = "SELECT * FROM tsm_work_book WHERE state = '$state' AND date = '$date'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
        
       
        
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td contenteditable>  <?php echo $row["wbi_engineer_name"]; ?> </td>
<td contenteditable>  <?php echo $row["wbi_id"]; ?> </td>
<td contenteditable>  <?php echo $row["location"]; ?> </td>
<td>
     <select>
    <option value="<?php echo $row["am10_call_planned_by_wbi_ce"]; ?>"> <?php echo $row["am10_call_planned_by_wbi_ce"]; ?></option>
    
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>

<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>


  <?php
$target_time = strtotime("11:00:00");
$a_time = strtotime($row["am_10_time"]);
if ($a_time > $target_time) {
  echo'<td style ="border: 2px solid red;" >';
}else{
    echo'<td>';
}
?>
    
<select>
<option value="<?php echo $row["am10_remarks"]; ?>"> <?php echo $row["am10_remarks"]; ?></option>
<option value="1st CALL WIP">1st CALL WIP</option>
<option value="On The Way First Call">On The Way First Call</option>

<option value="LEAVE">LEAVE</option>
<option value="WAITING FOR SPARE">WAITING FOR SPARE</option>
<option value="NO CALL">NO CALL</option>
<option value="WAITING FOR CALL LIST">WAITING FOR CALL LIST</option>
</select>
    </td>

  <?php
$target_time = strtotime("14:00:00");
$a_time = strtotime($row["pm_1_time"]);
if ($a_time > $target_time) {
  echo'<td style ="border: 2px solid red;" >';
}else{
    echo'<td>';
}
?>
<select>
<option value="<?php echo $row["pm1_remarks"]; ?>"><?php echo $row["pm1_remarks"]; ?></option>
<option value="1st CALL WIP">1st CALL WIP</option>
<option value="LEAVE">LEAVE</option>
<option value="On The Way To Next Call">On The Way To Next Call</option>
<option value="WAITING FOR SPARE">WAITING FOR SPARE</option>
<option value="NO CALL">NO CALL</option>
<option value="WAITING FOR CALL LIST">WAITING FOR CALL LIST</option>
<option value="2nd CALL WIP">2nd CALL WIP</option>
<option value="3rd CALL WIP">3rd CALL WIP</option>
</select>    
</td>
  <?php
$target_time = strtotime("21:00:00");
$a_time = strtotime($row["pm_8_time"]);
if ($a_time > $target_time) {
  echo'<td style ="border: 2px solid red;" >';
}else{
    echo'<td>';
}
?>
 <select>
<option value="<?php echo $row["no_of_call_attended"]; ?>"><?php echo $row["no_of_call_attended"]; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>
    <td>
 <select>
<option value="<?php echo $row["call_closer_count"]; ?>"><?php echo $row["call_closer_count"]; ?></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>
        </tr>
        
        <?php
    }
}else{
    


    
$sql = "SELECT * FROM employee WHERE designation = 'SERVICE ENGINEERS' AND vertical_name='WBI' AND working_status='WORKING' AND state = '$state'";
if (isset($state)) {
   // $sql .= " AND state = '$state'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        ?>
          <tr>
           
<td class='d-none'></td>
<td contenteditable><?php echo $row["name"];?> </td>
<td contenteditable> <?php echo $row["employee_id"];?> </td>

<td contenteditable> <?php echo $row["district"];?> </td>

<td>
     <select>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>

<td>
<select>
<option value="0">0</option>    
<option value="1st CALL WIP">1st CALL WIP</option>
<option value="On The Way First Call">On The Way First Call</option>

<option value="LEAVE">LEAVE</option>
<option value="WAITING FOR SPARE">WAITING FOR SPARE</option>
<option value="NO CALL">NO CALL</option>
<option value="WAITING FOR CALL LIST">WAITING FOR CALL LIST</option>
</select>
    </td>

<td>
<select>
<option value="0">0</option>     
<option value="1st CALL WIP">1st CALL WIP</option>
<option value="LEAVE">LEAVE</option>
<option value="On The Way To Next Call">On The Way To Next Call</option>

<option value="WAITING FOR SPARE">WAITING FOR SPARE</option>
<option value="NO CALL">NO CALL</option>
<option value="WAITING FOR CALL LIST">WAITING FOR CALL LIST</option>
<option value="2nd CALL WIP">2nd CALL WIP</option>
<option value="3rd CALL WIP">3rd CALL WIP</option>
</select>    
</td>
<td>
 <select>
<option value="0">0</option> 
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>
    <td>
 <select>
<option value="0">0</option> 
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="LEAVE">LEAVE</option>
<option value="NO CALL">NO CALL</option>
<option value="OTHERS">OTHERS</option>
  </select>
    </td>
        </tr>

        <?php
    }
} 
    
}
?>

</tbody>
    </table>
<div class='result Euclid-Circular-B-SemiBold'>
<p>Date: <?php echo $date; ?></p>
<p class='Euclid-Circular-B-SemiBold' id='total_presents'> </p> 
<p class='Euclid-Circular-B-SemiBold' id='total_no_call'> </p>  
<p class='Euclid-Circular-B-SemiBold' id='total_leave'> </p>  
<p class='Euclid-Circular-B-SemiBold' id='total_calls'> </p>   
</div>
   
</div> 

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="location.href='tsm-monthly-output'">tsm-monthly-output</button>
  <button id="captureButton">Copy to Clipboard</button>
 </div> 

<script>

const totalCalls = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(8) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);
console.log(totalCalls);
document.querySelector('#total_calls').textContent = `Total Calls: ${totalCalls}`;





const totalLeave = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(6) select')?.value || '0';
    return valueString;
  })
  .reduce((count, value) => count + (value === 'LEAVE' ? 1 : 0), 0);

document.querySelector('#total_leave').textContent = `Total: ${totalLeave} LEAVE`;
console.log(totalLeave);

const totalNoCall = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(6) select')?.value || '0';
    return valueString;
  })
  .reduce((count, value) => count + (value === 'NO CALL' ? 1 : 0), 0);

document.querySelector('#total_no_call').textContent = `Total "NO CALL": ${totalNoCall}`;


const totalPresents = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(6) select')?.value || '0';
    return valueString;
  })
  .reduce((count, value) => count + (value !== 'LEAVE' && value !== '0' ? 1 : 0), 0);

document.querySelector('#total_presents').textContent = `Total Presents: ${totalPresents}`;


</script>

  

<?php

 $customHeadings["wbi_tsm"] = '';  
 $customHeadings["rm_name"] = '';  
 $customHeadings["jm_name"] = '';  
 $customHeadings["date"] = $date;  
 $customHeadings["state"] = $state;  
 $customHeadings["who_upload"] = $_SESSION["type"];  
 $customHeadings["who_email"] = $_SESSION["email"];  
 
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');

?>





<div id='clipboard1'>
    <br>
    <input type="text" id="table-search1" placeholder="Search..." >

  <table id="editable-tablecalldata" class='mt-50'>
        <thead>
                
            <tr>  
            <input type="checkbox"  class="filterCheckbox1" checked> Select All

            <th><input type="checkbox"  class="filterCheckbox1" checked>client name</th>   
            <th><input type="checkbox"  class="filterCheckbox1" checked>no of calls completed</th>
            
           
            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM tsm_client_call_data WHERE state = '$state' AND date = '$date'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>


<td>
 <select>
    <option value="<?php echo $row["client_name"]; ?>"> <?php echo $row["client_name"]; ?></option>
<option value="select">select</option>
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'customer_name'); ?>
  </select> 
 </td>
<td>
    <select name="calls_completed">
        <?php
        // Generate options from 1 to 100
        for ($i = 1; $i <= 100; $i++) {
            // Check if the current option matches the value from the database
            $selected = ($row["no_of_calls_completed"] == $i) ? 'selected' : '';
            echo "<option value='$i' $selected>$i</option>";
        }
        ?>
    </select>
</td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>

</div>

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button1"  <?php if($type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button1">Export to Excel</button>
  <button onclick="addTableRow1()">Add Row</button>
<button id="captureButton1">Copy to Clipboard</button>
  </div>
<?php } ?>  
  
  
<script>

function addTableRow1() {
  var table = document.getElementById("editable-tablecalldata").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
<td class='d-none'></td>
<td>
 <select>
<option value="select">select</option>
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'customer_name'); ?>
  </select> 
 </td>
<td>
    <select name="calls_completed">
        <?php
        // Generate options from 1 to 100
        for ($i = 1; $i <= 100; $i++) {
            // Check if the current option matches the value from the database
            $selected = ($row["no_of_calls_completed"] == $i) ? 'selected' : '';
            echo "<option value='$i' $selected>$i</option>";
        }
        ?>
    </select>
</td>
      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>



<?php
$table='tsm_client_call_data';

$customHeadings = [
    "id" => 'textContent',
    "client_name" => 'selectValue',
    "no_of_calls_completed" => 'selectValue',
    "date" => $date, 
    "state" => $state,
    
];

$ExportButton1 = new ExportButton();
echo $ExportButton1=$ExportButton1->renderScript($customHeadings,'editable-tablecalldata','export-button1');


$SubmitButton1 = new SubmitButton();
echo $SubmitButton1=$SubmitButton1->renderScript($customHeadings, $table,'editable-tablecalldata','submit-button1');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard1','captureButton1');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search1', 'filterCheckbox1','editable-tablecalldata');

?>

    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

</body>

</html>