<?php
 // file autoload
require_once 'functions/autoload.php';
// database
$db = new db();
$con=$db->getConnection();

$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $year=$_GET['year'];
 $month=$_GET['month'];
 $edit=$_GET['edit'];
 

$table='finance_invoice';

$customHeadings = [
"id" => 'textContent',
"invoice_no"=> 'textContent',
"invoice_date"=> 'date',
"client_name"=> 'textContent',
"billed_call_count"=> 'textContent',
"taxable_amount"=> 'textContent',
"invoice_amount_with_gst"=> 'textContent',
"revised_taxable_amount"=> 'textContent',
"revised_invoice_amount_with_gst"=> 'textContent',
"rejected_call_count"=> 'textContent',
"rejected_amount_without_gst"=> 'textContent',
"invoice_status"=> 'selectValue',
"due_date"=> 'date',
"gst_filed" => 'selectValue',
"tl_permission"=> 'selectValue',
"tsm_permission"=> 'selectValue',
"rm_permission"=> 'selectValue',
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body >


<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
        <div class="position-sticky l-0 z-4 bg-white">
 <h6 class="card-title m-0">finance_invoice</h6>
   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

</div>
        
      
  
  



    
    <div id="clipboard">
  
   <table id="editable-table">
          <input type="text" id="table-search" placeholder="Search..." >
     <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM finance_invoice WHERE 1";


if(isset($state)&&!empty($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)&&!empty($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)&&!empty($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable><?php echo $row["invoice_no"]; ?></td>
<td>   
 <input type="date"  value="<?php echo $row["invoice_date"]; ?>" class="form-control form-control-lg" placeholder="invoice_date">
</td>
<td contenteditable><?php echo $row["client_name"]; ?></td>
<td contenteditable><?php echo $row["billed_call_count"]; ?></td>
<td contenteditable><?php echo $row["taxable_amount"]; ?></td>

<td contenteditable><?php echo $row["invoice_amount_with_gst"]; ?></td>
<td contenteditable><?php echo $row["revised_taxable_amount"]; ?></td>
<td contenteditable><?php echo $row["revised_invoice_amount_with_gst"]; ?></td>
<td contenteditable><?php echo $row["rejected_call_count"]; ?></td>
<td contenteditable><?php echo $row["rejected_amount_without_gst"]; ?></td>

<td>
  <select onchange="updateBorderColor(this)">
    <option value="<?php echo $row["invoice_status"]; ?>"><?php echo $row["invoice_status"]; ?></option>
<option value="">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>
  </select>
</td>
<td>
 <input type="date" name="due_date" value="<?php echo $row["due_date"]; ?>" class="form-control form-control-lg" placeholder="due_date">
</td>

<td>
  <select onchange="updateBorderColor(this)">
    <option value="<?php echo $row["gst_filed"]; ?>"><?php echo $row["gst_filed"]; ?></option>
<option value="">select</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
  </select>
</td>



<td>
      <select onchange="updateBorderColor(this)">
           <option value="<?php echo $row["tl_permission"]; ?>"><?php echo $row["tl_permission"]; ?></option>
 <?php if($type=="TL" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>



<td>
      <select onchange="updateBorderColor(this)">
          <option value="<?php echo $row["tsm_permission"]; ?>"><?php echo $row["tsm_permissionl"]; ?></option>
 <?php if($type=="TSM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>




<td>
      <select onchange="updateBorderColor(this)">
          <option value="<?php echo $row["rm_permission"]; ?>"><?php echo $row["rm_permission"]; ?></option>
 <?php if($type=="RM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>
        </tr>
        
        <?php
    }
}


?>

</tbody>
    </table>
  
  </div>
  
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button">Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>



<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
<td class='d-none'></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable> </td>
<td>   
 <input type="date" name="invoice_date" value="" class="form-control form-control-lg" placeholder="invoice_date">
</td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td>
  <select onchange="updateBorderColor(this)">
   
<option value="">select</option>
<option value="PAID">PAID</option>
<option value="UNPAID">UNPAID</option>
  </select>
</td>
<td>
 <input type="date" name="due_date" value="" class="form-control form-control-lg" placeholder="due_date">
</td>

<td>
  <select onchange="updateBorderColor(this)">
  
<option value="">select</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
  </select>
</td>



<td>
      <select onchange="updateBorderColor(this)">
        
 <?php if($type=="TL" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>



<td>
      <select onchange="updateBorderColor(this)">
       
 <?php if($type=="TSM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>




<td>
      <select onchange="updateBorderColor(this)">
       
 <?php if($type=="RM" || $type=="GM" || $type=="MD" || $type=="D"){ ?>
<option value="">select</option>
<option value="APPROVED">Approved</option>
<option value="CANCELED">Cancelled</option>
<?php } ?>
  </select>
</td>

      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>






       
<?php

$customHeadings["state"] = $state;
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;

    
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>

</body>

</html>