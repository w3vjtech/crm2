<?php
date_default_timezone_set('Asia/Kolkata');

$currentDate=date('Y-m-d H:i:s');
$currentTime = date('H:i:s');


 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table=$_GET['table'];



// Initialize CRUD object
$dynamicCRUD = new crud($table, $con);

$data = json_decode(file_get_contents('php://input'), true);

  print_r($data);
  
  
  
  
 if($table=="tsm_work_book"){
     
     foreach ($data as $entry) {

$entry['last_upadte_date']=$currentDate;
  if($entry['id']!=""){  
      $id =$entry['id'];
      
   $sql = "SELECT * FROM tsm_work_book where id='$id'";
   $result = mysqli_query($con, $sql);
   $row = mysqli_fetch_assoc($result);
   
            
 if (empty($row['am_10_time']) && !empty($entry['am10_remarks'])) {
    $entry['am_10_time'] = $currentTime; 
}

if (empty($row['pm_1_time']) && !empty($entry['pm1_remarks'])) {
    $entry['pm_1_time'] = $currentTime; 
}

if (empty($row['pm_8_time']) && !empty($entry['no_of_call_attended'])) {
    $entry['pm_8_time'] = $currentTime; 
}
      
   $response = $dynamicCRUD->update($entry['id'], $entry);  
  
  }else{ 
    
if (!empty($entry['am10_remarks'])) {
    $entry['am_10_time'] = $currentTime; 
}

if (!empty($entry['pm1_remarks'])) {
    $entry['pm_1_time'] = $currentTime; 
}

if (!empty($entry['no_of_call_attended'])) {
    $entry['pm_8_time'] = $currentTime; 
}

    $response = $dynamicCRUD->create($entry);
  }  
}

    
}else{

foreach ($data as $entry) {
  if($entry['id']!=""){  
   $response = $dynamicCRUD->update($entry['id'], $entry);  
  }else{ 
    $response = $dynamicCRUD->create($entry);
  }  
}

}
// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>