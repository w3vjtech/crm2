<?php

 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();



include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
 $table='transaction_summary';

$customHeadings = [
  
  
    "id" => 'textContent',
    "date" => 'date',
    "name" => 'textContent',
    "location" => 'textContent',
    "client" => 'textContent',
    "item" => 'textContent',
   "approved"  => 'selectValue',
    "remarks" => 'textContent',
    "transaction_in" => 'textContent',
    "transaction_out" => 'textContent',
     "invoices" => 'textContent',
    ];
 
 
 
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">
<div class='d-flex'>
<?php
include'header.php';
?>
  <div class="wrapper p-10 w-100">

<?php include'top-bar.php'; ?>



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

<h6 class="card-title m-0">Transaction Summary</h6>

   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

    
  <div class='d-flex'>
      
 
 <div>

   <table id="editable-table">
        <thead>
                
            <tr>  
            
        
<th>date</th>
<th>name</th> 
<th>location</th> 
<th>client</th> 
<th>item</th> 
<th>approved</th>
<th>remarks</th>
<th>In</th>
<th>Out</th>
<th>invoices</th>

            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM transaction_summary WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
         
<td class='d-none'><?php echo $row["id"]; ?></td>
       
<td>   
 <input type="date"  value="<?php echo $row["date"]; ?>">
</td>
<td contenteditable><?php echo $row["name"]; ?></td>

<td contenteditable><?php echo $row["location"]; ?></td>

<td contenteditable><?php echo $row["client"]; ?></td>

<td contenteditable><?php echo $row["item"]; ?></td>

<td>
  <select>
    <option value="<?php echo $row["approved"]; ?>"> <?php echo $row["approved"]; ?> </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td contenteditable><?php echo $row["remarks"]; ?></td>

<td contenteditable><?php echo $row["transaction_in"]; ?></td>

<td contenteditable><?php echo $row["transaction_out"]; ?></td>

<td contenteditable><?php echo $row["invoices"]; ?></td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>



  <button id="submit-button" <?php if($type != "FM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
   <button onclick="addTableRow()">Add Row</button>
  
 </div>  
 
  </div> 
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
 <td class='d-none'></td>
<td>   
 <input type="date"  value="">
</td>
<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td>
  <select>
    <option value="">  </option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




<?php
$customHeadings["state"] = $state;
 $customHeadings["month"] = $month;
 $customHeadings["year"] = $year;
 
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');


?>

                 
          
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
 <?php
include'footer.php';
?>  </div>
    
</div>
</body>

</html>