<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
   
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='screening';

$customHeadings = [
    
 
    
    "id" => 'textContent',
"first_level_interviewer" => 'textContent',
"source_of_cv" => 'textContent',
"candidate_name" => 'textContent',
"location" => 'textContent',
"contact_no" => 'textContent',
"email" => 'textContent',
"first_level_status" => 'selectValue',
"first_level_remarks" => 'textContent',
"second_level_interviewer" => 'textContent',
"second_level_status" => 'selectValue',
"second_level_remarks" => 'textContent',
"third_level_interviewer" => 'textContent',
"third_level_status" => 'selectValue',
"technical_test_marks" => 'textContent',
"third_level_remarks" => 'textContent',
];
 
 



    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>


<section>
    

<div class='sidebar'>
        <?php
    include'header.php';
    ?>

</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

    
    <div class="position-sticky l-0 z-4 bg-white">

     <h6  class="pt-5">screening</h6>
    
    
 <?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>



        </div>   
    
    <?php
if($date!=""){    
?>       


<div id="clipboard">
    
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
  <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM screening WHERE 1";

if(!empty($state)){
  $sql .= " AND state='$state'";
}
if(isset($date)){
  $sql .= " AND date='$date'";
}


//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
    <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["first_level_interviewer"]; ?></td> 


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["source_of_cv"]; ?></td> 


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["candidate_name"]; ?></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["location"]; ?></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["contact_no"]; ?></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["email"]; ?></td> 


<td>
 <select class="<?php echo ($row["first_level_status"] == "SELECTED") ? 'bg-primary text-white' : '';?>">
    <option value="<?php echo $row["first_level_status"]; ?>"><?php echo $row["first_level_status"]; ?></option>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<option value="NOT CONNECTED">NOT CONNECTED</option>
<?php } ?>
  </select> 
 </td>


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["first_level_remarks"]; ?></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["second_level_interviewer"]; ?></td> 

<td>
 <select class="<?php echo ($row["second_level_status"] == "SELECTED") ? 'bg-primary text-white' : '';?>">
    <option value="<?php echo $row["second_level_status"]; ?>"><?php echo $row["second_level_status"]; ?></option>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<?php } ?>
  </select> 
 </td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["second_level_remarks"]; ?></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["third_level_interviewer"]; ?></td> 
<td>
 <select class="<?php echo ($row["third_level_status"] == "SELECTED") ? 'bg-primary text-white' : '';?>">
    <option value="<?php echo $row["third_level_status"]; ?>"><?php echo $row["third_level_status"]; ?></option>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<?php } ?>
  </select> 
 </td>
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["technical_test_marks"]; ?></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["third_level_remarks"]; ?></td> 


      </tr>

        <?php
    }
}
?>

</tbody>
    </table>
</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "HR" && $type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()" style="<?php if($type != "HR" && $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "display: none;"; ?>" >Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
           
<td class='d-none'></td>


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 


<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 


<td>
 <select>
       <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<option value="NOT CONNECTED">NOT CONNECTED</option>
<?php } ?>
  </select> 
 </td>
 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td>
 <select>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<?php } ?>
  </select> 
 </td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 
<td>
 <select>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SELECTED">SELECTED</option>
<option value="REJECTED">REJECTED</option>
<?php } ?>
  </select> 
 </td>
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>





<?php
}
?>


<?php
$customHeadings["state"] = $state;
$customHeadings["date"] = $date;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');

$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



    </div>
    <div class='footer'>
        
     <?php
    include'footer.php';
    ?>  
    </div>
    
</div>
</section>


</body>

</html>