<?php
if(empty($email)){
    header("Location: index"); 
}
   include("db.php");
   

          
      $sql = "SELECT * FROM login WHERE user_id = '$email'";

      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     
      $count = mysqli_num_rows($result);
		
      if($count == 1) {
   $name=$row['name'];
   $email=$row['user_id'];
   $type=$row['type'];
   $state_access=$row['state'];
   $profile=$row['profile'];
      }else {
            header("Location: index"); 
      }

?>

<?php
$allaccess = in_array($type, ["GM", "FM", "HR", "MD"]);

$specificaccess = in_array($type, ["TL", "TSM", "RM", "ZM"]);

$logo = 'white';
?>


 <nav class='h-100vh overflow-overlay  pt-50 p-10  l-0 bg-primary'>
    <div class='d-flex justify-content-center'>
    <img   src="https://wbinfs.in/assets/logo-bg-white.png" height='75px' ></img>
   </div>
      <div class='menu pt-50 d-flex  flex-direction-column align-items-flex-start justify-content-space-between'>
    
      
       
        
<?php

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Function to recursively build the tree menu as an HTML unordered list
function buildTree($parent_id = NULL, $con) {
    global $type; 
    $query = "SELECT * FROM menu WHERE FIND_IN_SET('$type', access) > 0 AND parent_id " . ($parent_id ? "= $parent_id" : "IS NULL"). " ORDER BY order_id";
    $result = $con->query($query);

    if ($result->num_rows > 0) {
        echo "<ul>"; // Start the unordered list
        while ($row = $result->fetch_assoc()) {
            // Output the menu item as a list item
            
            
            echo "<li> <div class='d-flex justify-content-flex-start gap-10 align-content-center align-items-center menu_icon'> " . $row['icon'] . "<a href='" . $row['url'] . "'>" . $row['page'] . "</a> </div>";
            
            if($row['url']==""){
echo '<button class="showButton"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6.91 12.65"  ><g id="a7f88036-326e-4150-88c4-9d6b8a1610b0" data-name="Layer 2"><g id="e414f6f0-4d54-48dd-b0d5-dd4fdc6de053" data-name="Layer 1"><line x1="0.5" y1="0.5" x2="6.41" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.41" y1="6.41" x2="0.5" y2="12.15" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg></button> ';
}
            // Recursive call for children
            buildTree($row['id'], $con);

            echo "</li>"; // Close the list item
        }
        echo "
        
       
        </ul>"; // Close the unordered list
    }
}

// Call the function to build the tree menu starting from the top-level items
buildTree(NULL, $con);


?>
 <li class='pt-30'><a class='text-white' href='logout.php'>Sign Out</a></li>
</div>
</nav>



 <script>
        
        var buttons = document.querySelectorAll('.showButton');

        buttons.forEach(function(button) {
            button.addEventListener('click', function() {
                var ul = this.nextElementSibling;
                if (ul.style.display === 'none') {
                    ul.style.display = 'block';
                    this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12.65 6.91" ><g id="b5abdd3f-8659-4748-bdbe-779c8f04327b" data-name="Layer 2"><g id="e32df425-7f56-4e14-8b91-f6b1b51ef6c6" data-name="Layer 1"><line x1="12.15" y1="0.5" x2="6.24" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.24" y1="6.41" x2="0.5" y2="0.5" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg>';
                } else {
                    ul.style.display = 'none';
                    this.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6.91 12.65" ><g id="a7f88036-326e-4150-88c4-9d6b8a1610b0" data-name="Layer 2"><g id="e414f6f0-4d54-48dd-b0d5-dd4fdc6de053" data-name="Layer 1"><line x1="0.5" y1="0.5" x2="6.41" y2="6.41" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/><line x1="6.41" y1="6.41" x2="0.5" y2="12.15" style="fill:none;stroke:#fff;stroke-linecap:round;stroke-miterlimit:10"/></g></g></svg>';
                }
            });
        });
    </script>                         