<?php

 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
    $table='sales';

$customHeadings = [
    "id" => 'textContent',
    "items" => 'textContent', 
    "amount" => 'textContent'
   
    
    ];
 
 $table2='expenses';

$customHeadings2 = [
    "id" => 'textContent',
    "items" => 'textContent', 
    "amount" => 'textContent'
   
    
    ];
 
 
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body class="layout-1" data-luno="theme-black">
<div class='d-flex'>
<?php
include'header.php';
?>
  <div class="wrapper p-10 w-100">

<?php include'top-bar.php'; ?>



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">Sales Expenses</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
              </div>
              </div>
              <div class="card-body">

  
  


   <?php
$list = ['state'=>$state, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

    
    <?php
if($state!="" AND $month!="" AND $year!=""){    
?>
    
  <div class='d-flex gap-20'>
      
 
 <div>

   <table id="editable-table">
        <thead>
                
            <tr>  
  <th> items</th>  
 <th>amount</th>
            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM sales WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
         
<td class='d-none'><?php echo $row["id"]; ?></td>

<td contenteditable><?php echo $row["items"]; ?></td>
<td contenteditable><?php echo $row["amount"]; ?></td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>


<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "FM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
   <button  onclick="addTableRow()">Add Row</button>
  </div>
 </div>  
  <div>

   <table id="editable-tableexpenses">
        <thead>
                
            <tr> 
            <th> items</th>  
 <th>amount</th>  
            </tr>
        </thead>
        <tbody>
   

<?php
$sql = "SELECT * FROM expenses WHERE 1 ";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
         
<td class='d-none'><?php echo $row["id"]; ?></td>



<td contenteditable><?php echo $row["items"]; ?></td>
<td contenteditable><?php echo $row["amount"]; ?></td>

        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>


<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button2" <?php if($type != "FM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button2">Export to Excel</button>
    <button onclick="addTableRow2()">Add Row</button>
 </div>
  </div>  
  </div> 
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
 <td class='d-none'></td>

<td contenteditable></td>
<td contenteditable> </td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>


<script>

function addTableRow2() {
  var table = document.getElementById("editable-tableexpenses").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
 <td class='d-none'></td>
<td contenteditable></td>
<td contenteditable> </td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}



function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>


<?php
}
?>

<?php
 $customHeadings["state"] = $state;
 $customHeadings["month"] = $month;
 $customHeadings["year"] = $year;
        

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');


?>

<?php
 $customHeadings2["state"] = $state;
 $customHeadings2["month"] = $month;
 $customHeadings2["year"] = $year;
        
        
$ExportButton2 = new ExportButton();
echo $ExportButton2 = $ExportButton2->renderScript($customHeadings2, 'editable-tableexpenses', 'export-button2');

$SubmitButton2 = new SubmitButton();
echo $SubmitButton2 = $SubmitButton2->renderScript($customHeadings2, $table2, 'editable-tableexpenses', 'submit-button2');




?>

                 </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
 <?php
include'footer.php';
?>  </div>
    
</div>
</body>

</html>