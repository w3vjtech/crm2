<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='customer_escalation_matrix';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>

</head>

<body>
 
<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
          <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">WBI Organization Chart</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
     <?php
function generateOrgChartFromDB($parent_id = NULL, $con) {
    $html = '';
    $query = "SELECT * FROM wbi_hr_organization_chart WHERE parent_id " . ($parent_id ? "= $parent_id" : "IS NULL") . " ORDER BY order_id";
    $result = $con->query($query);

    if ($result->num_rows > 0) {
        $html .= "<ul>";
        while ($row = $result->fetch_assoc()) {
            $html .= "<li><div> <a><p class='fs-10'>" .$row['name'] ."</p><p class='fs-10'>" .$row['designation'].  "</p> </a></div>";
            $html .= generateOrgChartFromDB($row['id'], $con);
            $html .= "</li>";
        }
        $html .= "</ul>";
    }

    return $html;
}

// Output the organizational chart
echo '<div class="org-chart">';
echo generateOrgChartFromDB(NULL, $con);
echo '</div>';

?>
             
                  
                  


<style>
  .org-chart ul {
                padding-top: 20px;
                position: relative;
                transition: all .5s;
                -webkit-transition: .5s;
                -moz-transition: .5s;
                list-style-type: none!important
            }

            .org-chart li {
                float: left;
                text-align: center;
                list-style-type: none;
                position: relative;
                padding: 20px 2px 0;
                transition: all .5s;
                -webkit-transition: .5s;
                -moz-transition: .5s;
                list-style-type: none!important
            }

            .org-chart li::after,.org-chart li::before {
                content: '';
                position: absolute;
                top: 0;
                right: 50%;
                border-top: 1px solid #ccc;
                width: 50%;
                height: 20px
            }

            .org-chart li::after {
                right: auto;
                left: 50%;
                border-left: 1px solid #ccc
            }

            .org-chart li:only-child::after,.org-chart li:only-child::before {
                display: none
            }

            .org-chart li:only-child {
                padding-top: 0
            }

            .org-chart li:first-child::before,.org-chart li:last-child::after {
                border: 0
            }

            .org-chart li:last-child::before {
                border-right: 1px solid #ccc;
                border-radius: 0 5px 0 0;
                -webkit-border-radius: 0 5px 0 0;
                -moz-border-radius: 0 5px 0 0
            }

            .org-chart li:first-child::after {
                border-radius: 5px 0 0 0;
                -webkit-border-radius: 5px 0 0 0;
                -moz-border-radius: 5px 0 0
            }

            .org-chart ul ul::before {
                content: '';
                position: absolute;
                top: 0;
                left: 50%;
                border-left: 1px solid #ccc;
                width: 0;
                height: 20px
            }

            .org-chart li a {
                border: 1px solid #3dbdb5;
                background: #3dbdb5;
                padding: 5px 7px;
                text-decoration: none;
                color: white;
                font-family: arial,verdana,tahoma;
                font-size: 7px;
                display: inline-block;
                border-radius: 3px;
                -webkit-border-radius: 3px;
                -moz-border-radius: 3px;
                transition: all .5s;
                -webkit-transition: .5s;
                -moz-transition: .5s
            }

            .org-chart li a:hover,.org-chart li a:hover+ul li a {
                background: white;
                color: #3dbdb5;
                border: 1px solid #c1c1c1;
            }

            .org-chart li a:hover+ul li::after,.org-chart li a:hover+ul li::before,.org-chart li a:hover+ul ul::before,.org-chart li a:hover+ul::before {
                border-color: grey
            }
  </style>



              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

</body>

</html>