<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();

$table = 'screening_data';

function insert($table, $keys, $values, $con) {
    $sql = "INSERT INTO $table ($keys) VALUES ($values)";
    if (mysqli_query($con, $sql)) {
        header('Location: screening_apply?request=yes');
        exit(); // Exit after redirection
    } else {
        $_SESSION['error_message'] = "Error: " . mysqli_error($con);
        // Redirect or handle the error accordingly
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    unset($_POST['submit']);

    $keys = '';
    $values = '';

    foreach ($_FILES as $key => $value) {
        $key_name = rand(100000, 999999) . date("Ymdhis") . "-" . $value["name"];
        $key_tmp = $value["tmp_name"];
        $upload_directory = 'uploads/' . $key_name;

        if (move_uploaded_file($key_tmp, $upload_directory)) {
            $keys .= $key . ',';
            $values .= "'" . mysqli_real_escape_string($con, $key_name) . "',";
        } else {
            $_SESSION['error_message'] = "File upload failed for " . $value["name"];
            // Redirect or handle the error accordingly
        }
    }

    foreach ($_POST as $key => $value) {
        $key = mysqli_real_escape_string($con, $key);
        $value = mysqli_real_escape_string($con, $value);
        $keys .= $key . ',';
        $values .= "'" . $value . "',";
    }

    $keys .= 'action';
    $values .= "'insert'";

    $keys = rtrim($keys, ',');
    $values = rtrim($values, ',');

    insert($table, $keys, $values, $con);
}

function state()
{
    global $con;
    $sql = "SELECT * FROM state";
    $result = mysqli_query($con, $sql);
    $options = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $select = '<select name="state"  >';
    foreach ($options as $option) {
        $select .= '<option value="' . $option['name'] . '">' . $option['name'] . '</option>';
    }
    $select .= '</select>';

    return $select;
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  <style>
      label {
    display: inline-block;
    line-height: 1.3;
    font-size: 14px;
    color:#606060;
    font-family: 'Euclid Circular B Light', sans-serif;
    font-weight: normal;
     max-width: 350px;
}
.col-md-6 {
    display: flex;
    flex-direction: column;
    width: 100%;
    align-items: flex-start;
    gap: 30px;
}
input {
    background: #f7f7f7;
    color:#606060;
    height: 50px;
    width: 100%;
    margin: 10px 0px;
    padding-left:5px;
    max-width: 350px;
    border-radius: 7px;
}
input[type="date"] {
    outline: 0;
    border: 0;
    background: #f7f7f7;
}
select {
    text-align: center;
    background: #f7f7f7;
    padding: 10px;
    width: 100%;
    max-width: 350px;
    border-radius: 7px;
    height: 50px;
}
form {
    background:#f9f9f938;
    width: 100%;
    max-width: 600px;
    margin: auto;
    padding:10px;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: center;
    align-items: center;
}
form div {
    max-width: 350px;
        gap: 10px;
}
p {
    font-size: 12px;
    line-height: 1.5;
    font-family: 'Euclid Circular B Light', sans-serif;
    font-weight: normal;
     max-width: 350px;
}

.success {
    overflow:hidden;
    background: #3dbdb5;
    color: black;
    padding: 25px;
    height: 100vh;
    position: fixed;
    width: 100vw;
    top: 0px;
    left: 0px;
    display: flex;
    flex-direction: row;
    align-content: center;
    justify-content: center;
    align-items: center;
}
body {
   overflow: overlay;
}
  </style>
</head>

<body>


    <?php if(!empty($_GET['request'])){
echo "<div class='success'><p class='request'> REQUEST SEND SUCCESSFULLY </p></div>";
}
?>

              <div class="card-body">
<div class='text-center p-50'>
     <h6 class="Euclid-Circular-B-SemiBold fs-32">WBI- FIRST LEVEL SCREENING PROCEDURE</h6>
                 <h5 class="Euclid-Circular-B-Light fs-26">WETZEL BARRON INFOSYSTEM PVT LTD</h5>
               
</div>
    <!-- Display the add/edit screening form -->
          <form method="POST" action="" class="card-body" enctype="multipart/form-data">
       <div> 
        <input oninput="OnInput(event)" type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
    <div class="row g-3">    
    
<input type="hidden" name="apply_date" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['apply_date'] : date('Y-m-d'); ?>" required>


         <div class="col-md-6">
              <label class="form-label">CANDIDATE NAME:</label>
        <input oninput="OnInput(event)" type="text" name="name" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['name'] : ''; ?>"   required>
       </div>
   <div class="col-md-6">
              <label class="form-label">DOB:</label>
        <input type="date" name="dob" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['dob'] : ''; ?>"   required>
       </div>

       <div class="col-md-6">
    <label class="form-label">AGE:</label>
    <select name="age" required>
         <option value="<?php echo isset($_GET['edit']) ? $pageresults[0]['age'] : ''; ?>"> <?php echo isset($_GET['edit']) ? $pageresults[0]['age'] : 'Select'; ?></option>
        <?php
        $selectedAge = isset($_GET['edit']) ? $pageresults[0]['age'] : ''; // Get the selected age if editing
        for ($i = 18; $i <= 35; $i++) {
            $selected = ($i == $selectedAge) ? 'selected' : ''; // Check if the option should be selected
            echo "<option value=\"$i\" $selected>$i</option>";
        }
        ?>
    </select>
    
</div>
       
       <div class="col-md-6">
              <label class="form-label">MARITAL  STATUS:</label>
           <div class='selectmenu'>
              
              <input type="radio" name="marital_status" value="single" <?php if (isset($_GET['edit'])) { echo $pageresults[0]['marital_status'] === 'single' ? 'checked' : ''; } ?>>

<label>Single</label>
<input type="radio" name="marital_status" value="married" <?php if (isset($_GET['edit'])) { echo $pageresults[0]['marital_status'] === 'married' ? 'checked' : ''; } ?>>

<label>Married</label>
</div>
</div>
       
 
  <div class="col-md-6">
              <label class="form-label">STATE NAME:</label>
    <select name="state" >
    <option value="<?php echo isset($_GET['edit']) ? $pageresults[0]['state'] : ''; ?>"> <?php echo isset($_GET['edit']) ? $pageresults[0]['state'] : 'Select'; ?></option>
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
} 
?>
</select>

       </div>

  <div class="col-md-6">
              <label class="form-label">DISTRICT NAME:</label>
        <input type="text" name="district" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['district'] : ''; ?>"  required>
       </div>
       
       
         <div class="col-md-6">
              <label class="form-label">WORK LOCATION:</label>
        <input type="text" name="work_location" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['work_location'] : ''; ?>"  required>
       </div>
       
 <div class="col-md-6">
              <label class="form-label">HOME LOCATION:</label>
        <input type="text" name="home_location" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['home_location'] : ''; ?>"   required>
       </div>
       
       
 <div class="col-md-6">
              <label class="form-label">RESIDENTIAL ADDRESS:</label>
        <input type="text" name="residential_address" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['residential_address'] : ''; ?>"   required>
       </div>
       
       <div class="col-md-6">
              <label class="form-label">PIN CODE:</label>
        <input type="text" name="pin_code" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['pin_code'] : ''; ?>"   required>
       </div>
       

 <div class="col-md-6">
              <label class="form-label">CANDIDATE PHONE NO:</label>
        <input type="tel" name="phone" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['phone'] : ''; ?>"   required>
       </div>

 <div class="col-md-6">
              <label class="form-label">CANDIDATE E-MAIL ID:</label>
        <input type="email" name="email" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['email'] : ''; ?>"   required>
       </div>
       
      <div class="col-md-6">
              <label class="form-label">ACADEMIC QUALIFICATION:</label>
              <p>(APPLICANT SHOULD HAVE ITI / DIPLOMA / DEGREE OR BACHELOR DEGREE)</p>
        <input type="text" name="academic_qualification" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['academic_qualification'] : ''; ?>"   required>
       </div>  

     <div class="col-md-6">
              <label class="form-label">FIELD WORK EXPERIENCE:</label>
        <input type="text" name="field_work_experience" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['field_work_experience'] : ''; ?>"  required>
       </div>
       
       

<div class="col-md-6">
              <label class="form-label">ATM E-SURVEILLANCE EXPERIENCE:</label>
        <input type="text" name="atm_esurveillance_experience" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['atm_esurveillance_experience'] : ''; ?>"   required>
       </div>
       <div class="col-md-6">
              <label class="form-label">YEAR OF EXPERIENCE:</label>
        <input type="text" name="year_of_exprience" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['year_of_exprience'] : ''; ?>"   required>
       </div>
       
       <div class="col-md-6">
              <label class="form-label">RECENT COMPANY JOB ROLE AND SALARY:</label>
        <input type="text" name="recent_company_job_role_and_salary" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['recent_company_job_role_and_salary'] : ''; ?>"   required>
       </div>


<div class="col-md-6">
              <label class="form-label">RECENT COMPANY DETAILS AND ONE REFERENCE NO:</label>
        <input type="text" name="recent_company_details_and_two_reference_no" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['recent_company_details_and_two_reference_no'] : ''; ?>"  required>
       </div>
<div class="col-md-6">
              <label class="form-label">BASIC COMPUTER  HARDWARE AND SOFTWARE KNOWLEDGE:</label>
        <input type="text" name="computer_knowledge_hardware_and_software" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['computer_knowledge_hardware_and_software'] : ''; ?>"   required>
       </div>

<div class="col-md-6">
              <label class="form-label">CANDIDATE HAVING TWO WHEELER AND LICENCE:</label>
              <p>(MENTION LICENCE NUMBER)</p>
        <input type="text" name="candidate_have_two_wheeler_and_license" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['candidate_have_two_wheeler_and_license'] : ''; ?>"   required>
       </div>
  
       
          <div class="col-md-6">
              <label class="form-label">CANDIDATE HAVING LAPTOP:</label>
        <input type="text" name="candidate_have_laptop" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['candidate_have_laptop'] : ''; ?>"   required>
       </div>

  <div class="col-md-6">
              <label class="form-label">CANDIDATE CAN ASSURE PHONE WHATSAPP AVAILABILITY:</label>
        <input type="text" name="candidate_can_assure_phone_watsapp_availability" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['candidate_can_assure_phone_watsapp_availability'] : ''; ?>"   required>
       </div>
      <div class="col-md-6">
              <label class="form-label">PAYMENT MODE PREFERRED SALARY PERCALL BASIS /FIXED SALARY:</label>
        <input type="text" name="payment_mode_preferred_salary_percall_basis" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['payment_mode_preferred_salary_percall_basis'] : ''; ?>"   required>
       </div>   

 <div class="col-md-6">
              <label class="form-label">WILLINGNESS TO RELOCATE IF REQUIRED:</label>
        <input type="text" name="willingness_to_relocate_If_required" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['willingness_to_relocate_If_required'] : ''; ?>"   required>
       </div>   
<div class="col-md-6">
              <label class="form-label">LANGUAGES KNOWN:</label>
        <input type="text" name="languages_known" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['languages_known'] : ''; ?>"   required>
       </div>   
<div class="col-md-6">
              <label class="form-label">TWO REFERENCE PHONE NUMBER FROM FAMILY:</label>
        <input type="text" name="reference_phone_number_from_family" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['reference_phone_number_from_family'] : ''; ?>"  required>
       </div>   
<div class="col-md-6">
              <label class="form-label">WILLINGNESS TO IMMEDIATELY JOIN:</label>
        <input type="text" name="willingness_to_immediately_join" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['willingness_to_immediately_join'] : ''; ?>"   required>
       </div>   

<div class="col-md-6">
              <label class="form-label">CURRENTLY WORKING:</label>
        <input type="text" name="currently_working" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['currently_working'] : ''; ?>"   required>
       </div>   
<div class="col-md-6">
              <label class="form-label">NOTICE PERIOD DURATION:</label>
        <input type="text" name="notice_period_duration" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['notice_period_duration'] : ''; ?>"  required>
       </div> 

<div class="col-md-6">
              <label class="form-label">ADDITIONAL REMARKS:</label>
        <input type="text" name="additional_remarks" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['additional_remarks'] : ''; ?>"   required>
       </div> 
<div class="col-md-6">
              <label class="form-label">LINKEDIN:</label>
        <input type="text" name="linkedin" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['linkedin'] : ''; ?>"   required>
       </div> 
       
       <div class="col-md-6">
              <label class="form-label">IF SELECTED HOW MANY DAYS YOU NEED TO SUBMIT POLICE CLEARANCE CERTIFICATE?</label>
        <input type="text" name="police_clearance_certificate" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['linkedin'] : ''; ?>"   required>
       </div> 
       
       
       <div class="col-md-6">
              <label class="form-label">UPLOAD CV:</label>
        <input type="file" name="upload_recent_photo" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['linkedin'] : ''; ?>"   required>
       </div> 

           <div class="card-footer">
                <button type="submit" name="submit" class="w-60 p-15 mt-30 mb-30 mx-auto">SUBMIT</button>
              </div>
    </form>
  

             
              </div>
            </div>
            </div>
         
    
    
    <style>
        p.request {
    background:white;
    color: #606060;
    padding: 50px;
}
input[type="radio"]:checked {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-color: #3dbdb5;
    border: 1px solid #ccc;
}
    </style>
    
    
 </div>
  
  


  <script>
  const inputElements = document.querySelectorAll("input[type='text']");

  inputElements.forEach(function(inputElement) {
    inputElement.addEventListener('input', function(event) {
      const currentInput = event.target.value;
      const uppercaseInput = currentInput.toUpperCase();
      event.target.value = uppercaseInput;
    });
  });
  
  

  const dateInputs = document.querySelectorAll("input[type='date']");

  dateInputs.forEach(function(dateInput) {
    dateInput.setAttribute('min', '1988-01-01');
  });
</script>


  <style>

ul.dtr-details {
    list-style: none;
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    align-items: flex-start;
    gap: 20px;
}

.table.dataTable .dtr-details li {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 30px;
    border-bottom: 1px solid;
    width: 100%;
}

.table.dataTable .dtr-details li span {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    width: 50%;
    text-align: left;
}

html {
text-transform: capitalize;
}
  </style>
</body>

</html>