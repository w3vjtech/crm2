

<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="keyword" content="">
  <link rel="icon" href="https://wbinfs.com/wp-content/uploads/2021/05/favicon.png" type="image/x-icon"> <!-- Favicon-->
  <title>HRMS Dashboard</title>
  
  
   
 <link rel="stylesheet" href="style.php">
 <style>
*, *::before, *::after { 
      
      background: transparent;
 }
 html {
     color: #606060;
 }



    
    input[type="checkbox"] {
      position: relative;
      padding-left: 25px;
      cursor: pointer;
    }

input[type="checkbox"]:before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 18px;
      height: 18px;
      border: 2px solid #ccc;
      background-color: #fff;
    }

     

    input[type="checkbox"]:checked:before {
      content: "\2713"; 
      font-size: 18px;
      color:white; 
      background:#3dbdb5;
      border: 2px solid #3dbdb5;
      position: absolute;
      top:0;
      left:0;
    }
    

    input#table-search {
    border: 1px solid #3dbdb5;
    margin-right: 10px;
    border-radius: 3px;
    padding:7px;
}
 
   select {
      -webkit-appearance: none;
      -moz-appearance: none;
      appearance: none;
      font-size: 14px; 
      padding:7px;
      outline: none;
      cursor: pointer;
    color: #606060;
    border: 0.2px solid #cccc;
    border-radius: 4px;
    }
    
.card {
    padding: 25px;
}
thead {
  position: sticky;
  top: 0; 
  z-index: 1050;
  background: white;
}



td.email {
    text-transform: lowercase;
}
table {
    margin: 30px 0px;
}
table, th,tr, td {
    background:white;
    border-collapse: collapse;
    border: 0.2px solid #cccc;
}

td select {
    font-size: 14px;
    font-family: 'Euclid Circular B Regular', sans-serif;
    font-weight: normal;
    text-align: center;
    background: #f9f9f9;
    color: #606060;
    padding: 5px;
    border:none;
    border-radius: 3px;
}
div {
    line-height: normal;
}

     th {
         font-size: 16px;
         line-height:1.5;
         color:#606060;
         font-family: 'Euclid Circular B Regular', sans-serif;
         font-weight: normal;
         padding:3px;
         background: #fcfcfc;
     }
     td {
         font-size: 14px;
         font-family: 'Euclid Circular B Regular', sans-serif;
         font-weight: normal;
        line-height: 1.5;
        padding: 3px;
        color:#606060;
        text-align: center;
     }
     
     td select {
    background: transparent;
    color: #606060;
    padding: 5px;
    border-radius: 3px;
    width: 100%;
    line-height: 1.5;
}
    
  
 tr:hover td , tr:hover td select, tr:hover td input {
     background-color: #3dbdb5;
     color:white;
 }


form.searc-form {
    padding:50px 0px;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content: flex-start;
    align-items: center;
    gap: 50px;
}
form.searc-form label,form.searc-form select,form.searc-form input {
font-size: 16px;


}

     select {
         text-align: center;
     }
     
     .result {
    display: flex;
    flex-wrap: wrap;
    flex-direction: row;
    align-content: center;
    justify-content: flex-end;
    align-items: center;
    gap: 50px;
    padding: 7px 60px;
   
}
.result p {
     font-size: 10px !important;
}

button {
    background: #3dbdb5;
    padding: 12px 23px;
    color:white;
}
    form div {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-content: center;
    justify-content:flex-start;
    align-items: center;
    gap: 7px;
}


input.search {
    outline: 0;
    border: 0;
    padding: 7px 24px;
    position:relative !important;
    background:#3dbdb5;
    color:white !important;
    border-radius: 3px;
}

form.search-form {
    display: flex;
    align-content: center;
    justify-content: flex-start;
    align-items: center;
}

input[type="date"] {
      outline: 0;
    border: 0;
    background: transparent;
}


h6.card-title {
    font-size: 15px;
    line-height: 3.5;
     font-family: 'Euclid Circular B medium', sans-serif;
    font-weight: normal;
}
footer {
    
    padding:25px;
}
footer p,footer a {
    font-size: 9px;
    text-align: left;
}

   input[type="radio"]{
     width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            display: inline-block;
            vertical-align: middle;
            text-align: center;
            line-height: 20px;
            color: green;
            font-size: 16px;
   }
   /* Remove default styling for checked input boxes */
input[type="radio"]:checked {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  background-color: transparent;
  border: none;
  outline: none;
  /* You can add other reset properties here */
}

        input[type="radio"].checkmark-checkbox:checked::before {
            content: "✓";
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            display: inline-block;
            vertical-align: middle;
            text-align: center;
            line-height: 20px;
            color: green;
            font-size: 16px;
        }

        input[type="radio"].crossmark-checkbox:checked::before {
            content: "✕";
            color: red;
                width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            display: inline-block;
            vertical-align: middle;
            text-align: center;
            line-height: 20px;
            font-size: 16px;
        }
        .wrapper {
        width: calc(100% - 300px) !important;
}




nav {
    text-transform: capitalize;
    position: sticky;
    top: 0px;
    z-index:1050;
    width: 300px;
}
.overflow-overlay {
    overflow: overlay;
}
    .menu ul li button {
    display:block;
    }  


.menu {
    position: relative;
    width:100%;
    max-width:700px;
}

.menu ul {
  width:100%;
  list-style: none;
  padding: 0;
  margin: 0;
  gap: 30px;
  display: flex;
  flex-direction: column;
}





/* This hides the dropdowns */


.menu li ul { display: none; }

.menu ul li a {
  display: block;
  text-decoration: none;
  white-space: nowrap;
  color: white;
  line-height: 2.5;
  font-family: 'Euclid Circular B Regular', sans-serif;
    font-weight: normal;
}






.menu li ul li { border-top: 0; }

/* Displays second level dropdowns to the right of the first level dropdown */






.menu ul:after { clear: both; }




.menu ul li a {
    width: 80%;
    
}

.menu ul li  {
    width: 100%;
    position: relative;
}
button.showButton svg {
    width: 20px;
    height: 20px;
}
.menu li button {
    position: absolute;
    right: 15px;
    top: 0px;
    margin:0px;
    padding:0px;
}
.menu_icon svg {
    height: 20px;
    width:20px;
    fill: white;
}


body {
    height: 100vh;
    width: 100%;
    overflow: hidden;
    box-sizing: border-box;
}
    section {
    height: 100vh;
    display: flex;
    gap: 20px;
    box-sizing: border-box;
}

.sidebar {
    background: black;
    width: 300px;
    height: 100vh;
}
.main {
    width: calc(100% - 320px);
    height: 100vh;
    display: flex;
    flex-direction: column;
    gap: 20px;
    padding-right: 20px;
}
.nav {
    height: 100px;
    width: 100%;
}

.page {
    height: calc(100vh - 100px);
    width: 100%;
    overflow: overlay;
    position: relative;
}
.footer {
    height: 50px;
    width: 100%;
    display:none;
}

.page button {
    background: #535353;
    padding: 12px 23px;
    color: white;
    border-radius: 3px;
}
</style>
    
 
<script src="js/html2canvas.min.js"></script>

