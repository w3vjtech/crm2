<?php
error_reporting(0);

 $date1='01'.date("/m/Y");
 $date2='31'.date("/m/Y");
$con = mysqli_connect('localhost', 'u309659183_fieldsupport', 'Ben824855', 'u309659183_fieldsupport');
  
function view($con,$sql)
{
 $result=mysqli_query($con,$sql);

 
while($row = $result->fetch_assoc()){
 $data[]=$row;
 $datas=json_encode($data);
 
 
}
 return json_decode($datas);
 
}
$sql="SELECT * FROM activity";

$activity = view($con,$sql);


 
 $sql = "SELECT * FROM engineer_works WHERE   date BETWEEN '$date1' AND '$date2'";
   
   $summery = view($con,$sql);
   
   
   foreach($activity as $mydata)
{  $name=$mydata->name;
foreach($summery as $mydata)
{
 $sactivity=$mydata->activity;
if($name==$sactivity){
   $bill[$sactivity] +=1;
}}}

foreach($activity as $mydata)
{
$no=$bill[$mydata->name];
$amount=$mydata->amount;
$total=$amount*$no;
if(!empty($no)){
$maintotal +=$total;
}
}
$contents.=$maintotal;	
$contents = strip_tags($contents);
?>
