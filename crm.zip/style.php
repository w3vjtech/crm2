<?php 
$css='';
error_reporting(0);

 ob_start();
 ob_start("minifier");function minifier($code){$search=array('/ {2,}/','/<!--.*?-->|\t|(?:\r?\n[ \t]*)+/s');$replace=array(' ','');$code=preg_replace($search,$replace,$code);return $code;} ?>

<?php
header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0");
clearstatcache();

$fontDirectory = 'fonts';
$fontFiles = glob($fontDirectory . '/*.ttf');

foreach ($fontFiles as $fontFile) {
    $fontName = basename($fontFile, '.ttf');
    $font_class= str_replace(' ', '-', $fontName);

    $css .= "
@font-face {
    font-family: '$fontName';
    src: url('$fontFile') format('truetype');
}

.$font_class {
    font-family: '$fontName', sans-serif;
    font-weight: normal;
}


";


}

header("Content-type: text/css");

$sm='600';
$md='1024';

$screenSizes = array(0, $sm, $md);
$screen = array('', 'sm-', 'md-');


$html = array(12, 14, 15, 16,18.5);

$text_align = array('left', 'right', 'center', 'justify');
$align_items = array('flex-start', 'flex-end', 'center', 'baseline', 'stretch');
$align_content = array('flex-start', 'flex-end', 'center', 'space-between', 'space-around', 'stretch');
$justify_items = array('flex-start', 'flex-end', 'center', 'space-between', 'space-around', 'stretch');
$justify_content = array('flex-start', 'flex-end', 'center', 'space-between', 'space-around', 'stretch');
$position = array('static', 'relative', 'absolute', 'fixed', 'sticky');
$display = array('block', 'inline', 'inline-block', 'flex', 'grid', 'none');
$float = array('left', 'right', 'none');
$flex_wrap = array('wrap', 'nowrap');
$flex_direction = array('row', 'column','row-reverse','column-reverse');
$background_repeats = array('repeat', 'repeat-x', 'repeat-y', 'no-repeat');
$background_positions = array('top', 'bottom', 'left', 'right', 'center','25%','50%','75%','100%');
$background_sizes = array('cover', 'contain', 'auto', '100% 100%', '50% 50%');
$background_origins = array('padding-box', 'border-box', 'content-box');
$background_attachments = array('scroll', 'fixed', 'local');
$background_blend_modes = array(
    'normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 
    'color-dodge', 'color-burn', 'hard-light', 'soft-light', 
    'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'
);

$background_clips = array('border-box', 'padding-box', 'content-box');



$cssProperties = array(
    'height' => 'h',
    'width' => 'w',
    'min-height' => 'min-h',
    'min-width' => 'min-w',
    'top'=> 't',
    'bottom'=> 'b',
    'left'=> 'l',
    'right'=> 'r',
);


$font_size = range(0, 150);

$line_height = array();

for ($i = 0.7; $i <= 3; $i += 0.1) {
    $line_height[number_format($i, 1)] = str_pad($i*10, 2, '0', STR_PAD_LEFT);
}



$range = array();

$units = array('vh', 'vw', '%');
$increments = range(0, 100);


foreach ($increments as $increment) {
  foreach ($units as $unit) {
    $range[] = $increment . $unit;
  }
}
$range[]='auto';
$range[]='max-content';

echo <<<CSS
@charset "UTF-8";

*, *::before, *::after {
    box-sizing: border-box;
    padding: 0px;
    margin: 0px;
    line-height: 0.9;
    list-style: none;
    border: 0px;
    outline: 0px;
    vertical-align: baseline;
    text-decoration: none;
    scroll-behavior: smooth;
    text-wrap: nowrap !important;
}
*::-webkit-scrollbar {
  display: none;
}
.clear-both{
    clear: both;
}
.logo {
    height: 50px;
}

html {
    font-size: 16px;
    font-family: Regular,sans-serif;
}
h1,h2,h3,h4,h5,h6{
    line-height: 1.1;
}


h1 {
  font-size:70px;
   line-height: 1.1;
}

h2 {
  font-size:58px;
   line-height: 1.2;
}

h3 {
  font-size:42px;
   line-height: 1.3;
}

h4 {
  font-size: 36px;
   line-height: 1.4;
}

h5 {
  font-size: 28px;
   line-height: 1.5;
}

h6 {
  font-size: 22px;
  line-height: 1.5;
}

p {
    font-size:17px;
    line-height: 1.5;
/*    letter-spacing: 1.5px;
    word-spacing: 8px;
    line-break: anywhere;
    */
}

a {
     font-size:16px;
     line-height:1.6;
     color: #606060;
}

.small,.small a {
    font-size:15px;
    line-height: 1.5; 
}

.display-font-150 {
    line-height: 0.9;
    font-size:120px;
}

.grid-row-4{
    grid-row: span 4/span 4;
}

.grid-row-start-4 {
  grid-row-start: 4;
 }
    
.grid-row-start-3 {
  grid-row-start: 3;
 }
 
 .grid-row-start-1 {
  grid-row-start: 1;
 }
 
.mx-auto {
    margin:auto;
}
.row {
    display: flex;
    flex-wrap: wrap;
}
.flex-direction-column {
  flex-direction: column;
}
.max-content {
    width:max-content;
}
.video-16-9 {aspect-ratio: 16/ 9;height: 100%;width: 100%;object-fit: cover;}
.row > * {
    flex-shrink: 0;
    width: 100%;
    max-width: 100%;
}
.mw-1140 {
    max-width:1140px;
}
@media only screen and (max-width: 600px) {

h1 {
  font-size:38px;
   line-height: 1.1;
}

h2 {
  font-size:36px;
   line-height: 1.2;
}

h3 {
  font-size:32px;
   line-height: 1.3;
}

h4 {
  font-size: 28px;
   line-height: 1.4;
}

h5 {
  font-size: 24px;
   line-height: 1.5;
}

h6 {
  font-size: 18px;
  line-height: 1.5;
}

p {
    font-size:14px;
     word-spacing: 1px;
    text-align: left;
    letter-spacing: 1.3px;
    line-height: 1.96;
}

.small,.small a {
    font-size:13px;
    line-height: 1.5; 
}
.display-font-150 {
    line-height: 0.9;
    font-size:60px;
}



}

CSS;

echo $css;


  $color = array('primary' => '#3DBDB5', 'white' => 'white', 'black' => '#606060');
        
        foreach ($color as $colorName => $colorCode) {
            echo <<<CSS
            .bg-{$colorName} { background-color: {$colorCode}; }
            .text-{$colorName} { color: {$colorCode}; }
            CSS;
        }
       
        
 $opacityValues = array(25, 50, 75, 100);

        foreach ($opacityValues as $value) {
            $opacityValue = $value / 100; // Convert the value to the range 0 to 1 for CSS opacity property
            
            echo ".opacity-{$value} { opacity: {$opacityValue}; }\n";
        }
       
 
 

        
$overflowValues = array(
            'hidden',
            'scroll',
            'auto',
            'visible'
        );

        
        
        foreach ($overflowValues as  $value) {
            echo <<<CSS
            .overflow-{$value} { overflow: {$value}; }
            .overflow-x-{$value} { overflow-x: {$value}; }
            .overflow-y-{$value} { overflow-y: {$value}; }
            CSS;
        }
       
        
        $background_repeat = array(
            'repeat',
            'repeat-x',
            'repeat-y',
            'no-repeat'
        );

        
        
        foreach ($background_repeat as  $value) {
            echo <<<CSS
            .background-repeat-{$value} { background-repeat: {$value}; }
            
            CSS;
        }

        $background_size = array(
            'auto',
            'cover',
            'contain',
            '100vw'
        );

        
        
        foreach ($background_size as  $value) {
            echo <<<CSS
            .background-size-{$value} { background-size: {$value}; }
            
            CSS;
        }

        $background_attachment = array(
            'scroll',
            'fixed',
            'local'
        );

        
        
        foreach ($background_attachment as  $value) {
            echo <<<CSS
            .background-attachment-{$value} { background-attachment: {$value}; }
            
            CSS;
        }

        $clear = array(
            'none',
            'left',
            'right',
            'both'
        );

        
        
        foreach ($clear as  $value) {
            echo <<<CSS
            .clear-{$value} { clear: {$value}; }
            .float-{$value} { float: {$value}; }
            CSS;
        }

       
        $z_index = range(1, 12, 1);

        foreach ($z_index as  $value) {
            echo <<<CSS
            .z-{$value} { z-index: {$value}; }
            CSS;
        }


         $maxWidths = range(0, 1140);
         $paddingValues = range(0,100);
         $order = range(1, 12, 1);

foreach ($screenSizes as $i => $screenSize) {
    
    
      
        
        
        
        
        
    echo <<<CSS

@media only screen and (min-width: {$screenSize}px) {
    html {
        font-size: {$html[$i]}px;
    }
    
CSS;

 foreach ($maxWidths as  $value) {
            echo <<<CSS
            .mw-{$screen[$i]}{$value} { max-width: {$value}px; }
          CSS;
        }
        
 foreach ($paddingValues as  $value) {
          echo <<<CSS
            .p-{$screen[$i]}{$value} { padding: {$value}px; }
            .pt-{$screen[$i]}{$value} {padding-top: {$value}px !important; }
            .pr-{$screen[$i]}{$value} {padding-right: {$value}px !important; }
            .pb-{$screen[$i]}{$value} {padding-bottom: {$value}px !important; }
            .pl-{$screen[$i]}{$value} {padding-left: {$value}px !important; }
            .px-{$screen[$i]}{$value} {padding-right: {$value}px;padding-left: {$value}px; }
            .py-{$screen[$i]}{$value} {padding-top: {$value}px;padding-bottom: {$value}px; }
            .m-{$screen[$i]}{$value} { margin: {$value}px; }
            .mt-{$screen[$i]}{$value} {margin-top: {$value}px; }
            .mr-{$screen[$i]}{$value} {margin-right: {$value}px; }
            .mb-{$screen[$i]}{$value} {margin-bottom: {$value}px; }
            .ml-{$screen[$i]}{$value} {margin-left: {$value}px; }
            .mx-{$screen[$i]}{$value} {margin-right: {$value}px;margin-left: {$value}px; }
            .my-{$screen[$i]}{$value} {margin-top: {$value}px;margin-bottom: {$value}px; }
            .gap-{$screen[$i]}{$value} { gap: {$value}px; }
            .bt-{$screen[$i]}{$value} { border-top: {$value}px solid;}
            .bb-{$screen[$i]}{$value} { border-bottom: {$value}px solid;}
      CSS;
      
        }
        
        foreach ($order as  $value) {
            echo <<<CSS
            .order-{$screen[$i]}{$value} { order: {$value}; }
          CSS;
        }


        foreach ($font_size as  $size) {
            echo <<<CSS
        .fs-{$screen[$i]}{$size} {
            font-size: {$size}px;
        }
    CSS;
        }    

        
        foreach ($line_height as  $values   => $height) {
            echo <<<CSS
        .lh-{$screen[$i]}{$height} {
            line-height: {$values};
        }
    CSS;
        }
        
        
        
    foreach ($text_align as  $alignment) {
        echo <<<CSS
    .text-{$screen[$i]}{$alignment} {
        text-align: {$alignment};
    }
CSS;
    }

    foreach ($align_items as  $alignItem) {
        echo <<<CSS
    .align-items-{$screen[$i]}{$alignItem} {
        align-items: {$alignItem};
    }
CSS;
    }

    foreach ($align_content as  $alignContent) {
        echo <<<CSS
    .align-content-{$screen[$i]}{$alignContent} {
        align-content: {$alignContent};
    }
CSS;
    }

    foreach ($justify_items as  $justifyItem) {
        echo <<<CSS
    .justify-items-{$screen[$i]}{$justifyItem} {
        justify-items: {$justifyItem};
    }
CSS;
    }

    foreach ($justify_content as  $justifyContent) {
         echo <<<CSS
    .justify-content-{$screen[$i]}{$justifyContent} {
        justify-content: {$justifyContent};
    }
CSS;

    }



    foreach ($position as  $Position) {
        echo <<<CSS
    .position-{$screen[$i]}{$Position} {
        position: {$Position};
    }
CSS;

    }
    
  foreach ($display as  $displayValue) {
        echo <<<CSS
    .d-{$screen[$i]}{$displayValue} {
        display: {$displayValue};
    }
CSS;
    }
    foreach ($flex_wrap as  $flex_wrapValue) {
        echo <<<CSS
    .flex-wrap-{$screen[$i]}{$flex_wrapValue} {
        flex-wrap: {$flex_wrapValue};
    }
CSS;
    }
    
        foreach ($flex_direction as  $flex_directionValue) {
        echo <<<CSS
    .flex-direction-{$screen[$i]}{$flex_directionValue} {
        flex-direction: {$flex_directionValue};
    }
CSS;
    }
    
    
foreach ($float as  $floatValue) {
        echo <<<CSS
    .float-{$screen[$i]}{$floatValue} {
        float: {$floatValue};
    }
CSS;
    }
    
    for ($row = 1; $row <= 12; $row++) {
    $rowHeight = $row * 8.33333333333; // Calculate row height
    echo ".row-{$screen[$i]}{$row} > * {
    flex: 0 0 auto;
    width: {$rowHeight}%;
}\n";
}
    
  for ($col = 1; $col <= 12; $col++) {
    $colWidth = $col * 8.33333333333;
    echo <<<CSS
.col-{$screen[$i]}{$col} {
    flex: 0 0 auto;
    width: {$colWidth}%;
}
CSS;
}


        foreach ($cssProperties as  $property => $values) {

        foreach ($range as $rangeValue) {
            $cleanedrangeValue = str_replace('%', '', $rangeValue);
            echo <<<CSS
    .{$values}-{$screen[$i]}{$cleanedrangeValue} {
        {$property}: {$rangeValue};
    }
CSS;
      
    }
}
    


    
    echo <<<CSS
}

CSS;
}


?>

<?php ob_end_flush(); ?>