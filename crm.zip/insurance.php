<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 $date=$_GET['date'];
 
 
$table='insurance';

$customHeadings = [
    "id" => 'textContent',
    "name" => 'textContent', 
    "state" =>$state,
    "dob" =>  'date',
    "address" => 'textContent',
    "nominee_name" => 'textContent',
    "nominee_age" => 'textContent',
    "relationship_with_nominee" => 'textContent',
    "driving_licence_no" =>'textContent',
    "aadhar_card_number" => 'textContent',
   "contact_number" => 'textContent',
    "email_id" => 'textContent',
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>


</head>

<body>

<section>
    

<div class='sidebar'>
     <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
         
  <div class="position-sticky l-0 z-4 bg-white">
      
<h6 class="card-title m-0">Engineer Insurance</h6>
<?php
$list = ['state'=>$state]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
 

</div>
    <?php
if($state!=""){    
?>
       
       <div id="clipboard">
      <input type="text" id="table-search" placeholder="Search..." >
   <table id="editable-table">
 <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM insurance WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class="position-sticky l-0 z-4 bg-white" contenteditable><?php echo $row["name"]; ?></td> 

<td contenteditable><?php echo $row["state"]; ?></td> 

<td>   
 <input type="date" value="<?php echo $row["dob"]; ?>">
</td>

<td contenteditable><?php echo $row["address"]; ?></td> 
<td contenteditable><?php echo $row["nominee_name"]; ?></td> 
<td contenteditable><?php echo $row["nominee_age"]; ?></td> 
<td contenteditable><?php echo $row["relationship_with_nominee"]; ?></td> 
<td contenteditable><?php echo $row["driving_licence_no"]; ?></td> 
<td contenteditable><?php echo $row["aadhar_card_number"]; ?></td> 
<td contenteditable><?php echo $row["contact_number"]; ?></td> 
<td contenteditable class="email">  <?php echo $row["email_id"]; ?></td> 


        </tr>
        
        <?php
    }
}
?>

</tbody>
    </table>

</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
 <button id="captureButton">Copy to Clipboard</button>

</div>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
<td class='d-none'></td>

<td class="position-sticky l-0 z-4 bg-white" contenteditable></td> 

<td contenteditable></td> 

<td>   
 <input type="date" value="">
</td>

<td contenteditable></td> 

<td contenteditable></td> 

<td contenteditable></td> 

<td contenteditable></td> 

<td contenteditable></td>

<td contenteditable></td> 
<td contenteditable></td> 
<td contenteditable></td> 

<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




<?php
}
?>

<script>document.getElementById('captureButton').addEventListener('click', function() {html2canvas(document.getElementById('clipboard')).then(function(canvas) {canvas.toBlob(function(blob) {var item = new ClipboardItem({ "image/png": blob });navigator.clipboard.write([item]);});});});</script>



<?php

   $customHeadings["month"] = $month;
   $customHeadings["year"] = $year;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>




                 </div>
                 
          
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>
</body>

</html>




