
<?php
$download='h';
clearstatcache();
  extract($_GET);
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename="'.$download.'.csv"');

 $date1='01'.date("/m/Y");
 $date2='31'.date("/m/Y");

   include("api/db.php");

   
      
      
function view($con,$sql)
{

 $result=mysqli_query($con,$sql);
while($row = $result->fetch_assoc()){
 $data[]=$row;
 $datas=json_encode($data);
 
 
}
 return json_decode($datas);
 
}
$sql="SELECT * FROM tsm_work_book";


$activity = view($con,$sql);

 $contents=',tsm_work_book'."\n";



 $contents.='tsm_name,rm_name,jm_name,state,engineer_name,report_time,no_of_call_placed_by_wbi,no_of_call_complete,status'."\n";
 
 foreach($activity as $mydata)
{
$contents.=str_replace(',', '',$mydata->tsm_name)." ,"; 
$contents.=str_replace(',', '',$mydata->rm_name)." ,"; 
$contents.=str_replace(',', '',$mydata->jm_name)." ,"; 
$contents.=str_replace(',', '',$mydata->state)." ,"; 
$contents.=str_replace(',', '',$mydata->engineer_name)." ,"; 
$contents.=str_replace(',', '',$mydata->report_time)." ,"; 
$contents.=str_replace(',', '',$mydata->no_of_call_placed_by_wbi)." ,"; 
$contents.=str_replace(',', '',$mydata->no_of_call_complete)." ,"; 
$contents.=str_replace(',', '',$mydata->status)." \n";
}




$contents = strip_tags($contents);

print $contents;	
?>
