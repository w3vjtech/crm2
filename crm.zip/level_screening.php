<?php
$table='level_screening';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  <link rel="stylesheet" href="../assets/cssbundle/dataTables.min.css">
  <!-- project css file  -->
  <link rel="stylesheet" href="../assets/css/luno-style.css">
  <!-- Jquery Core Js -->
  <script src="../assets/js/plugins.js"></script>
</head>

<body class="layout-1" data-luno="theme-black">

 <?php
  include'sidebar.php';
  ?>
  <div class="wrapper">
<?php
include'header.php';
?>


     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0"> frist level screening</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
            

    <!-- Display the add/edit screening form -->
      <form method="POST" action="" class="card-body">
        
        <input oninput="OnInput(event)" type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
    <div class="row g-3">    
    

         <div class="col-md-6">
              <label class="form-label">CANDIDATE NAME:</label>
        <input oninput="OnInput(event)" type="text" name="candidate_name" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['candidate_name'] : ''; ?>" class="form-control form-control-lg" placeholder="Candidate Name" required>
       </div>


         <div class="col-md-6">
              <label class="form-label">LOCATION:</label>
        <input type="text" name="location" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['location'] : ''; ?>" class="form-control form-control-lg" placeholder="Location" required>
       </div>

  <div class="col-md-6">
              <label class="form-label">STATE NAME:</label>
      <select name="state" class="form-control form-control-lg">
    <option value="<?php echo isset($_GET['edit']) ? $pageresults[0]['state'] : ''; ?>"> <?php echo isset($_GET['edit']) ? $pageresults[0]['state'] : 'Select'; ?></option>
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        echo '<option value="' . $name . '">' . $name . '</option>';
    }
} 
?>
</select>

       </div>

<div class="col-md-4">
              <label class="form-label">intrested in field work:</label>
             
              <div class='selectmenu'>
              
              <input type="radio" name="intrested_in_field_work" value="YES"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['intrested_in_field_work'] === 'YES' ? 'checked' : ''; } ?>>

<label>YES</label>
<input type="radio"  name="intrested_in_field_work" value="NO"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['intrested_in_field_work'] === 'NO' ? 'checked' : ''; } ?>>

<label>no</label>
</div>
</div>


<div  class="col-md-4">
              <label class="form-label">bike & labtop availability:</label>
             
              <div class='selectmenu'>
              
              <input type="radio"  name="bike_labtop_availability" value="yes"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['bike_labtop_availability'] === 'yes' ? 'checked' : ''; } ?>>

<label>YES</label>
<input type="radio"  name="bike_labtop_availability" value="no"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['bike_labtop_availability'] === 'no' ? 'checked' : ''; } ?>>

<label>NO</label>
</div>
</div>


<div  class="col-md-4 item-details">
              <label class="form-label">self introduction:</label>
              <div class='selectmenu'>
              
              <input type="radio" name="self_introduction" value="DONE"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['self_introduction'] === 'DONE' ? 'checked' : ''; } ?>>

<label>Done</label>
</div>
</div>

<div  class="col-md-4 item-details">
              <label class="form-label">experienced / fresher:</label>
             
              <div class='selectmenu'>
              
              <input type="radio" name="experienced_fresher" value="EXPERIENCED"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['experienced_fresher'] === 'EXPERIENCED' ? 'checked' : ''; } ?>>

<label>EXPERIENCED</label>
<input type="radio" name="experienced_fresher" value="FRESHER"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['experienced_fresher'] === 'FRESHER' ? 'checked' : ''; } ?>>

<label>FRESHER</label>
</div>
</div>


<div  class="col-md-4 item-details">
              <label class="form-label">company details:</label>
              <div class='selectmenu'>
              
              <input type="radio" name="company_details" value="DONE"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['company_details'] === 'DONE' ? 'checked' : ''; } ?>>

<label>Done</label>
</div>
</div>

<div  class="col-md-4 item-details">
              <label class="form-label">explained work details:</label>
              <div class='selectmenu'>
              
              <input type="radio" name="explained_work_details" value="DONE"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['explained_work_details'] === 'DONE' ? 'checked' : ''; } ?>>

<label>Done</label>
</div>
</div>

<div  class="col-md-4 item-details">
              <label class="form-label">salary:</label>
             
              <div class='selectmenu'>
              
              <input type="radio" name="salary" value="FIXED"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['salary'] === 'FIXED' ? 'checked' : ''; } ?>>

<label>fixed</label>
<input type="radio" name="salary" value="PER CALL BASICS"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['salary'] === 'PER CALL BASICS' ? 'checked' : ''; } ?>>

<label>Per Call Basics</label>
</div>
</div>


<div  class="col-md-6 item-details">
              <label class="form-label">joining date:</label>
        <input type="date" name="joining_date" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['joining_date'] : ''; ?>" class="form-control form-control-lg" placeholder="Joining Date" required>
       </div>
       
       
<div  class="col-md-4 item-details">
              <label class="form-label">forwarded to rm:</label>
             
              <div class='selectmenu'>
              
              <input type="radio" name="forwarded_to_rm" value="YES"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['forwarded_to_rm'] === 'YES' ? 'checked' : ''; } ?>>

<label>YES</label>
<input type="radio" name="forwarded_to_rm" value="NO"<?php if (isset($_GET['edit'])) { echo $pageresults[0]['forwarded_to_rm'] === 'NO' ? 'checked' : ''; } ?>>

<label>no</label>
</div>
</div>    
       




         <div class="card-footer">
                <button type="submit" name="submit" class="btn btn-primary"><?php echo isset($_GET['edit']) ? 'Update' : 'Add'; ?> screening</button>
              </div>
    </form>


   <style>
 .item-details {
      display: none;
    }
</style>

<script>
  // Get references to the radio buttons and item details elements
  const radioButtons = document.querySelectorAll('input[type="radio"][name="bike_labtop_availability"]');
  const itemDetails = document.querySelectorAll('.item-details');

  // Add event listener to the radio buttons
  radioButtons.forEach(radioButton => {
    radioButton.addEventListener('change', function() {
      // Check if the "yes" radio button is selected
      if (radioButton.value === 'yes' && radioButton.checked) {
        itemDetails.forEach(detail => {
          detail.style.display = 'block';
        });
      } else if (radioButton.value === 'no' && radioButton.checked) {
        itemDetails.forEach(detail => {
          detail.style.display = 'none';
        });
      }
    });
  });
</script>

             
                <table class="table myDataTable table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </th>
                      
<th> candidate_name </th>
<th> location </th>
<th> state </th>
<th> intrested_in_field_work </th>
<th> bike_labtop_availability </th>
<th> self_introduction </th>
<th> experienced_fresher </th>
<th> company_details </th>
<th> explained_work_details </th>
<th> salary </th>
<th> joining_date </th>
<th> forwarded_to_rm </th>

            <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                      
                           <?php foreach ($pageresults as $pageresult) : ?>
        <tr>
             <td>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </td>
                      


<td><?php echo $pageresult['candidate_name']; ?></td>
<td><?php echo $pageresult['location']; ?></td>
<td><?php echo $pageresult['state']; ?></td>
<td><?php echo $pageresult['intrested_in_field_work']; ?></td>
<td><?php echo $pageresult['bike_labtop_availability']; ?></td>
<td><?php echo $pageresult['self_introduction']; ?></td>
<td><?php echo $pageresult['experienced_fresher']; ?></td>
<td><?php echo $pageresult['company_details']; ?></td>
<td><?php echo $pageresult['explained_work_details']; ?></td>
<td><?php echo $pageresult['salary']; ?></td>
<td><?php echo $pageresult['joining_date']; ?></td>
<td><?php echo $pageresult['forwarded_to_rm']; ?></td>
           
              <td>
                          <a href="?edit=<?php echo $pageresult['id']; ?>" > <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-edit"></i></button></a>
                        <a href="?delete=<?php echo $pageresult['id']; ?>" onclick="return confirm('Are you sure you want to delete this screening?')"> <button type="button" class="btn btn-sm btn-outline-danger"><i class="fa fa-trash-o"></i></button></a>
                      </td>
                      
        </tr>
        <?php endforeach; 
              ?>
                    
  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    
    
    
    
       
 <?php
include'footer.php';
?>  </div>

  <script src="../assets/js/theme.js"></script>
  <script src="../assets/js/bundle/dataTables.bundle.js"></script>
  <script>
    $('.myDataTable').addClass('nowrap').dataTable({
      responsive: true,
    });
  </script>
</body>

</html>