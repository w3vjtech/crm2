<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='customer_escalation_matrix';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 $client_name=$_GET['client_name'];
 $state=$_GET['state'];
 ?>

</head>

<body class="layout-1" data-luno="theme-black">

<div class='d-flex'>
<?php
include'header.php';
?>
  <div class="wrapper p-10">


<?php include'top-bar.php'; ?>


     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">Customer Escalation Matrix</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
                  
                  
                    
             <form action="" method="get" class='searc-form'>
      <div class='d-flex gap-30'>


<div>
    <label class="form-label">Client Name:</label>
 <select name='client_name'>
 <option value="<?php echo isset($client_name) ? $client_name : ''; ?>"> <?php echo isset($client_name) ? $client_name : 'Select'; ?></option>
     
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'customer_name'); ?>
  </select> 
</div>

      <div>
  <label class="form-label">State:</label>
  <select name='state'>
 <option value="<?php echo isset($state) ? $state : ''; ?>"> <?php echo isset($state) ? $state : 'Select'; ?></option>
     
<?php  echo $selectDropdown = generateSelectDropdown($con, 'customer_escalation_matrix', 'state'); ?>
  </select> 
</div>

<div>
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
             
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}


    </style>
                  
           

<div class='d-flex gap-3'>
    
   <?php

$sql = "SELECT * FROM customer_escalation_matrix WHERE customer_name ='$client_name' AND state='$state'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        
        ?>
         <div>
        <h3 class='text-center'><?php echo $row["designation"]; ?></h3>
     <ul>
         <li><?php echo $row["name"]; ?></li>
         <li><?php echo $row["mobile"]; ?></li>
         <li><?php echo $row["email"]; ?></li>
     </ul>
    </div>
    <?php
  }
} 
?>

</div>


              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    
    
    
    <style>
      .card  ul {
    list-style: none;
    padding: 10px;
}

.card ul li {
    padding: 10px;
}
  </style>
       
 <?php
include'footer.php';
?>  </div>
</div>
</body>

</html>