<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();

function extractDayFromDate($dateString, $inputFormat = 'd-m-Y') {
    $dateTime = DateTime::createFromFormat($inputFormat, $dateString);
    return $dateTime ? $dateTime->format('d') : 'Invalid date format';
}


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $month=$_GET['month'];
    $year=$_GET['year'];
    
 $report_time=$_GET['report_time'];

$start_date=$year.'-'.$month.'-01';
$end_date=$year.'-'.$month.'-31';

 $edit=$_GET['edit'];
 

    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body>

<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
<div class="position-sticky l-0 z-4 bg-white"> 
<h6 class="card-title m-0">ZM MONTHLY REPORT</h6>

 <form action="" method="get" class='searc-form'>
      <div class='d-flex gap-30'>

<select name='month'>
    <?php
    $months = [
        '01' => "January",
        '02' => "February",
        '03' => "March",
        '04' => "April",
        '05' => "May",
        '06' => "June",
        '07' => "July",
        '08' => "August",
        '09' => "September",
        '10' => "October",
        '11' => "November",
        '12' => "December"
    ];

    foreach ($months as $number => $name) {
        echo "<option value=\"$number\">$name</option>";
    }
    ?>
</select>

<select name='year'>
    <?php
    $currentYear = date("Y");
    $startYear = 2022;
     echo "<option value=\"$year\">$year</option>";
    for ($syear = $currentYear; $syear >= $startYear; $syear--) {
        echo "<option value=\"$syear\">$syear</option>";
    }
    ?>
</select>


<div>
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    
</div>
 
 <div id="clipboard">

  
  


    
    
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}

tbody, td, tfoot, th, thead, tr {
    padding: 10px;
    width: max-content;
    text-wrap: nowrap;
    border: 1px solid #606060;
}
    </style>
    <?php
//if($state!="" AND $start_date!="" AND $end_date!=""){    
?>       

<?php
 $states = explode(",", $state_access);
$stateList = "'" . implode("','", $states) . "'";


function fetchData($state) {
    global $con; // Assuming $con is your database connection

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT code FROM state WHERE name = '$state'";
    $result = mysqli_query($con, $sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["code"];
    } else {
        return null; // Return null if no data found for the state
    }
}
?>






<?php
$sql = "SELECT date,state,no_of_call_attended  FROM tsm_work_book WHERE state IN ($stateList) AND STR_TO_DATE(date, '%d-%m-%Y') BETWEEN '$start_date' AND '$end_date'";

$result = mysqli_query($con, $sql);

?>





<?php
if ($result) {
    
    $dates = [];
   
    $states = [];
   
    $calls = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $date = $row['date'];
         $state = trim($row['state']); // Trim whitespace from the engineer name

          $dates[] = $date;

          $states[] = $state;

    if ($row['no_of_call_attended'] !== 'LEAVE' && $row['no_of_call_attended'] !== '0'  && $row['no_of_call_attended'] !== 'NO CALL' && $row['no_of_call_attended'] !== 'OTHERS') {
        
       $calls[$state][$date]  += $row['no_of_call_attended'];
       
        $state_calls[$state]  += $row['no_of_call_attended'];
       
        $date_calls[$date]  += $row['no_of_call_attended'];
       
       $tsm_grand_total  += $row['no_of_call_attended'];
       
    }
    
    }
    
$dates = array_unique($dates);
$states = array_map('trim', array_unique($states)); // Trim each element in the array
    if (!empty($dates)) {
        
        echo '<table border="1">
            <tr>
                <th class="bg-primary  text-white fs-20" colspan="' . (count($dates) + 2) . '">Monthly Overall Productivity Report '.$months[$month].'-'.$year.' </th>
               
            </tr>
            <tr><td class="bg-primary  text-white fs-17" >State</td> <td class="bg-primary  text-white text-center fs-16" colspan="' . (count($dates)) . '">Date</td>  <td class="bg-primary  text-white fs-16">State-Wise Productivity</td><tr>
         
        ';

        // Print Engineer and Location headers
     echo '<tr><td></td>';
        foreach ($dates as $date) {
            echo '<td class="fs-16">'. extractDayFromDate($date) . '</td>';
        }
        echo '</tr>';

      
        echo '</tr>';

        // Print Date and Calls data
        foreach ($states as $state) {
            echo '<tr><td class="fs-16">' . fetchData($state). '</td>';
            foreach ($dates as $date) {
                echo '<td>' . $calls[$state][$date] . '</td>';
               
            }
             echo '<td class="fs-16">' . $state_calls[$state] . '</td>';
               
             
            echo '</tr>';
        }
        
         echo '<tr><td class="bg-primary  text-white fs-16">Date-Wise Productivity</td>';
      
        foreach ($dates as $date) {
            echo '<td class="bg-primary  text-white fs-16">' .  $date_calls[$date] . '</td>';
        }
      echo '<td class="Euclid-Circular-B-SemiBold bg-primary text-white fs-20"> Grand Total:'.$tsm_grand_total.'</td></tr>';
  
    echo '</table>';
    

        echo '</table>';
    } else {
        echo 'No data found';
    }
} else {
    echo 'Error in query execution: ' . $conn->error;
}
?>




<?php
//}
?>

<?php
// Initialize arrays
$client_dates = [];
$client_names = [];
$calls2 = [];

$sql3 = "SELECT date, client_name, no_of_calls_completed FROM tsm_client_call_data WHERE state IN ($stateList) AND STR_TO_DATE(date, '%d-%m-%Y') BETWEEN '$start_date' AND '$end_date'";

$result3 = mysqli_query($con, $sql3);

while ($row2 = mysqli_fetch_assoc($result3)) {
    $date = $row2['date'];
    $client_name = $row2['client_name'];
    $calls_completed = $row2['no_of_calls_completed'];

    // Populate arrays and count calls completed for each client on each date
    $client_dates[] = $date;
    $client_names[] = $client_name;

    $calls2[$client_name][$date] += $calls_completed;
    $client_name_calls2[$client_name] += $calls_completed;
    $date_calls2[$date] += $calls_completed;
    $grand_total += $calls_completed;
}


$client_dates = array_unique($client_dates);
$client_names = array_map('trim', array_unique($client_names)); // Trim each element in the array

if (!empty($client_dates)) {
    echo '<table border="1">
            <tr>
                <th class="bg-primary  text-white fs-20" colspan="' . (count($client_dates) + 2) . '"> Client-Wise Monthly Overall Productivity Report '.$months[$month].'-'.$year.'</th>
                
            </tr>
             <tr><td class="bg-primary  text-white fs-16">Clients</td> <td class="bg-primary  text-white text-center fs-16" colspan="' . (count($dates) - 5) . '">Date</td> <td class="bg-primary  text-white fs-16">Clients wise Total</td><tr>
         
            <tr>
                <td></td>';

    // Print date headers
    foreach ($client_dates as $date) {
        echo '<td>' . extractDayFromDate($date) . '</td>';
    }
    echo '</tr>';

    // Print client names and their respective calls completed on each date
    foreach ($client_names as $client_name) {
        echo '<tr><td class="fs-16">' . $client_name . '</td>';
        foreach ($client_dates as $date) {
            echo '<td>' .  $calls2[$client_name][$date] . '</td>';
        }
        echo '<td class="fs-16">' .$client_name_calls2[$client_name]. '</td>';
        echo '</tr>';
        
        
        
    }
    
      echo '<tr ><td class="bg-primary  text-white fs-16">Date wise Total</td>';
      
        foreach ($client_dates as $date) {
            echo '<td class="bg-primary  text-white fs-16">' .  $date_calls2[$date] . '</td>';
        }
      echo '<td class="Euclid-Circular-B-SemiBold  bg-primary  text-white fs-20">Grand Total:'.$grand_total.'</td></tr>';
  
    echo '</table>';
  
}
?>



              </div>
         <button id="captureButton">Copy to Clipboard</button>

   <?php
   $Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');
   ?>
</div>
</div>
<section>    
    
</body>

</html>