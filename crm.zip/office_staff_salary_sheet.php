<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();

$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $edit=$_GET['edit'];
 
 $date=$_GET['date'];
 
 
 $table='office_staff_salary';

$customHeadings = [
    "id" => 'textContent',
    "pymt_prod_type_code" => 'textContent', 
    "pymt_mode" => 'textContent',
    "debit_acc_no" => 'textContent',
    "bnf_name" => 'textContent',
    "bene_acc_no" => 'textContent',
    "bene_ifsc" => 'textContent',
    "amount" => 'textContent',
    "debit_narr" =>'textContent',
    "credit_narr" =>'textContent',
    "mobile_num" => 'textContent',
   "email_id" => 'textContent',
    "remark" => 'textContent',
    "pymt_date" => 'textContent',
    "ref_no" => 'textContent',
    "addl_info1" => 'textContent',
    "addl_info2" => 'textContent',
    "addl_info3" => 'textContent',
     "addl_info4" => 'textContent',
    "lei_number" => 'textContent',
    
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
</head>

<body>



<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
        <div class="position-sticky l-0 z-4 bg-white">
   <h6 class="card-title m-0">Office staff salary sheet</h6>
<?php
$list = ['date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
        
  

    <?php
    
  
if($date!=""){    
?>       

 <div id="clipboard">
       <input type="text" id="table-search" placeholder="Search..." >
   <table id="editable-table">
   <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>

<?php
$sql = "SELECT * FROM office_staff_salary WHERE date='$date'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td class="position-sticky l-0 z-5" contenteditable><?php echo $row["pymt_prod_type_code"]; ?></td>
<td contenteditable><?php echo $row["pymt_mode"]; ?></td>
<td contenteditable><?php echo $row["debit_acc_no"]; ?></td>
<td contenteditable><?php echo $row["bnf_name"]; ?></td>
<td contenteditable><?php echo $row["bene_acc_no"]; ?></td>
<td contenteditable><?php echo $row["bene_ifsc"]; ?></td>
<td contenteditable><?php echo $row["amount"]; ?></td>
<td contenteditable><?php echo $row["debit_narr"]; ?></td>
<td contenteditable><?php echo $row["credit_narr"]; ?></td>
<td contenteditable><?php echo $row["mobile_num"]; ?></td>
<td contenteditable class='email'>  <?php echo $row["email_id"]; ?></td>
<td contenteditable><?php echo $row["remark"]; ?></td>
<td contenteditable><?php echo $row["pymt_date"]; ?></td>
<td contenteditable><?php echo $row["ref_no"]; ?></td>
<td contenteditable><?php echo $row["addl_info1"]; ?></td>
<td contenteditable><?php echo $row["addl_info2"]; ?></td>
<td contenteditable><?php echo $row["addl_info3"]; ?></td>
<td contenteditable><?php echo $row["addl_info4"]; ?></td>
<td contenteditable><?php echo $row["lei_number"]; ?></td>
        </tr>
        
        <?php
    }
}else{
     
$sql = "SELECT * FROM office_staff_salary_sheet WHERE 1";


$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    
        ?>
          <tr>

          
<td class='d-none'></td>

<td class="position-sticky l-0 z-5" contenteditable><?php echo $row["pymt_prod_type_code"]; ?></td>
<td contenteditable><?php echo $row["pymt_mode"]; ?></td>
<td contenteditable><?php echo $row["debit_acc_no"]; ?></td>
<td contenteditable><?php echo $row["bnf_name"]; ?></td>
<td contenteditable><?php echo $row["bene_acc_no"]; ?></td>
<td contenteditable><?php echo $row["bene_ifsc"]; ?></td>
<td contenteditable><?php echo $row["amount"]; ?></td>
<td contenteditable><?php echo $row["debit_narr"]; ?></td>
<td contenteditable><?php echo $row["credit_narr"]; ?></td>
<td contenteditable><?php echo $row["mobile_num"]; ?></td>
<td contenteditable class='email'>  <?php echo $row["email_id"]; ?></td>
<td contenteditable><?php echo $row["remark"]; ?></td>
<td contenteditable><?php echo $row["pymt_date"]; ?></td>
<td contenteditable><?php echo $row["ref_no"]; ?></td>
<td contenteditable><?php echo $row["addl_info1"]; ?></td>
<td contenteditable><?php echo $row["addl_info2"]; ?></td>
<td contenteditable><?php echo $row["addl_info3"]; ?></td>
<td contenteditable><?php echo $row["addl_info4"]; ?></td>
<td contenteditable><?php echo $row["lei_number"]; ?></td>

      </tr>

        <?php
    }
} 
    
}
?>

</tbody>
    </table>

</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "FM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()">Add Row</button>
 <button id="captureButton">Copy to Clipboard</button>
</div>


<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           <td class='d-none'></td>

<td class="position-sticky l-0 z-5" contenteditable>   </td>
<td contenteditable>  </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>  </td>
<td contenteditable class='email'> </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>
<td contenteditable>   </td>



      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>



           

<?php

 $customHeadings["date"] = $date;
        
        

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>

        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?> 
    </div>
    
</div>
</section>


</body>

</html>