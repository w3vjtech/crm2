<?php
date_default_timezone_set('Asia/Kolkata');
include'api/db.php';
    
$data = json_decode(file_get_contents('php://input'), true);

print_r($data);

$date = date("Y-m-d H:i:s");  

extract($data);

$sql = "INSERT INTO invoice_wbi_tsm_remarks (invoice_no,date,wbi_tsm_remarks) VALUES ('$invoice_no','$date','$wbi_tsm_remarks')";

if(mysqli_query($con,$sql)){
     $response = ['status' => 'success', 'message' => 'wbi_tsm_remarks submitted'];
   echo json_encode($response);
}

?>


