
<?php
clearstatcache();
ob_start();
session_start();
$email=$_SESSION["email"];
include'db.php';


define('BASE_URL', 'https://'. $_SERVER['HTTP_HOST'].'/');
error_reporting(0);

ob_start("minifier");

function minifier($code){$search=array('/ {2,}/','/<!--.*?-->|\t|(?:\r?\n[ \t]*)+/s');$replace=array(' ','');$code=preg_replace($search,$replace,$code);

$resize=BASE_URL.'resize?resize=';
$newSrc = '"loading="lazy';
$code = preg_replace('/(<img[^>]+src=")([^"]+)(")/i', '${1}'.$resize.'${2}'.$newSrc.'${3}', $code);

$newSrc = '" autoplay muted loop playsinline poster="one-does-not-simply.jpg" loading="lazy';
$code = preg_replace('/(<video[^>]+src=")([^"]+)(")/i', '${1}${2}'.$newSrc.'${3}', $code);
return $code;
    
    
}
header("Content-Type: text/html; charset=utf-8");

date_default_timezone_set("Asia/Calcutta");



function state()
{
    global $con;
    $sql = "SELECT * FROM state";
    $result = mysqli_query($con, $sql);
    $options = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $select = '<select name="state" class="form-control form-control-lg" >';
    foreach ($options as $option) {
        $select .= '<option value="' . $option['name'] . '">' . $option['name'] . '</option>';
    }
    $select .= '</select>';

    return $select;
}


?>




 <?php
// Function to generate a select dropdown based on data from a database table column
function generateSelectDropdown($con, $tableName, $columnName) {
    $options = '';

    $sql = "SELECT DISTINCT $columnName FROM $tableName"; // Modify query as needed
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $optionValue = $row[$columnName];
            $options .= "<option value='$optionValue'>$optionValue</option>";
        }
    }

    return $options;
}

?>

 <?php
// Function to generate a select dropdown with distinct values from the 'customer_name' column
function generateCustomerNameDropdown($con, $tableName, $columnName) {
    $options = '';

    $sql = "SELECT DISTINCT '.$tableName.' FROM '.$columnName";
    $result = $con->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $customerName = $row['customer_name'];
            $options .= "<option value='$customerName'>$customerName</option>";
        }
    }

    return $options;
}
?>