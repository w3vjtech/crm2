<?php
 if(!empty($_SERVER['REQUEST_URI'])){
 $url=explode("/css/",$_SERVER['REQUEST_URI']);

$page=$url[1];
$page = empty($page) ? 'index.php' : $page;
}
?>
<head>
  <link rel="stylesheet" href="style.php?code=css/<?php echo $page; ?> ">
</head>