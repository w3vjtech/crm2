<?php
clearstatcache();

$domainName = 'https://'.$_SERVER['HTTP_HOST'].'/';

header("Content-type: text/css");
echo '@charset "UTF-8"';
$fontDirectory = 'fonts';
$fontFiles = glob($fontDirectory . '/*.ttf');

foreach ($fontFiles as $fontFile) {
    $fontName = basename($fontFile, '.ttf');
    $font_class= str_replace(' ', '-', $fontName);
$font_classs[]=$font_class;
    $fonts .= "@font-face {font-family: '$fontName';src: url('$fontFile') format('truetype');}.$font_class {font-family: '$fontName', sans-serif;font-weight: normal;}";
}



$code_url = $domainName.$_GET['code'] ?? '';

$filejson = $domainName .'css/file.json';

$jsonString = file_get_contents($filejson);
$decodedData = json_decode($jsonString, true);

// Check if URL is provided and accessible
if (!empty($code_url) && filter_var($code_url, FILTER_VALIDATE_URL)) {
    $code_url = file_get_contents($code_url);
    

function generateDynamicCSSClass($class, $screen) {
    global $decodedData;
    $separatedStrings = explode($screen, $class);
    $propertyAbbreviation = $separatedStrings[0];
    $value = $separatedStrings[1];
if (is_numeric($value) AND $propertyAbbreviation != "z") {
    $value = $value . '%';
}
if ($propertyAbbreviation == "bg" OR $propertyAbbreviation == "c" ) {
    if (preg_match('/[a-zA-Z]/', $value) && preg_match('/[0-9]/', $value)) {
        $value = "#" . $value;
    }
}


  
    $property = $decodedData[$propertyAbbreviation] ?? $propertyAbbreviation;
  
    return ".$class { $property: $value; }";
}

function htmlcss($code_url){
global $font_classs;

$pattern = '/class="([^"]+)"/';

preg_match_all($pattern, $code_url, $matches);

if (isset($matches[1])) {
    $allClasses = array_unique($matches[1]);
    
    $screens = ['-xs-', '-sm-', '-md-', '-lg-', '-xl-', '-sl-', '-ml-', '-']; // Different screen sizes and default

    $classStyles = []; // Array to hold generated CSS for each screen size
    
    foreach ($allClasses as $classes) {
        $classArray = explode(' ', $classes); // Split classes into an array
        
        
        $classArray = array_diff($classArray, $font_classs);
        
        
        foreach ($classArray as $class) {
            $matched = false;
            
            foreach ($screens as $screen) {
                if (strpos($class, $screen) !== false) {
                    $css = generateDynamicCSSClass($class, $screen);
                    $classStyles[$screen][] = $css;
                    $matched = true;
                    break;
                }
            }
            
            if (!$matched) {
                // Handle classes without screen size prefixes
                $css = generateDynamicCSSClass($class, '-');
                $classStyles['-'][] = $css;
            }
        }
    }

    $minWidths = [
        '' => '0px',
        'xs' => '320px',
        'sm' => '576px',
        'md' => '768px',
        'lg' => '992px',
        'xl' => '1200px'
    ];

foreach ($classStyles as $screen => $styles) {
    $classStyles[$screen] = array_unique($styles);
}

    foreach ($classStyles as $screen => $styles) {
        $screenKey = str_replace('-', '', $screen);
        $screenMapping = $minWidths[$screenKey];

        $mediaQuery = "@media screen and (min-width: {$screenMapping}) {";

        foreach ($styles as $style) {
            $mediaQuery .= $style;
        }

        $mediaQuery .= '}';
        
        $code.= $mediaQuery;
    }
    
    
    
}

global $fonts;
$code = $fonts.$code;
return $code;
}
echo  htmlcss($code_url);
}


?>