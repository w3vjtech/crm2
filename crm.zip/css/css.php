<?php include'style.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CSS Property Search</title>
</head>
<body>
  <input type="text" id="searchInput" placeholder="Search CSS Properties...">
  <ul id="results"></ul>

  <script>
    const searchInput = document.getElementById('searchInput');
    const resultsList = document.getElementById('results');

    // Fetch JSON data
    fetch('https://hr.wbinfs.in/css/file.json')
      .then(response => response.json())
      .then(data => {
        // Function to filter and display results
        function displayFilteredResults(searchTerm) {
          searchTerm = searchTerm.toLowerCase();
          resultsList.innerHTML = '';

          for (const key in data) {
            if (data.hasOwnProperty(key) && key.toLowerCase().includes(searchTerm)) {
              const li = document.createElement('li');
              li.textContent = `${key}: ${data[key]}`;
              resultsList.appendChild(li);
            }
          }
        }

        // Event listener for search input
        searchInput.addEventListener('input', function() {
          const searchValue = this.value;
          displayFilteredResults(searchValue);
        });

        // Initially display all results
        displayFilteredResults('');
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        resultsList.innerHTML = 'Failed to fetch CSS properties.';
      });
  </script>
</body>
</html>
