<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$current_date = date("d-m-Y");
$table='invoice';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
  $currentDate = date("d-m-Y");


$table='invoice';

$customHeadings = [
    "id" => 'textContent',
    "invoice_no" => 'textContent', 
    "invoice_date" => 'date', 
    "vendor" => 'textContent', 
    "invoice_status" => 'selectValue', 
    "due_date" => 'date', 
    "tl_approval" => 'selectValue', 
    "tsm_approval" => 'selectValue', 
    "rm_approval" => 'selectValue', 
    "wbi_tsm_remarks" => 'textContent', 
];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>


<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

<div class="position-sticky l-0 z-4 bg-white">

     <h6  class="pt-5">invoice</h6>
   <?php
$list = ['state'=>$state,'vendor'=>$vendor, 'month'=>$month,'year'=>$year]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>

</div>

    <div id="clipboard">
    
    <?php
if($state!="" AND $vendor!="" AND $month!="" AND $year!=""){    
?>       
   <table id="editable-table">
       <input type="text" id="table-search" placeholder="Search..." >
   <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM invoice WHERE state='$state' AND month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
      
      
       $check_date=$row["create_date"];
      
        ?>
      <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>


<td  <?php if($type=="ZM" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>>  <?php echo $row["invoice_no"]; ?> </td>
 
<td>  
 <input type="date" name="invoice_date" value="<?php echo $row["invoice_date"]; ?>" <?php if($type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>
       
</td> 
<td <?php if($type=="ZM" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?>>  <?php  echo $row["vendor_state"]; ?> </td>
<td>
  <select onchange="updateBorderColor(this)" <?php if($type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>
    <option value="<?php echo $row["invoice_status"]; ?>"> <?php echo $row["invoice_status"]; ?></option>
<option value="select">select</option>
<option value="UNPAID">UNPAID</option>
<option value="PAID">PAID</option>
  </select>
</td>
<td>   
 <input type="date" name="due_date" value="<?php echo $row["due_date"]; ?>" <?php if($type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>
</td>

<td>
      <select onchange="updateBorderColor(this)">
          <option value="<?php echo $row["tl_approval"]; ?>"> <?php echo $row["tl_approval"]; ?></option>
 <?php if($type=="TL"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>

<td>
      <select onchange="updateBorderColor(this)">
        <option value="<?php echo $row["tsm_approval"]; ?>"> <?php echo $row["tsm_approval"]; ?></option>
 <?php if($type=="TSM"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>


<td>
      <select onchange="updateBorderColor(this)">
        <option value="<?php echo $row["rm_approval"]; ?>"> <?php echo $row["rm_approval"]; ?></option>
 <?php if($type=="RM"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>


<td <?php if (str_replace('-', '', $current_date) == str_replace('-', '', $check_date) AND $type=="TSM") {
   ?>contenteditable <?php } ?> >  </td>



        </tr>

        <?php
    }
}


?>

</tbody>
    </table>
</div>

<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button" <?php if($type != "TL" && $type != "TSM" && $type != "RM" && $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?>>Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()" style="<?php if($type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "display: none;"; ?>">Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>

 </div> 
 
<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
<td class='d-none'></td>


<td contenteditable> </td>
<td>   
 <input type="date" name="invoice_date" value="" class="form-control form-control-lg" placeholder="invoice_date">
</td>
<td contenteditable> </td>
<td>
  <select onchange="updateBorderColor(this)">
    
<option value="select">select</option>
<option value="UNPAID">UNPAID</option>
<option value="PAID">PAID</option>
  </select>
</td>
<td>   
 <input type="date" name="due_date" value="" class="form-control form-control-lg" placeholder="due_date">
</td>

<td>
      <select onchange="updateBorderColor(this)">
        
 <?php if($type=="TL"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>

<td>
      <select onchange="updateBorderColor(this)">
     
 <?php if($type=="TSM"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>


<td>
      <select onchange="updateBorderColor(this)">
      
 <?php if($type=="RM"){ ?>
<option value="">select</option>
<option value="APPROVED">APPROVED</option>
<option value="PENDING">PENDING</option>
<?php } ?>
  </select>
</td>


<td contenteditable >  </td>


      
<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




<?php
$customHeadings["month"] = $month;
$customHeadings["year"] = $year;
$customHeadings["vendor"] = $vendor;
$customHeadings["state"] = $state;


       
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');

$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



        
    </div>
    <div class='footer'>
        <?php
include'footer.php';
?>
    </div>
    
</div>
</section>


</body>

</html>