<?php
require('fpdf.php'); // Include the FPDF class
error_reporting(E_ALL);
ini_set('display_errors', 1);

class Invoice extends FPDF
{
    function Header()
    {
        $this->SetFont('Regular', '', 12);
        $this->Cell(190, 10, 'Invoice', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Regular', '', 8);
        $this->Cell(0, 10, 'Page '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }

    function generateInvoice($invoiceData)
    {
        // Invoice details
        $this->SetFont('Regular', '', 12);
        $this->Cell(130, 10, 'Description', 1, 0);
        $this->Cell(30, 10, 'Quantity', 1, 0, 'C');
        $this->Cell(30, 10, 'Price', 1, 1, 'C');

        $this->SetFont('Regular', '', 12);
        foreach ($invoiceData as $data) {
            $this->Cell(130, 10, $data['description'], 1, 0);
            $this->Cell(30, 10, $data['quantity'], 1, 0, 'C');
            $this->Cell(30, 10, $data['price'], 1, 1, 'C');
        }

        // Total
        $total = array_reduce($invoiceData, function ($carry, $item) {
            return $carry + ($item['quantity'] * $item['price']);
        }, 0);

        $this->Cell(130, 10, 'Total', 1, 0);
        $this->Cell(60, 10, '$'.$total, 1, 1, 'C');
    }
}

// Sample invoice data
$invoiceData = [
    ['description' => 'Item 1', 'quantity' => 2, 'price' => 10],
    ['description' => 'Item 2', 'quantity' => 1, 'price' => 20],
    ['description' => 'Item 3', 'quantity' => 3, 'price' => 15],
];

$fontDirectory='fonts/';
$pdf = new Invoice();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->AddFont('Regular','','Euclid Circular B Regular.php', $fontDirectory);

$pdf->generateInvoice($invoiceData);
$pdf->Output();
?>
