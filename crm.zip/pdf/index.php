<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$ce_name='VIJAYA KUMAR';
$state='TAMIL NADU';
$join_date="01-01-2023";

   
$fontDirectory='fonts/';
require('fpdf.php'); // Include or require the FPDF library

// Create a new PDF document
$pdf = new FPDF();
$pdf->AddFont('Light','','Euclid Circular B Light.php', $fontDirectory);
$pdf->AddFont('Regular','','Euclid Circular B Regular.php', $fontDirectory);
$pdf->AddFont('Medium','','Euclid Circular B Medium.php', $fontDirectory);
$pdf->AddFont('SemiBold','','Euclid Circular B SemiBold.php', $fontDirectory);
$pdf->AddFont('Bold','','Euclid Circular B Bold.php', $fontDirectory);


$pdf->AddPage('P', 'Letter');


$pdf->Image('bg.png', 0, 0, $pdf->GetPageWidth(), $pdf->GetPageHeight());

$pdf->Ln(50);


$pdf->SetFont('Bold', '', 16);
$pdf->MultiCell(0, 10, 'WETZEL BARRON INFOSYSTEM', 0, 'C');
$pdf->SetFont('Bold', '', 16);
$pdf->MultiCell(0, 10, 'PRIVATE LIMITED', 0, 'C');


$pdf->SetFont('Regular','',16);
$pdf->MultiCell(0, 10, 'CONSULTANT ENGINEER AGREEMENT', 0, 'C');

$pdf->Ln(10);

$pdf->SetFont('Regular','',10);
$pdf->Write(8,'We are pleased to extend this Consultant Engineer Agreement (the Agreement) to you, effective  '.$join_date.' , by and between');

$pdf->SetFont('SemiBold','',10);
$pdf->Write(8,'  WETZEL BARRON INFOSYSTEM PRIVATE LIMITED, ');

$pdf->SetFont('Regular','',10);
$pdf->Write(8,'a company registered under the Companies Act,  having its registered office at Sri Kumara Kripa, Koppam, Puthur Road Palakkad, Kerala, pin code 678001 (referred to as Company), and  '.$ce_name.' , '.$state);

$pdf->Ln(20);
$pdf->SetFont('SemiBold','',9);
$pdf->Write(5,'  1. Engagement Period: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(5,' This Agreement shall commence on '.$join_date.' and will continue until terminated in writing by either party, with a one-month notice period being mandatory.');

$pdf->Ln(10);
$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 2. Remuneration: ');

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' a. Compensation will be issued upon submission of invoices for completed services, in accordance with the terms outlined in this Agreement.');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,'b. Payment will be contingent on approved client calls, and are processed on the 10th of each month. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' c. No advance payment will be provided, and a deduction of Rs. 500 will be made from your salary starting from the second month, refundable along with the full and final settlement. ');


$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 3. Responsibilities: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Your responsibilities include safeguarding company property, adhering to designated shift timings, and following established procedures. ');



$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 4. Spare Responsibility: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' The Consultant Engineer is not authorized to make any commitments without obtaining prior written consent from the Company. ');



$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 5. Training and Resignation: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Given our commitment to providing/arranging training for CEs, mandatory attendance is expected for the provided training sessions. Resignation is permissible only after successfully completing a minimum of three months of employment. ');

$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 6. Termination: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' WBI Pvt Ltd reserves the right to terminate this Agreement upon 30 days written notice. Termination without notice is possible in case of misconduct, breach of agreement, negative background verification, or non-performance. ');


$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 7. Exit Process: ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' WBI ID CARD shall be returned to the head office through courier. NOC from client about inventory clearance must be received by CE/TSM and forwarded to HR. Subsequently, the HR department will transmit the NOC to the finance team. ');

$pdf->Ln(10);


$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 8. FNF Settlement:  ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' The Finance Team will finalize the FNF settlement within 45 days following the completion of call data verification by the client team. Any delays in the verification process from the client side may consequently postpone the FNF procedure. In the event of call rejections by the client, the corresponding call amounts will be deducted, and the FNF settlement will be processed accordingly. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 9. Confidentiality:  ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Both parties agree to maintain the confidentiality of information disclosed during the engagement. Any unauthorized disclosure or use may result in legal action. ');



$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 10. Indemnity:  ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' You agree to indemnify and hold WBI Pvt Ltd harmless against any claims, liabilities, demands, damages, or expenses arising from your activities, including breaches of applicable laws, agreement provisions, security breaches, and other specified instances. ');



$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 11. Poaching Clause:  ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' As we are working for multiple clients and providing /arranging training for CEs, changing employment from WBI to a client companies(client list updated in website) within 6 months of resignation/termination is considered a breach of the Agreement, leading to legal complications. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 12. General Terms:  ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' a. Notices shall be sent in writing to the addresses mentioned in the Agreement.  ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' b. This Agreement, along with referenced materials, constitutes the entire agreement between the parties. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' c. Compliance with company rules, background checks, and adherence to SOPs are mandatory.  ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' d. The Agreement is governed by Indian law, and disputes will be subject to the jurisdiction of the courts at Palakkad, Kerala, India.  ');



$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Please review this Agreement carefully and signify your acceptance by signing and dating below. We look forward to a successful collaboration. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' For Wetzel Barron Infosystem Private Limited ');


$pdf->SetFont('SemiBold','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,'Accepted and Agreed by',0,1,'L'); // 'R' indicates right alignment


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' [Authorized Signatory] [Name] [Date] ');

$pdf->SetFont('Regular','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' [Consultant Engineer Name] [Signature] [Date] ',0,1,'L'); // 'R' indicates right alignment

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' ________________________________________ ');

$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' ________________________________________ ',0,1,'L'); // 'R' indicates right alignment



$pdf->Ln(10);

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' Roles and Responsibilities of CEs: ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 1. Service Performance: ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Responsible for performing services on all the verticals in which training provided/arranged by WBI i.e. ATMs, Recyclers, PBK Machines, VSAT, E surveillance, Medical and financial instruments & UPS etc. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Tasks include Installation, Grouting, Site Survey, breakdown calls, EJ related calls, Operational calls, Preventive Maintenance Calls, Image recovery-related calls, and Proactive Maintenance Calls. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Ensure completion of calls within 1 hour from dispatch time (excluding out locations). ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 2. Documentation: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Utilize the assigned Google form for uploading daily work data. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 3. Spare parts Management: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Request spare parts through WBI TSM. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Mandatory return of defective parts using a customer courier. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 4. Reporting: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Upload images of different stages of PM calls, Earthing voltage calls, and Field Call reports. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Ensure timely completion of calls and return of defective parts within 24 hours. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 5. Adherence to Instructions: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Follow instructions from the Help Desk regarding call priorities. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Adhere to technical instructions on the software and hardware repair process. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 6. Asset Management: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Ensure the safe custody of company assets such as parts, pen drives, blower, tools, etc., issued to the CE. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 7. Documentation Compliance: ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Ensure that Fault Call reports [FCR] /service call report are signed and stamped by the customer upon completion of the call. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Return the signed FCR to the assigned Team Leader within 48 hours of call completion. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 8. Emergency Responsiveness: ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Perform emergency tasks on Sundays/Holidays when necessary. ');


$pdf->Ln(30);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 9. Performance Evaluation: ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' Any deficit in service delivery or SLM performance may attract penalties as per the agreement. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' Terms and Conditions: ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 1. Cost Recovery:  ');


$pdf->SetFont('Regular','',9);
$pdf->Write(6,' The company reserves the right to recover costs and monies if the Field Service Engineer (CE) is unable to return provided parts, tool kits, and devices. ');

$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 2. Documentation Submission:   ');

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' All Field Call Reports (FCRs) and installation documents must be submitted to the company weekly from the date of the incident. ');


$pdf->Ln(10);
$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 3. Salary Deduction:   ');

$pdf->SetFont('Regular','',9);
$pdf->Write(6,'  If any client rejects calls due to false call data updating, the corresponding amount will be deducted from the current salary. After committing a call, being unavailable will result in deduction of that call rate from the current salary. ');

$pdf->Ln(10);
$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' 4. Experience Certificate:  ');

$pdf->SetFont('Regular','',9);
$pdf->Write(6,'  At least 6 months completed in our company and only after completing FNF process it will be provided. ');


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6,' Dos & Donts for Engineer: ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 1. Reach the first site before 9:30 am. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 2. Be available on the mobile phone during working hours. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 3. Maintain a presentable appearance in formal dress. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 4. Ensure excellent coordination with custodians, banks, and customers. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 5. Always carry the WBI Employee ID card during work assignments. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 6. Avoid attending calls under the influence of alcohol or any narcotic substances. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 7. Refrain from consuming betel nut, Pan, or smoking during work assignments. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 8. Avoid involvement in any bribery activities. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 9. Keep tools and measuring instruments in good working condition. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 10. Do not attend a Bottom hatch call without the presence of a custodian. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 11. Attending calls at the scheduled time with no deviations. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 12. Take a GPS selfie with the machine upon reaching the site. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 13. Coordinate with the TSM and provide updates related to the call. ');


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,' 14. Leave the site only after getting permission from the concerned TSM. ');

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," 15. Submit a leave email at least one day before your intended leave of absence, unless it's a medical emergency." );

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6,"  16. Approval for only 2 days of casual leave for CEs." );

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," 17. Resignation is permissible only after completing at least 3 months post-attendance of provided training. " );

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," 18. Be ready to attend training arranged by the company for different verticals. " );


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," 19. Be available for calls assigned by the concerned TSM for different clients. " );


$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," Please review this Agreement carefully and signify your acceptance by signing and dating below. " );

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," By signing this letter, you acknowledge and accept the terms and conditions outlined above. Please sign and return a copy of this offer letter within 2days along with all the required documents softcopy. We look forward to welcoming you to the Wetzel Barron Infosystem Private Limited team. " );



$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," Sincerely, " );


$pdf->Ln(10);

$pdf->SetFont('SemiBold','',9);
$pdf->Write(6," For Wetzel Barron Infosystem Private Limited  " );

$pdf->SetFont('SemiBold','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' Accepted and Agreed by ',0,1,'L'); // 'R' indicates right alignment



$pdf->SetFont('Regular','',9);
$pdf->Write(6," [Authorized Signatory] [Name] [Date]  " );


$pdf->SetFont('Regular','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' [Consultant Engineer Name] [Signature] [Date] ',0,1,'L'); // 'R' indicates right alignment

$pdf->Ln(10);

$pdf->SetFont('Regular','',9);
$pdf->Write(6," ________________________________________  " );


$pdf->SetFont('Regular','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' ________________________________________ ',0,1,'L'); // 'R' indicates right alignment



$pdf->SetFont('Regular','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' [Your Company Seal/Stamp] ',0,1,'L'); // 'R' indicates right alignment


$pdf->Ln(15);


$pdf->SetFont('Regular','',9);
$pdf->SetXY($pdf->GetPageWidth() - 83, $pdf->GetY());
$pdf->Cell(0,10,' [Your Company Name] [Company Address] ',0,1,'L'); // 'R' indicates right alignment


$pdf->Output('');
?>
