<?php

// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];

 $start_date= date("d-m-Y", strtotime($_GET['start_date']));
 
 $end_date= date("d-m-Y", strtotime($_GET['end_date']));
 
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body >

<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
          <div class="card">

              <div class="card-body">
                  
<div class="position-sticky l-0 z-4 bg-white">
  <h6 class="card-title m-0">GM-WORK-BOOK</h6>
  <?php
$list = ['start_date'=>$start_date, 'end_date'=>$end_date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    <div id='clipboard'>
    <?php
//if($state!="" AND $start_date!="" AND $end_date!=""){    
?>       

<?php
// Function to retrieve and display data
function fetchData($state, $type, $con) {
    // Sanitize user inputs to prevent SQL injection (you should use prepared statements)
    $state = $con->real_escape_string($state);
    $type = $con->real_escape_string($type);

    // SQL query
    $sql = "SELECT name FROM login WHERE state LIKE '%$state%' AND type = '$type'";

    // Execute the query
    $result = $con->query($sql);

    // Check if there are results
    if ($result->num_rows > 0) {
        // Loop through the results and echo the names
        while ($row = $result->fetch_assoc()) {
            return $row["name"];
        }
    } else {
        echo "No results found.";
    }
}





$states = explode(",", $state_access);
$stateList = "'" . implode("','", $states) . "'";

$sql = "SELECT date, state,am10_remarks,no_of_call_attended FROM tsm_work_book
        WHERE date BETWEEN '$start_date' AND '$end_date' AND state IN ($stateList)";
$formattedOutput = [];
// Execute the SQL query
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $date = $row['date'];
    $state = $row['state'];
    
    $zm_name=fetchData($state, 'ZM', $con); 
    
      $formattedOutput[$date][$state]['am10_remarks'] += 1;
     
    if ($row['am10_remarks'] !== 'LEAVE' && $row['am10_remarks'] !== '0') {
      $am10_remarks[$date][$state] += 1;
      $total_am10_remarks[$date] += 1;
      
      $total_am10_remarks[$state] += 1;
      
       $grand_total_am10_remarks += 1;
       
       $zm_total[$zm_name] += 1;
       
    }
    
     if ($row['no_of_call_attended'] !== 'LEAVE' && $row['no_of_call_attended'] !== '0'  && $row['no_of_call_attended'] !== 'NO CALL' && $row['no_of_call_attended'] !== 'OTHERS') {
      $no_of_call_attended[$date][$state] += $row['no_of_call_attended'];
   
      $total_no_of_call_attended[$date] += $row['no_of_call_attended'];
      $total_no_of_call_attended[$state] += $row['no_of_call_attended'];
       $grand_total_no_of_call_attended += $row['no_of_call_attended'];
       
       $zm_total_no_of_call_attended[$zm_name] += $row['no_of_call_attended'];
    }
    
    
}

/*

$sql3 = "SELECT date,client_name,no_of_calls_completed  FROM tsm_client_call_data
        WHERE date BETWEEN '$start_date' AND '$end_date'";

$result3 = mysqli_query($con, $sql3);

while ($row3 = mysqli_fetch_assoc($result3)) {
   
   $client_name=$row3['client_name'];
   $no_of_calls_completed=$row3['no_of_calls_completed'];
   
    $client_calls_completed[$client_name] += $no_of_calls_completed;
}
*/

// Print the formatted output as an HTML table
echo '<table border="1">';
echo '<tr>';

foreach ($client_calls_completed as $key => $value) {
    echo '<td> '.$key.'</td>';
  }
  echo'</tr> <tr>';
  foreach ($client_calls_completed as $key => $value) {
   
    echo '<td> '. $value .'</td>';
  }

echo '</tr> </table>';

echo'<br>';
// Print the formatted output as an HTML table
echo '<table border="1">';
echo '<tr>';

$count = 1; // Initialize count outside the loop

foreach ($zm_total as $key => $value) {
    echo '<td> ZM ' . $count .'</td>';
    $count++; // Increment count after displaying each value
}

echo '</tr>';


echo '<tr>';
foreach ($zm_total as $key => $value) {
    echo '<td>';
    echo "Name: $key, <br> Total Presents: $value<br>";
    echo "Total Call Attend: ".$zm_total_no_of_call_attended[$key];
    echo'</td>';
}
echo '</tr>';

echo '</table>';

echo '<div class="d-flex gap-30 Euclid-Circular-B-SemiBold pt-30">';
echo '<div>';
echo 'Grand Total Presents : '.$grand_total_am10_remarks;
echo '</div><div>';
echo  'Grand Total Call Attend : '.$grand_total_no_of_call_attended;
echo '</div></div>';
?>
   
</div>

  <div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="export-button">Export to Excel</button>
  <button id="captureButton">Copy to Clipboard</button>
  </div>
<?php
//}
?>

 
    <script>
        document.getElementById('captureButton').addEventListener('click', function() {
            html2canvas(document.getElementById('clipboard')).then(function(canvas) {
                  canvas.toBlob(function(blob) {
                    var item = new ClipboardItem({ "image/png": blob });
                    navigator.clipboard.write([item]);
                });
            });
        });
    </script>

<script>

const total = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(10) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call10').textContent = `Total: ${total}`;

const total9 = [...document.querySelectorAll('#editable-table tbody tr')]
  .map(row => {
    const valueString = row.querySelector('td:nth-child(9) select')?.value || '0';
    const numericValue = parseFloat(valueString.replace(/[^0-9.-]/g, '')) || 0;
    return numericValue;
  })
  .reduce((sum, value) => sum + value, 0);

document.querySelector('#total_call9').textContent = `Total: ${total9}`;


</script>
<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
       "id",
"state",
"wbi_engineer",
"location",
"cms_team_leader",
"cms_engineer",
"am10_remarks",
"no_of_call_attended",
"no_of_call_attended",
"am10_remarks",
"pm1_remarks",
"report_time",
"date",
"wbi_tsm",
"rm_name",
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
           id: cells[0].textContent,
                state: '<?php echo $state; ?>',
                wbi_engineer: cells[1].textContent,
                location: cells[2].textContent,
                cms_team_leader: cells[3].textContent,
                cms_engineer: cells[4].textContent,
              'am10_remarks': cells[5].querySelector('select').value,
                'am10_remarks': cells[6].querySelector('select').value,
                'pm1_remarks': cells[7].querySelector('select').value,
              'no_of_call_attended': cells[8].querySelector('select').value,
              'no_of_call_attended': cells[9].querySelector('select').value,
                date: '<?php echo $date; ?>',
                wbi_tsm: '<?php echo $state; ?>',
                rm_name: '',
                jm_name: ''
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


                 </div>
            </div>
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>


</body>

</html>