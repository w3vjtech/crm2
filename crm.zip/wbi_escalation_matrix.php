<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();

include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 $table='wbi_escalation_matrix';


$customHeadings = [
    "id" => 'textContent',
    "name" => 'textContent', 
    "designation" => 'textContent', 
    "phone" => 'textContent', 
    "email" => 'textContent',
    "work_nature" => 'textContent', 
];
        
   
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>
<section>
<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

<div class='w-100 p-10'>
  

     <h6  class="py-15 Euclid-Circular-B-SemiBold">wbi escalation matrix</h6>
    
    
    
    
    <?php
//if($state!="" AND $date!=""){    
?>       


<div id="clipboard">
    

<input type="text" id="table-search" placeholder="Search..." >


   <table id="editable-table">
  
         <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead('filterCheckbox', $customHeadings);

       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM wbi_escalation_matrix";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
<td class='d-none'><?php echo $row["id"]; ?></td>

<td contenteditable><?php echo $row["name"]; ?></td>

<td contenteditable><?php echo $row["designation"]; ?></td>

<td contenteditable><?php echo $row["phone"]; ?></td>

<td contenteditable class='email'><?php echo $row["email"]; ?></td>

<td contenteditable><?php echo $row["work_nature"]; ?></td>
  </tr>

        <?php
    }
}
?>

</tbody>
    </table>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
  <button id="submit-button">Submit Data</button>
  <button id="export-button">Export to Excel</button>
  
<button onclick="addTableRow()">Add Row</button>


<button id="captureButton">Copy to Clipboard</button>

</div>


<?php
//}
?>


<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
          
<td class='d-none'></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable></td>

<td contenteditable class='email'></td>

<td contenteditable></td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>

</div>


<?php
$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');


$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');

?>

  </div>
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>
</body>

</html>