<?php
$table='insurance';
?>
<?php
clearstatcache();
ob_start();

$con = mysqli_connect('localhost', 'u309659183_hms', 'Ben824855', 'u309659183_hms');
$location='uploads/';
$data ='';
$keys ='';
$values ='';



function insert($table,$keys,$values)
{
 global $con;
echo $sql="INSERT INTO $table ($keys) VALUES($values)";
  
     if(mysqli_query($con, $sql)){
       header('Location: insurance_appy?request=yes');
    }
 
}






if (isset($_POST['submit'])) {
    
unset($_POST['submit']);
unset($_POST['DataTables_Table_0_length']);


$id = $_POST['id'];

    if ($id == '') {

foreach ($_FILES as $key => $value) {


if($value['name']!=''){
	
 $key_name = rand(100000, 999999).date("Ymdhis")."-".$value["name"];
 $key_tmp= $value["tmp_name"];

 move_uploaded_file($key_tmp,$location.$key_name);

$keys .=$key.',';
$values .="'".$key_name."',";

  }
  
} 

foreach ($_POST as $key => $value) {
     $key= htmlspecialchars($key);
  $value = htmlspecialchars($value);
 $keys .=$key.',';
$values .="'".$value."',";
} 
$keys .='action';
$values .="'insert'";

insert($table,$keys,$values);
 
     } 
}




?>

<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  <link rel="stylesheet" href="../assets/cssbundle/dataTables.min.css">
  <!-- project css file  -->
  <link rel="stylesheet" href="../assets/css/luno-style.css">
  <!-- Jquery Core Js -->
  <script src="../assets/js/plugins.js"></script>
</head>

<body class="layout-1" data-luno="theme-black">


  <div class="wrapper">



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">INSURANCE</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">
            
                 
<?php if(!empty($_GET['request'])){
    
echo "<p class='request'> REQUEST SEND SUCCESSFULLY </p>";
}
?>  

    <!-- Display the add/edit training form -->
    <form method="POST" action="" class="card-body">
        
        <input type="hidden" name="id" value="<?php echo isset($_GET['edit']) ? $_GET['edit'] : ''; ?>">
    <div class="row g-3">   
    
    
 <div class="col-md-6">
              <label class="form-label">NAME:</label>
        <input type="text" name="name" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['name'] : ''; ?>" class="form-control form-control-lg" placeholder="Name" required>
       
       </div>
          
       <div class="col-md-6">
              <label class="form-label">STATE:</label>
        <input type="text" name="sate" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['sate'] : ''; ?>" class="form-control form-control-lg" placeholder="Sate" required>
       
       </div>
       
       <div class="col-md-6">
              <label class="form-label">DOB:</label>
        <input type="date" name="dob" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['dob'] : ''; ?>" class="form-control form-control-lg" placeholder="dob" required>
       
       </div>
    
       
        <div class="col-md-6">
              <label class="form-label">ADDRESS:</label>
        <input type="text" name="address" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['address'] : ''; ?>" class="form-control form-control-lg" placeholder="Address" required>
       
       </div>
       
        <div class="col-md-6">
              <label class="form-label">NOMINEE NAME:</label>
        <input type="text" name="nominee_name" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['nominee_name'] : ''; ?>" class="form-control form-control-lg" placeholder="Nominee Name" required>
       
       </div>
       
       <div class="col-md-6">
              <label class="form-label">NOMINEE AGE:</label>
        <input type="text" name="nominee_age" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['nominee_age'] : ''; ?>" class="form-control form-control-lg" placeholder="Nominee Age" required>
       
       </div>
   
    <div class="col-md-6">
              <label class="form-label">RELATIONSHIP WITH NOMINEE:</label>
        <input type="text" name="relationship_with_nominee" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['relationship_with_nominee'] : ''; ?>" class="form-control form-control-lg" placeholder="Relationship With Nominee" required>
       
       </div>
       
        <div class="col-md-6">
              <label class="form-label">DRIVING LICENCE NO:</label>
        <input type="text" name="driving_licence_no" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['driving_licence_no'] : ''; ?>" class="form-control form-control-lg" placeholder="Driving Licence No" required>
       
       </div>
       
        <div class="col-md-6">
              <label class="form-label">AADHAAR NUMBER:</label>
        <input type="text" name="aadhaar_number" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['aadhaar_number'] : ''; ?>" class="form-control form-control-lg" placeholder="Aadhaar Number" required>
       
       </div>
       
       

       <div class="col-md-6">
              <label class="form-label">PHONE:</label>
        <input type="text" name="phone" value="<?php echo isset($_GET['edit']) ? $pageresults[0]['phone'] : ''; ?>" class="form-control form-control-lg" placeholder="Phone" required>
       
       </div>
       
       
   



           <div class="card-footer">
                <button type="submit" name="submit" class="btn btn-primary"> SUBMIT</button>
              </div>
    </form>
    
    
             
              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    
    
    
    
       
 <?php
include'footer.php';
?>  </div>

  <script src="../assets/js/theme.js"></script>
  <script src="../assets/js/bundle/dataTables.bundle.js"></script>
  <script>
    $('.myDataTable').addClass('nowrap').dataTable({
      responsive: true,
    });
  </script>
</body>

</html>