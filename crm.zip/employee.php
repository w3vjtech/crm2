<?php
 // file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 $working_status=$_GET['working_status'];
 $vertical_name=$_GET['vertical_name'];
 $designation=$_GET['designation'];
 
 
 
 
 $table='employee';

$customHeadings = [
    "id" => 'textContent',
    "name" => 'textContent', 
    "designation" => 'textContent',
    "vertical_name" => 'selectValue',
    "employee_id" => 'textContent',
    "contact_number" => 'textContent',
    "email_id" => 'textContent',
    "joining_date" => 'date',
    "dob" => 'date',
    "marital_status" => 'selectValue',
    "qualification" => 'textContent',
    "experience" => 'textContent',
    "district" => 'textContent',
    "state" => 'textContent',
    "country" => 'textContent',
    "address" => 'textContent',
    "bank_name" => 'textContent',
    "branch_name" => 'textContent',
    "account_holder_name" => 'textContent',
    "account_number" => 'textContent',
    "ifsc_code" => 'textContent',
    "reference_number" => 'textContent',
    "blood_group" => 'textContent',
    "aadhar_card_number" => 'textContent',
    "softcopy_received" => 'selectValue',
    "hardcopy_received" => 'selectValue',
    "working_status" => 'selectValue',
    "last_working_date" => 'date'
];
    
    
    
    ?>    

<!DOCTYPE html>
<html>
<head>
 <?php
 include'head.php';
 ?>
</head>
<body>

<section>

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
<div class='position-sticky l-0 z-4 bg-white'>

<h6  class="pt-5">WBI Employee</h6>
    
<?php
$list = ['state'=>$state, 'working_status'=>$working_status, 'vertical_name'=>$vertical_name, 'designation'=>$designation ]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
        
    <?php
//if($state!="" AND $date!=""){    
?> 
    <div id="clipboard" class="pb-100">
<div>
    

    
    <?php
    $sql = "SELECT COUNT(*) as total_rows FROM employee WHERE 1";

if(!empty($state)){
  $sql .= " AND state='$state'";
}
if(!empty($working_status)){
  $sql .= " AND working_status='$working_status'";
}
if(!empty($vertical_name)){
  $sql .= " AND vertical_name='$vertical_name'";
}
if(!empty($designation)){
  $sql .= " AND designation='$designation'";
}

$result = $con->query($sql);
if ($result->num_rows > 0) {
     $row = $result->fetch_assoc(); 
     ?>
        <p>Total WBI EMPLOYEE: <?php echo $row["total_rows"]; ?> </p> 
<?php
}
?>
</div>


<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table" >
       <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   
<?php
$sql = "SELECT * FROM employee WHERE 1";

if(!empty($state)){
  $sql .= " AND state='$state'";
}
if(!empty($working_status)){
  $sql .= " AND working_status='$working_status'";
}
if(!empty($vertical_name)){
  $sql .= " AND vertical_name='$vertical_name'";
}
if(!empty($designation)){
  $sql .= " AND designation='$designation'";
}


$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class='position-sticky l-0 z-4 bg-white' contenteditable><?php echo $row["name"]; ?></td>
<td contenteditable><?php echo $row["designation"]; ?></td>

<td> <select>
    <option value="<?php echo $row["vertical_name"]; ?>"> <?php echo $row["vertical_name"]; ?></option>
<option value="select">select</option>
<option value="WBI">WBI</option>
<option value="O²">O²</option>
<option value="Dirtx">Dirtx</option>
<option value="Cassette">Cassette</option>
  </select>
</td>

<td contenteditable><?php echo $row["employee_id"]; ?></td>
<td contenteditable><?php echo $row["contact_number"]; ?></td>
<td contenteditable class='email'><?php echo $row["email_id"]; ?></td>
<td><input type="date" value="<?php echo $row["joining_date"]; ?>"> </td>
<td><input type="date" value="<?php echo $row["dob"]; ?>"> </td>
<td>
  <select>
    <option value="<?php echo $row["marital_status"]; ?>"> <?php echo $row["marital_status"]; ?></option>
<option value="select">select</option>
<option value="SINGLE">SINGLE</option>
<option value="MARRIED">MARRIED</option>
  </select>
</td>
<td contenteditable><?php echo $row["qualification"]; ?></td>
<td contenteditable><?php echo $row["experience"]; ?></td>
<td contenteditable><?php echo $row["district"]; ?></td>
<td contenteditable><?php echo $row["state"]; ?></td>
<td contenteditable><?php echo $row["country"]; ?></td>
<td contenteditable><?php echo $row["address"]; ?></td>
<td contenteditable><?php echo $row["bank_name"]; ?></td>
<td contenteditable><?php echo $row["branch_name"]; ?></td>
<td contenteditable><?php echo $row["account_holder_name"]; ?></td>
<td contenteditable><?php echo $row["account_number"]; ?></td>
<td contenteditable><?php echo $row["ifsc_code"]; ?> </td>
<td contenteditable><?php echo $row["reference_number"]; ?></td>
<td contenteditable><?php echo $row["blood_group"]; ?></td>
<td contenteditable><?php echo $row["aadhar_card_number"]; ?></td>

<td>
 <select>
    <option value="<?php echo $row["softcopy_received"]; ?>"> <?php echo $row["softcopy_received"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td>
  <select>
    <option value="<?php echo $row["hardcopy_received"]; ?>"> <?php echo $row["hardcopy_received"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>

<td> <select>
    <option value="<?php echo $row["working_status"]; ?>"> <?php echo $row["working_status"]; ?></option>
<option value="select">select</option>
<option value="WORKING">WORKING</option>
<option value="RESIGNED">RESIGNED</option>
<option value="TERMINATED">TERMINATED</option>
<option value="NOT RESPONDING">NOT RESPONDING</option>
  </select> </td>
  
<td> <input type="date" value="<?php echo $row["last_working_date"]; ?>"></td>
        </tr>

        <?php
    }
}
?>

</tbody>
    </table>  
    
    </div>
<div class='position-sticky l-0 z-4 bg-white d-flex gap-20'>
    
  
    
  <button id="submit-button"   <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  
  <button id="export-button">Export to Excel</button>
<button id="captureButton">Copy to Clipboard</button>
<button onclick="addTableRow()">Add Row</button>

</div>
<?php
//}
?>





<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
        
<td class='d-none'></td>
<td class='position-sticky l-0 z-4 bg-white' contenteditable></td>
<td contenteditable></td>

<td> <select>
<option value="select">select</option>
<option value="WBI">WBI</option>
<option value="O²">O²</option>
<option value="Dirtx">Dirtx</option>
<option value="Cassette">Cassette</option>
  </select>
</td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable class='email'></td>
<td><input type="date" value=""></td>
<td><input type="date" value=""></td>
<td>
  <select>
<option value="select">select</option>
<option value="SINGLE">SINGLE</option>
<option value="MARRIED">MARRIED</option>
  </select>
</td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td>
 <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>
 
<td>
  <select>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select>
</td>


<td> <select>
<option value="select">select</option>
<option value="WORKING">WORKING</option>
<option value="RESIGNED">RESIGNED</option>
<option value="TERMINATED">TERMINATED</option>
<option value="NOT RESPONDING">NOT RESPONDING</option>
  </select> </td>
<td> <input type="date" value=""></td>
<td> <button onclick="removeTableRow(this)">Remove</button> </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>





<?php

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>

  </div>

    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

</body>
</html>


