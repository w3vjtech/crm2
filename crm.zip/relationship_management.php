<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();


include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
   
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='relationship_management';

$customHeadings = [
"id" => 'textContent',
"wbi_staff_name" =>'textContent',
"designation" =>'textContent',
"complaint_suggestion" =>'textContent',
"status" =>'selectValue',
"remarks" =>'textContent',
];
 ?>
 


<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>


<section>
    

<div class='sidebar'>
        <?php
    include'header.php';
    ?>

</div>
<div class='main'>
    <div class='nav'>
        <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        

    
    <div class="position-sticky l-0 z-4 bg-white">

     <h6  class="pt-5">Relationship Management</h6>
    
    
 <?php
$list = ['state'=>$state, 'date'=>$date]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>



        </div>   
    
    <?php
if($state!="" AND $date!=""){    
?>       


<div id="clipboard">
    
<input type="text" id="table-search" placeholder="Search..." >

   <table id="editable-table">
  <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM relationship_management WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($date)){
  $sql .= " AND date='$date'";
}


//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
    <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["wbi_staff_name"]; ?></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["designation"]; ?></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["complaint_suggestion"]; ?></td> 
<td>
 <select>
    <option value="<?php echo $row["status"]; ?>"><?php echo $row["status"]; ?></option>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SOLVED">SOLVED</option>
<option value="NOT SOLVED">NOT SOLVED</option>
<?php } ?>
  </select> 
 </td>
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ><?php echo $row["remarks"]; ?></td> 

      </tr>

        <?php
    }
}
?>

</tbody>
    </table>
</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">

  <button id="submit-button" <?php if($type != "HR" && $type != "TSM" && $type != "RM" && $type != "ZM" &&  $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
  <button onclick="addTableRow()" style="<?php if($type != "HR" && $type != "ZM" && $type != "GM" && $type != "MD" && $type != "D") echo "display: none;"; ?>" >Add Row</button>
  <button id="captureButton">Copy to Clipboard</button>
</div>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
     
<td class='d-none'></td>

<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 
<td>
 <select>
    <?php if($type == "HR" || $type == "GM" || $type == "MD" || $type == "D"){ ?>
<option value="select">select</option>
<option value="SOLVED">SOLVED</option>
<option value="NOT SOLVED">NOT SOLVED</option>
<?php } ?>
  </select> 
 </td>
<td <?php if($type=="HR" OR $type=="GM" OR $type=="MD" OR $type=="D"){ ?>contenteditable <?php } ?> ></td> 

<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>





<?php
}
?>


<?php
$customHeadings["state"] = $state;
$customHeadings["date"] = $date;

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');

$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>



    </div>
    <div class='footer'>
        
     <?php
    include'footer.php';
    ?>  
    </div>
    
</div>
</section>


</body>

</html>