<?php
$table='tsm_work_book';
include'function.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  <link rel="stylesheet" href="../assets/cssbundle/dataTables.min.css">
  <!-- project css file  -->
  <link rel="stylesheet" href="../assets/css/luno-style.css">
  <!-- Jquery Core Js -->
  <script src="../assets/js/plugins.js"></script>
</head>

<body class="layout-1" data-luno="theme-black">

 <?php
 include'sidebar.php';
  ?>
  <div class="wrapper">
<?php
include'header.php';
?>



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">RM work book</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">

    
    

 
                <table class="table myDataTable table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </th>
                      
 
  <th>State</th>
  <th>Engineer Name</th>
  <th>date</th>
  <th>call</th>


            <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                     
                           <?php foreach ($pageresults as $pageresult) : ?>
        <tr>
             <td>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" value="">
                        </div>
                      </td>
                     
  
  
  
  <td><?php echo $pageresult['state']; ?></td>
 
  <td><?php echo $pageresult['engineer_name']; ?></td>
  <td><?php echo $pageresult['date']; ?></td>
  
  
<td><?php echo $pageresult['no_of_call_complete']+$pageresult['call_status']; ?></td>
  
  
   
              <td>
                          <a href="?edit=<?php echo $pageresult['id']; ?>" > <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-edit"></i></button></a>
                        <a href="?delete=<?php echo $pageresult['id']; ?>" onclick="return confirm('Are you sure you want to delete this training?')"> <button type="button" class="btn btn-sm btn-outline-danger"><i class="fa fa-trash-o"></i></button></a>
                      </td>
                      
        </tr>
        <?php endforeach; 
              ?>
                    
  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
    
    
    
    
    
       
 <?php
include'footer.php';
?>  </div>

  <script src="../assets/js/theme.js"></script>
  <script src="../assets/js/bundle/dataTables.bundle.js"></script>
  <script>
    $('.myDataTable').addClass('nowrap').dataTable({
      responsive: true,
    });
  </script>
</body>

</html>