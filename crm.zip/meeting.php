<?php
$table='tsm_work_book';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
 </head>

<body class="layout-1" data-luno="theme-black">

 <?php
 include'sidebar.php';
  ?>
  <div class="wrapper">
<?php
include'header.php';
?>



     <!-- Body: Body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h6 class="card-title m-0">Meeting</h6>
                <div class="dropdown morphing scale-left">
                  <a href="#" class="card-fullscreen" data-bs-toggle="tooltip" title="Card Full-Screen"><i class="icon-size-fullscreen"></i></a>
            
                </div>
              </div>
              <div class="card-body">

  
  


    
    
    
             
             <form action="" method="get" class='searc-form'>
      <div class='row'>
      <div class="col-md-3">
  <label class="form-label">State:</label>
  <select name="state" class="form-control form-control-lg">
    <option value="<?php echo isset($state) ? $state : ''; ?>"> <?php echo isset($state) ? $state : 'Select'; ?></option>
   <?php
        echo $state_access;
       $array = explode(",", $state_access);

        ?>
        
<?php
$sql = "SELECT * FROM state";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        
if (in_array($name, $array)) {
        echo '<option value="' . $name . '">' . $name . '</option>';
}
    }
} 
?>
</select>
</div>


<div class="col-md-3">
    <label class="form-label">Date:</label>
    <input type="date" name="date" value="<?php echo $date; ?>" class="form-control form-control-lg" placeholder="Date" required>
</div>


<div class="col-md-3">
    <div class='search-box'>
        <input type="submit"  class="search" value="Search">
        </div>
    </div>
</div>

    </form>
    <style>
        .search-box {
    position: relative;
    height: 100%;
}

input.search {
    position: absolute;
    bottom: 5px;
    padding: 7px 60px;
    outline: 0;
    border: 0;
    color: #606060;
}
form.searc-form {
    padding-bottom: 40px;
}

table {
     width: 100%;
    overflow: scroll;
}
    </style>
    <?php
if($state!="" AND $date!=""){    
?>       
   <table id="editable-table">
        <thead>
        
            <tr>
<th>tsm_name</th>
<th>rm_name</th>
<th>date</th>
<th>meeting_times</th>
<th>rm_approvel</th>
<th>meeting_agenda</th>
<th>meeting_attendance</th>
<th>meeting_miniutes</th>
<th>remarks</th>
            </tr>
        </thead>
        <tbody>
   

<?php

$sql = "SELECT * FROM meeting WHERE state = '$state' AND date = '$date'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
     <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>










<td contenteditable>  <?php echo $row["tsm_name"]; ?> </td>

<td contenteditable>  <?php echo $row["rm_name"]; ?> </td>
<td>   
 <input type="date" name="date" value="<?php echo $row["date"]; ?>" class="form-control form-control-lg" placeholder="date">
</td>
<td>   
 <input type="time" name="meeting_times" value="<?php echo $row["meeting_times"]; ?>" class="form-control form-control-lg" placeholder="meeting_times">
</td>
<td>
  <select onchange="updateBorderColor(this)">
    <option value="<?php echo $row["rm_approvel"]; ?>">  <?php echo $row["rm_approvel"]; ?></option>
    
   <?php if($type=="RM"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>
<td contenteditable>  <?php echo $row["meeting_agenda"]; ?> </td>




<td contenteditable>  <?php echo $row["meeting_attendance"]; ?> </td>
<td contenteditable>  <?php echo $row["meeting_miniutes"]; ?> </td>
<td contenteditable>  <?php echo $row["remarks"]; ?> </td>

        </tr>
        
        <?php
    }
}else{
        ?>
          <tr>
<td class='d-none'></td>

<td contenteditable>0</td>
<td contenteditable>0</td>
<td>   
 <input type="date" name="date" value="" class="form-control form-control-lg" placeholder="date">
</td>
<td>   
 <input type="time" name="meeting_times" value="" class="form-control form-control-lg" placeholder="meeting_times">
</td>
<td>
      <select onchange="updateBorderColor(this)">
 <?php if($type=="RM"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
  </select>
</td>
<td contenteditable>0</td>



<td contenteditable>0</td>
<td contenteditable>0</td>
<td contenteditable>0</td>
<td contenteditable>0</td>
       
        </tr>

        <?php
}
?>

</tbody>
    </table>



  <button id="submit-button">Submit Data</button>
  <button id="export-button">Export to Excel</button>
<?php
}
?>

<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
    <td class='d-none'></td>
    <td contenteditable>0</td>
    <td contenteditable>0</td>
    <td>   
      <input type="date" name="date" value="" class="form-control form-control-lg" placeholder="date">
    </td>
     <td>   
      <input type="time" name="meeting_times" value="" class="form-control form-control-lg" placeholder="meeting_times">
    </td>
       <td>
      <select onchange="updateBorderColor(this)">
         <?php if($type=="RM"){ ?>
<option value="">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
<?php } ?>
      </select>
    </td>
    <td contenteditable>0</td>
 
    <td contenteditable>0</td>
    <td contenteditable>0</td>
    <td contenteditable>0</td>
    <td>
      <button onclick="removeTableRow(this)">Remove</button>
    </td>
  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>

<button onclick="addTableRow()">Add Row</button>


<script>
  document.getElementById('submit-button').addEventListener('click', function () {
        const tableRows = document.querySelectorAll('#editable-table tbody tr');
        const data = [];

        tableRows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const rowData = {
                id: cells[0].textContent,
tsm_name: cells[1].textContent,
rm_name: cells[2].textContent,
date: cells[3].querySelector('input[type="date"]').value,
meeting_times: cells[4].querySelector('input[type="time"]').value,
rm_approvel: cells[5].querySelector('select').value,
meeting_agenda: cells[6].textContent,
meeting_attendance: cells[7].textContent,
meeting_miniutes: cells[8].textContent,
remarks: cells[9].textContent,
                state: '<?php echo $state; ?>'
            };
            data.push(rowData);
        });

        const jsonString = JSON.stringify(data);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'meeting_crud.php', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert('Data sent successfully');
                    console.log('Data sent successfully:', xhr.responseText);
                } else {
                    alert("Data sent Failed");
                    console.error('Error sending data:', xhr.statusText);
                }
            }
        };
        xhr.send(jsonString);
    });
</script>

<script>
document.getElementById("export-button").addEventListener("click", function() {
    const tableRows = document.querySelectorAll('#editable-table tbody tr');
    const data = [];

   const customHeadings = [
       "id",
       "tsm_name",
"rm_name",
"date",
"meeting_times",
"rm_approvel",
"meeting_agenda",
"meeting_attendance",
"meeting_miniutes",
"remarks"
"state",
    ];
    

    data.push(customHeadings.join(','));
    
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        const rowData = {
               id: cells[0].textContent,
tsm_name: cells[1].textContent,
rm_name: cells[2].textContent,
date: cells[3].querySelector('input[type="date"]').value,
meeting_times: cells[4].querySelector('input[type="time"]').value,
rm_approvel: cells[5].querySelector('select').value,
meeting_agenda: cells[6].textContent,
meeting_attendance: cells[7].textContent,
meeting_miniutes: cells[8].textContent,
remarks: cells[9].textContent,
state: '<?php echo $state; ?>'
        };
        data.push(Object.values(rowData).map(value => `"${value}"`).join(","));
    });

    const csvContent = "data:text/csv;charset=utf-8," + data.join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    
    link.click();
    
    document.body.removeChild(link);
});

</script>


                 </div>
            </div>
          </div>
        </div> <!-- Row end  -->
      </div>
    </div>
 <?php
include'footer.php';
?>  </div>
</body>

</html>