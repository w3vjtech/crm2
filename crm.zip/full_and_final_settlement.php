<?php
// file autoload
require_once 'functions/autoload.php';


// database
$db = new db();
$con=$db->getConnection();



$table='invoice';
include'function.php';
?>
  <?php
    $state=$_GET['state'];
    $vendor=$_GET['vendor'];
    $month=$_GET['month'];
    $year=$_GET['year'];
 $report_time=$_GET['report_time'];
 $date=$_GET['date'];
 $edit=$_GET['edit'];
 
 
$table='full_and_final_settlement';

$customHeadings = [
    "id" => 'textContent',
    "date" => 'date', 
    "state" => $state,
    "employee_name" => 'textContent',
    "employee_id" => 'textContent',
    "last_working_date" => 'date',
    "noc_from_client" => 'textContent',
    "id_card_status" => 'selectValue',
    "proceeded_date" => 'date',
    "fnf_status" => 'selectValue',
    "remarks" => 'textContent',
];
        
  
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
 <?php
 include'head.php';
 ?>
  
</head>

<body>



<section>
    

<div class='sidebar'>
    <?php
include'header.php';
?>
</div>
<div class='main'>
    <div class='nav'>
         <?php include'top-bar.php'; ?>
    </div>
    <div class='page'>
        
 
<div class="position-sticky l-0 z-4 bg-white">

     <h6  class="pt-5">Full and final settlement</h6>

   <?php
$list = ['state'=>$state]; 

$search_form = new search_form();
echo $search_form->generate_search_form($con, $state_access, $list);

?>
</div>
    
    
    <?php
if($state!=""){    
?>       

<div id="clipboard">
    <input type="text" id="table-search" placeholder="Search..." >
   <table id="editable-table">
 <?php
$Thead = new Thead();
echo $Thead=$Thead->generateThead($filterCheckbox, $customHeadings);
       ?>
        <tbody>
   

<?php
$sql = "SELECT * FROM full_and_final_settlement WHERE 1";

if(isset($state)){
  $sql .= " AND state='$state'";
}
if(isset($month)){
  $sql .= " AND month='$month'";
}
if(isset($year)){
  $sql .= " AND year='$year'";
}

//WHERE month='$month' AND  year='$year' AND vendor='$vendor'";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      
        ?>
      <tr>
           
<td class='d-none'><?php echo $row["id"]; ?></td>
<td class="position-sticky l-0 z-4 bg-white "><input type="date" value="<?php echo $row["date"]; ?>"></td>
<td contenteditable><?php echo $row["state"]; ?> </td>
<td contenteditable><?php echo $row["employee_name"]; ?></td>
<td contenteditable><?php echo $row["employee_id"]; ?></td>
<td><input type="date" value="<?php echo $row["last_working_date"]; ?>"></td>
<td contenteditable><?php echo $row["noc_from_client"]; ?></td>

<td>
 <select>
    <option value="<?php echo $row["id_card_status"]; ?>"><?php echo $row["id_card_status"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td><input type="date" value="<?php echo $row["proceeded_date"]; ?>"> </td>

<td>
 <select>
    <option value="<?php echo $row["fnf_status"]; ?>"><?php echo $row["fnf_status"]; ?></option>
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td contenteditable><?php echo $row["remarks"]; ?></td>


        </tr>

        <?php
    }
}
?>

</tbody>
    </table>
</div>
<div class="position-sticky l-0 z-4 bg-white d-flex gap-20">
    
  <button id="submit-button" <?php if($type != "HR" && $type != "GM" && $type != "MD" && $type != "D") echo "disabled"; ?> >Submit Data</button>
  <button id="export-button">Export to Excel</button>
<button onclick="addTableRow()">Add Row</button>
<button id="captureButton">Copy to Clipboard</button>


</div>
<script>

function addTableRow() {
  var table = document.getElementById("editable-table").getElementsByTagName('tbody')[0];
  var newRow = table.insertRow(table.rows.length);

  newRow.innerHTML = `
       
      
           
<td class='d-none'></td>
<td class="position-sticky l-0 z-4 bg-white" ><input type="date" value=""> </td>
<td contenteditable></td>
<td contenteditable></td>
<td contenteditable></td>
<td><input type="date" value=""></td>
<td contenteditable></td>

<td>
 <select>

<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td><input type="date" value=""></td>

<td>
 <select>
   
<option value="select">select</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
  </select> 
 </td>

<td contenteditable></td>


      

<td> <button onclick="removeTableRow(this)">Remove</button> </td>

  `;
}

function removeTableRow(button) {
  var row = button.parentNode.parentNode;
  row.parentNode.removeChild(row);
}
</script>




<?php
}
?>



<?php
$customHeadings["month"] = $month;          
$customHeadings["year"] = $year;          

$ExportButton = new ExportButton();
echo $ExportButton=$ExportButton->renderScript($customHeadings,'editable-table','export-button');


$SubmitButton = new SubmitButton();
echo $SubmitButton=$SubmitButton->renderScript($customHeadings, $table,'editable-table','submit-button');

$Clipboard = new Clipboard();
echo $Clipboard=$Clipboard->generateScript('clipboard','captureButton');

$TableFilter = new TableFilter();
echo $TableFilter=$TableFilter->generateScript('table-search', 'filterCheckbox','editable-table');
?>





 

  
        
    </div>
    <div class='footer'>
         <?php
include'footer.php';
?>
    </div>
    
</div>
</section>

</body>

</html>